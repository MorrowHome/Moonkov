"""Serial R09–R18 cumulative display FBX validation.
Run only after export completion; explicit readiness flag prevents partial imports.
Set MOONKOV_R18_EXPORT_READY=1 after the export completion token is present.
Uses factory-empty import for every partition. Never opens or saves the author .blend.
No Unity acceptance is claimed. The instance-specific seam override remains blocked.
"""
import bpy
import collections
import hashlib
import json
import os
import sys
import traceback
from pathlib import Path

D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
from independent_fbx_helpers import digest_file, write_json, validate_object, read_fbx_global_settings, IMPORT_SETTINGS
from independent_binary_r16 import validate_binary_geometry, validate_binary_attributes
PRIOR = D.parent / 'r09_r16_cumulative_game_export_handoff_20261020'
SOURCE = D.parent / 'moonkov_rebuild_R18_west_service_house_20261020' / 'Moonkov_Rebuild_R18_West_Service_House_FULL_EDITABLE.blend'
SOURCE_SHA = 'd840a1ad99f65a153f7bda34d73adbb830b7d1cad5654d3270f5cd23c6f788e0'
SOURCE_BYTES = 308488076
EXPECTED_PARTITIONS = 33
EXPECTED_OBJECTS = 1629
EXPECTED_ADDED = 196


def load(path):
    return json.loads(Path(path).read_text())


def validate_manifest(manifest):
    old = load(PRIOR / 'EXPORT_MANIFEST.json')
    frozen = load(D / 'source_contracts/PRIOR_R09_R16_EXPORT_MANIFEST.json')
    assert frozen == old, 'Prior export manifest frozen copy differs.'
    assert manifest['source_sha256'] == SOURCE_SHA and manifest['source_bytes'] == SOURCE_BYTES
    rows = [r for r in manifest['objects'] if not r.get('exclude_reason')]
    parts = manifest['partitions']
    assert len(parts) == EXPECTED_PARTITIONS and len(rows) == EXPECTED_OBJECTS
    assert len({p['name'] for p in parts}) == len(parts) == len({p['file'] for p in parts})
    assert len({r['export_object'] for r in rows}) == len(rows) == len({r['source_object'] for r in rows})
    expected_old = {r['source_object']: r for r in old['objects']}
    by_source = {r['source_object']: r for r in rows}
    assert len(expected_old) == 1433 and all(by_source.get(n) == r for n, r in expected_old.items()), 'Old object row changed.'
    added = [r for r in rows if r['source_object'] not in expected_old]
    assert len(added) == EXPECTED_ADDED and all(r['source_object'].startswith(('R17_','R18_')) for r in added)
    assert all(r['source_type'] == 'MESH' and r['instance_parent'] is None for r in rows)
    grouped = collections.defaultdict(list)
    for r in rows:
        grouped[r['partition']].append(r)
        stable = 'GX_' + hashlib.sha256(json.dumps([r['source_object'], None, []], separators=(',', ':')).encode()).hexdigest()[:12] + '_' + r['source_object'][:44]
        assert r['export_object'] == stable, ('Stable object identity mismatch', r['source_object'])
        assert r['export_snapshot']['max_polygon_vertices'] <= 4
        assert r['export_snapshot']['material_slots'] == r['source_snapshot']['material_slots']
        assert r['export_snapshot']['local_vertex_sha256'] == r['source_snapshot']['local_vertex_sha256']
        assert r['export_snapshot']['vertices'] == r['source_snapshot']['vertices']
        assert r['export_snapshot']['world_bounds'] == r['source_snapshot']['world_bounds']
        if r['source_uv_layers']:
            assert r['uv_policy'] == 'preserved_existing_layers_unchanged'
            assert r['pretri_snapshot']['uv_layers'] == r['source_snapshot']['uv_layers']
        else:
            assert r['uv_policy'] != 'preserved_existing_layers_unchanged'
            assert len(r['export_snapshot']['uv_layers']) == 1 and not r['source_snapshot']['uv_layers']
            assert all(u['finite'] and u['nonzero_geometry_triangles_with_zero_uv_area'] == 0 for u in r['export_snapshot']['uv_layers'])
    assert set(grouped) == {p['name'] for p in parts}
    assert all(len(grouped[p['name']]) == p['objects'] for p in parts)
    assert len({r['partition'] for r in added}) == 9
    actual_files = {p.resolve() for p in (D / 'fbx').glob('*.fbx')}
    assert actual_files == {(D / p['file']).resolve() for p in parts}
    assert all((D / p['file']).resolve().is_relative_to((D / 'fbx').resolve()) for p in parts)
    old_bytes = []
    for p in old['partitions']:
        new = next(x for x in parts if x['name'] == p['name'])
        assert new == p
        assert (D / p['file']).stat().st_size == p['bytes']
        assert digest_file(D / p['file']) == digest_file(PRIOR / p['file']) == p['sha256']
        old_bytes.append({'file': p['file'], 'sha256': p['sha256'], 'bytes': p['bytes'], 'byte_exact_to_prior': True})
    assert manifest['images'] == old['images'] and len(manifest['images']) == 18
    assert {(D / i['file']).resolve() for i in manifest['images']} == {p.resolve() for p in (D / 'textures').glob('*')}
    maps = []
    for i in manifest['images']:
        path = D / i['file']
        packed = i['source_packed_payloads']
        assert path.resolve().is_relative_to((D / 'textures').resolve()) and len(packed) == 1
        assert i['file_bundled'] is True and i['source_image'].startswith('R14_')
        assert digest_file(path) == digest_file(PRIOR / i['file']) == i['sha256'] == packed[0]['sha256']
        assert path.stat().st_size == i['bytes'] == packed[0]['bytes']
        maps.append({'file': i['file'], 'sha256': i['sha256'], 'bytes': i['bytes'], 'exact_to_prior_and_declared_source_packed': True})
    assert manifest['units'] == old['units'] and manifest['settings'] == old['settings']
    p = manifest['integration_policy']
    for key in ('review_only_no_automatic_import', 'preserve_current_local_lunar_surface_material_textures_shader_settings',
                'preserve_existing_Unity_materials', 'no_collision_or_gameplay_changes', 'no_generated_lights',
                'preserve_118_light_and_135_button_ids', 'preserve_baked_MC00_lighting_static_chunks_indoor_culling_rock_LOD',
                'preserve_existing_R08_colliders', 'bundled_R14_compact_maps_review_only'):
        assert p[key] is True, key
    for key in ('base_geometry_exported', 'terrain_geometry_exported', 'automatic_material_import',
                'import_or_replace_cloud_terrain_materials', 'import_source_textures',
                'automatic_collider_deletion_or_replacement', 'generate_colliders_from_FBX', 'automatic_R14_material_binding'):
        assert p[key] is False, key
    assert manifest['local_material_protection']['current_local_lunar_material_must_not_change'] is True
    assert all(m['automatic_import_allowed'] is False and 'neutral placeholder' in m['fbx_material_role'] for m in manifest['materials'])
    assert {m['source_material'] for m in manifest['materials']} == {n for r in rows for n in r['export_snapshot']['material_slots'] if n is not None}
    for m in manifest['materials']:
        if m['source_material'].startswith(('R23_', 'R24_')):
            assert m['translation_status'] == 'EXCLUDED_SOURCE_SETTINGS_PRESERVE_CURRENT_LOCAL_R23_R24'
    bundled = {i['source_image'] for i in manifest['images']}
    reference = {i['source_image'] for i in manifest['source_image_dependencies_reference_only']}
    graph_images = {n['image'] for m in manifest['materials'] for n in m['nodes'] if n.get('image')}
    assert bundled.isdisjoint(reference) and graph_images == bundled | reference
    assert all(i['file_bundled'] is False for i in manifest['source_image_dependencies_reference_only'])
    return rows, parts, grouped, {'status': 'PASS', 'old_object_rows_exact': len(expected_old),
            'new_R17_R18_objects': len(added), 'old_FBX_byte_checks': old_bytes,
            'maps': maps, 'old_FBX_byte_exact_count': len(old_bytes), 'map_byte_exact_count': len(maps),
            'revision_counts': dict(collections.Counter(r['source_object'].split('_')[0] for r in rows))}


def validate_source_audit_and_seams(manifest):
    audit=load(D/'SOURCE_R18_AUDIT.json'); seam=load(D/'INSTANCE_REPAIR_REVIEW_MANIFEST.json')
    assert audit['source_sha256']==audit['source_hash_after']==SOURCE_SHA
    assert audit['source_bytes']==SOURCE_BYTES
    assert all(audit[k] is True for k in ('prior_1433_source_snapshots_and_matrices_exact','old_material_graphs_exact','R14_packed_maps_match_18_delivery_bytes','R18_final_contact_corrected_vertices_exact','R16_seam_reference_retained_byte_exact','R16_target_private_collection_and_all_instance_pointers_transforms_visibility_match'))
    assert len(audit['old_objects'])==1433 and audit['new_object_count']==196
    assert audit['new_revision_counts']=={'R17':66,'R18':130}
    assert digest_file(D/'INSTANCE_REPAIR_REVIEW_MANIFEST.json')==digest_file(PRIOR/'INSTANCE_REPAIR_REVIEW_MANIFEST.json')
    assert seam['status']=='BLOCKED_LOCAL_PER_INSTANCE_RENDERER_MAPPING' and seam['automatic_seam_replacement_allowed'] is False
    assert seam['local_renderer_mapping'] is None and seam['local_repair_applied'] is False
    assert (seam['original_source_count'],seam['preserved_nonseam_count'],seam['omitted_target_occurrence_count'])==(144,130,14)
    assert seam['source_target']=='B_R06_SOUTHWEST_RIM_EB01_01' and seam['other_instance_pointers_preserved']==21
    assert len(audit['inherited_delivery_files'])==42
    for f in audit['inherited_delivery_files']:
        assert f['copied_byte_exact'] is True and digest_file(D/f['file'])==f['sha256']
    oldrows={r['source_object']:r for r in load(PRIOR/'EXPORT_MANIFEST.json')['objects']}
    assert {r['source_object'] for r in audit['old_objects']}==set(oldrows)
    for r in audit['old_objects']:
        assert r['source_snapshot_and_world_matrix_exact'] is True
        assert (r['export_object'],r['partition'])==(oldrows[r['source_object']]['export_object'],oldrows[r['source_object']]['partition'])
    added={r['source_object']:r for r in manifest['objects'] if r['source_object'] not in oldrows}
    assert len(audit['new_source_snapshots'])==len(added)
    for r in audit['new_source_snapshots']:
        assert r['source_snapshot']==added[r['source_object']]['source_snapshot'] and r['matrix_world']==added[r['source_object']]['matrix_world']
    contracts=[load(D/'source_contracts'/f'{rev}_ALLOWED_CHANGE_CONTRACT.json') for rev in ('R17','R18')]
    assert {n for c in contracts for n in c['additive_objects']}==set(added)
    assert audit['new_partition_counts']==dict(collections.Counter(r['partition'] for r in added.values()))
    r17=load(D/'source_contracts/R17_INDEPENDENT_ACCEPTANCE.json');r18=load(D/'source_contracts/R18_INDEPENDENT_VERIFICATION.json')
    assert r17['outcome']==r18['outcome']=='PASS' and not r17['failed_checks'] and not r18['failed_checks']
    assert r18['source_sha256']==r17['candidate_sha256'] and r18['candidate_sha256']==SOURCE_SHA
    fix=load(D/'source_contracts/R18_IDENTIFIER_CONTACT_FINISH.json')
    assert fix==audit['R18_contact_correction'] and fix['source_sha256_after']==SOURCE_SHA
    assert fix['changed_vertices']==4 and fix['target']=='R18_Service_South_Identifier_Stripe'
    scopes={x['id']:x for x in manifest['review_scopes']}
    assert scopes['ADDITIVE_DISPLAY']['objects']==1629 and scopes['ADDITIVE_DISPLAY']['seam_override_included'] is False
    assert scopes['TARGET_INSTANCE_SEAM_OVERRIDE']['automatic_apply'] is False and scopes['TARGET_INSTANCE_SEAM_OVERRIDE']['mesh_payloads']==0
    return {'status':'PASS_SCOPED_SOURCE_AND_REVIEW_CONTRACT','actual_source_counts':audit['actual_source_counts'],'old_objects_exact':1433,'new_revision_counts':audit['new_revision_counts'],'new_partition_counts':audit['new_partition_counts'],'final_R18_contact_correction_verified':True,'seam_reference_bytes_preserved':True,'automatic_seam_operation':'BLOCKED_UNVERIFIED_LOCAL_RENDERER_SUBMESH_OWNERSHIP','local_Unity_evidence':False}


def main():
    assert os.environ.get('MOONKOV_R18_EXPORT_READY') == '1', 'Export completion and explicit readiness flag are required before the Blender run.'
    assert bpy.app.version == (4, 3, 2)
    assert 'CUMULATIVE_R09_R18_EXPORT_READY' in (D / 'export.log').read_text().splitlines()
    before = digest_file(SOURCE)
    assert before == SOURCE_SHA and SOURCE.stat().st_size == SOURCE_BYTES
    manifest = load(D / 'EXPORT_MANIFEST.json')
    rows, parts, grouped, scope = validate_manifest(manifest)
    seam_review = validate_source_audit_and_seams(manifest)
    protected_inputs = [D / 'EXPORT_MANIFEST.json', D / 'SOURCE_R18_AUDIT.json', D / 'INSTANCE_REPAIR_REVIEW_MANIFEST.json']
    input_hashes = {str(p.relative_to(D)): digest_file(p) for p in protected_inputs}
    report_dir = D / 'independent_reimport_validation'
    report_dir.mkdir(exist_ok=True)
    summary = {'schema': 'serial_r09_r18_validation_v1', 'status': 'RUNNING',
               'scope': 'Blender FBX integrity and conservative review handoff only; not Unity acceptance.',
               'source_sha256_before': before, 'source_bytes': SOURCE_BYTES, 'scope_checks': scope,
               'instance_override_review': seam_review, 'partitions': [], 'failures': [],
               'binary_tangent_quality_review': [], 'preserved_uv_quality_review': [], 'generated_uv_issues': [],
               'signed_zero_only_uv_equivalences': [], 'reimport_geometry_degenerate_triangles_at_area2_1e_12': 0,
               'reimport_geometry_degeneracy_quality_review': [],
               'input_sha256_before': input_hashes, 'blender': bpy.app.version_string}
    totals = collections.Counter()
    vector_totals = {k: collections.Counter() for k in ('tangent_layers', 'binormal_layers', 'normal_layers')}
    common_neutral = None
    for p in parts:
        pname = p['name']
        expected = grouped[pname]
        print('INDEPENDENT_PARTITION_BEGIN', pname, len(expected), flush=True)
        report = {'partition': pname, 'file': p['file'], 'status': 'RUNNING', 'issues': [], 'objects': []}
        path = D / p['file']
        try:
            assert digest_file(path) == p['sha256'] and path.stat().st_size == p['bytes']
            report['fbx_global_settings'] = read_fbx_global_settings(path)
            report['binary_geometry'] = validate_binary_geometry(path, expected)
            report['binary_attributes'] = validate_binary_attributes(path, expected)
            if common_neutral is None:
                common_neutral = report['binary_attributes']['neutral_binary_properties']
            assert report['binary_attributes']['neutral_binary_properties'] == common_neutral
            lookup = {r['export_object']: r for r in expected}
            for g in report['binary_geometry']['objects']:
                for key, counts in vector_totals.items():
                    for layer in g[key]:
                        for metric in ('vectors', 'zero_vectors', 'nonunit_vectors'):
                            counts[metric] += layer[metric]
                affected = [l for l in g['tangent_layers'] if l['zero_vectors'] or l['nonunit_vectors']]
                if affected:
                    summary['binary_tangent_quality_review'].append({'partition': pname, 'source_object': lookup[g['object']]['source_object'], 'object': g['object'], 'layers': affected,
                        'status': 'REVIEW_REQUIRED_NOT_NORMAL_MAP_READY'})
            bpy.ops.wm.read_factory_settings(use_empty=True)
            assert len(bpy.data.objects) == 0
            report['factory_empty_objects_before_import'] = 0
            assert bpy.ops.import_scene.fbx(filepath=str(path), **IMPORT_SETTINGS) == {'FINISHED'}
            bpy.context.view_layer.update()
            actual = {o.name: o for o in bpy.context.scene.objects}
            assert len(actual) == len(expected) and set(actual) == {r['export_object'] for r in expected}
            assert all(o.type == 'MESH' for o in actual.values())
            assert not any(n.type == 'TEX_IMAGE' for m in bpy.data.materials if m.node_tree for n in m.node_tree.nodes)
            assert not any(i.filepath for i in bpy.data.images)
            depsgraph = bpy.context.evaluated_depsgraph_get()
            for row in expected:
                detail = validate_object(row, actual[row['export_object']], depsgraph)
                report['objects'].append(detail)
                if detail['status'] != 'PASS':
                    summary['failures'].append({'partition': pname, 'object': row['export_object'], 'checks': detail['failed_checks']})
                for k in ('vertices', 'polygons', 'loops', 'triangles'):
                    totals[k] += detail['actual'][k]
                summary['reimport_geometry_degenerate_triangles_at_area2_1e_12'] += detail['actual']['geometry_degenerate_triangle_count_at_1e_12']
                if detail['actual']['geometry_degenerate_triangle_count_at_1e_12']:
                    summary['reimport_geometry_degeneracy_quality_review'].append({'partition': pname, 'source_object': row['source_object'], 'object': row['export_object'], 'triangles': detail['actual']['geometry_degenerate_triangle_indices_at_1e_12'], 'count': detail['actual']['geometry_degenerate_triangle_count_at_1e_12'], 'threshold': 'reimported local triangle cross-product magnitude area2 <= 1e-12', 'status': 'REVIEW_REQUIRED_GEOMETRY_QUALITY_NOT_SERIALIZATION_FAILURE'})
                for uv in detail['uv_comparison']:
                    if uv['signed_zero_only_equivalent']:
                        summary['signed_zero_only_uv_equivalences'].append({'object': row['export_object'], 'layer': uv['name']})
                for uv in row['export_snapshot']['uv_layers']:
                    if uv['nonzero_geometry_triangles_with_zero_uv_area']:
                        key = 'preserved_uv_quality_review' if row['uv_policy'] == 'preserved_existing_layers_unchanged' else 'generated_uv_issues'
                        summary[key].append({'partition': pname, 'source_object': row['source_object'], 'object': row['export_object'], 'layer': uv['name'], 'nonzero_geometry_triangles_with_zero_uv_area': uv['nonzero_geometry_triangles_with_zero_uv_area'], 'uv_sha256_float32': uv['sha256_float32']})
            assert digest_file(path) == p['sha256']
            report['status'] = 'PASS' if len(report['objects']) == len(expected) and all(o['status'] == 'PASS' for o in report['objects']) else 'FAIL'
        except Exception as exc:
            report['status'] = 'ERROR'
            report['issues'].append(repr(exc))
            report['traceback'] = traceback.format_exc()
            summary['failures'].append({'partition': pname, 'error': repr(exc)})
        write_json(report_dir / (pname + '.json'), report)
        concise = {'partition': pname, 'status': report['status'], 'objects': len(report['objects']),
                   'objects_passed': sum(o['status'] == 'PASS' for o in report['objects']), 'issues': report['issues']}
        summary['partitions'].append(concise)
        write_json(D / 'R18_SERIAL_VALIDATION_REVIEW.json', summary)
        print('INDEPENDENT_PARTITION_DONE', json.dumps(concise), flush=True)
    prior_review = load(PRIOR / 'INDEPENDENT_R16_VALIDATION_REVIEW.json')
    expected_tangents = {r['source_object']: sum(l['zero_vectors'] for l in r['layers']) for r in prior_review['binary_tangent_quality_review']}
    actual_tangents = {r['source_object']: sum(l['zero_vectors'] for l in r['layers']) for r in summary['binary_tangent_quality_review']}
    summary['known_R11_binary_tangent_gates_preserved'] = all(actual_tangents.get(n) == count for n, count in expected_tangents.items())
    expected_uv = {r['source_object']: r for r in prior_review['preserved_uv_quality_review']}
    actual_uv = {r['source_object']: r for r in summary['preserved_uv_quality_review']}
    summary['known_R15_R16_preserved_UV_gates_exact'] = all(actual_uv.get(n) == r for n, r in expected_uv.items())
    summary['geometry_totals'] = dict(totals)
    summary['binary_vector_totals'] = {k: dict(v) for k, v in vector_totals.items()}
    summary['neutral_binary_properties'] = common_neutral
    summary['source_sha256_after'] = digest_file(SOURCE)
    summary['source_unchanged'] = summary['source_sha256_after'] == before == SOURCE_SHA
    summary['protected_inputs_unchanged'] = all(digest_file(D / rel) == sha for rel, sha in input_hashes.items())
    summary['objects_passed'] = sum(p['objects_passed'] for p in summary['partitions'])
    summary['partitions_passed'] = sum(p['status'] == 'PASS' for p in summary['partitions'])
    expected_totals = {k: sum(r['export_snapshot'][k] for r in rows) for k in ('vertices', 'polygons', 'loops', 'triangles')}
    summary['expected_geometry_totals'] = expected_totals
    summary['geometry_totals_match'] = dict(totals) == expected_totals
    required = ('known_R11_binary_tangent_gates_preserved', 'known_R15_R16_preserved_UV_gates_exact', 'source_unchanged', 'protected_inputs_unchanged', 'geometry_totals_match')
    summary['roundtrip_integrity_status'] = 'PASS' if not summary['failures'] and summary['objects_passed'] == EXPECTED_OBJECTS and summary['partitions_passed'] == EXPECTED_PARTITIONS and all(summary[k] for k in required) and not summary['generated_uv_issues'] else 'FAIL'
    summary['status'] = 'PASS_BLENDER_INTEGRITY_WITH_QUALITY_REVIEW' if summary['roundtrip_integrity_status'] == 'PASS' else 'FAIL'
    summary['automatic_instance_override_status'] = 'BLOCKED_UNVERIFIED_LOCAL_RENDERER_SUBMESH_OWNERSHIP'
    summary['Unity_acceptance_status'] = 'NOT_TESTED_NOT_ACCEPTED'
    summary['limits'] = [
        'Only Blender FBX serialization and factory-empty reimport integrity are accepted here, not Unity import, shader/visual parity, runtime or performance.',
        'No author .blend was opened, saved or modified by this serial roundtrip validator; hash checked before and after.',
        'Live source audit is reviewed against its recorded source SHA; this validator does not repeat its source .blend reopening.',
        'Existing R11 binary zero tangent/binormal vectors and R15 collapsed label UVs remain explicit quality gates; importer recalculation is not a delivered-binary repair.',
        'Additive display FBXs do not encode suppressions of legacy target-instance seams. Applying additions alone can leave the legacy rods visible.',
        'Local target renderer/submesh, batching, collider ownership and reverse mappings are unverified. Do not replace global EB01/shared sources or modify colliders.',
        'Current local lunar materials, textures and shaders must remain unchanged. Neutral material identities are not translated shaders.',
        'No render, source save/edit, user computer, Unity, upload or installation was used.'
    ]
    write_json(D / 'R18_SERIAL_VALIDATION_REVIEW.json', summary)
    txt = [summary['status'], f"Factory-empty partitions: {summary['partitions_passed']}/{EXPECTED_PARTITIONS}; objects: {summary['objects_passed']}/{EXPECTED_OBJECTS}.",
           'Geometry totals: ' + json.dumps(summary['geometry_totals'], sort_keys=True),
           'Old FBX and compact maps preserved byte-exact: 24 FBXs, 18 maps.',
           f"Binary tangent quality review objects: {len(summary['binary_tangent_quality_review'])}; preserved UV review objects: {len(summary['preserved_uv_quality_review'])}.",
           'Source SHA256 unchanged: ' + str(summary['source_unchanged']) + ' (' + summary['source_sha256_after'] + ').',
           'Instance-specific seam override: BLOCKED. Unity acceptance: NOT TESTED.', *summary['limits']]
    (D / 'R18_SERIAL_VALIDATION_REVIEW.txt').write_text('\n'.join(txt) + '\n')
    print('\n'.join(txt), flush=True)
    assert summary['roundtrip_integrity_status'] == 'PASS', 'Serial validation failed.'


if __name__ == '__main__':
    main()
