# R09–R18 material review contract

All 33 FBXs contain neutral identity-only placeholders, with exact material names and per-face assignments. Do not apply their grey appearance or cloud numeric source settings to existing local materials. Current lunar materials and all earlier local material choices take precedence. This package cannot verify local renderer/material ownership.

The cumulative scope uses the same 15 material identities as R09–R16. R17 and R18 add no new material definitions or image dependencies. Protected source-slot references total 190: R23_Matte_Deck_Fine_Finish 59, R24_Slate_Gray_Industrial_Enamel 123, R24_Service_Stencil_Offwhite 8. These are identity references only; preserve verified current local mappings. MATERIAL_SLOT_MAPPING.csv lists exact object/slot references. Source graph identity is verified; target-engine shader translation is NOT. Existing source shader/image dependencies are retained as provenance only, never silently approximated.

## Compact R14 maps

All 18 supplied PNGs match the previous delivery and the current saved source packed bytes exactly. The 160 R13 gallery mesh snapshots, including R14_SurfaceUV, remain exact. No UV regeneration, texture resampling, material rebinding or file substitution was performed. Apply only to the exact original object/face families in `source_contracts/R14_MATERIAL_ASSIGNMENT_MANIFEST.json` and `R14_TEXTURE_MANIFEST.json`; these unique per-face atlas maps are not a general tileable replacement for earlier materials.

- BaseColor: sRGB RGB, neutral white tint, opaque alpha 1. No alpha/smoothness data is present.
- ORM: linear/Non-Color. G is roughness, B metallic. Convert smoothness as 1-G and pack only to the target shader's documented expected channel. ORM R is contact occlusion data but is NOT connected in the Blender reference; leave it disabled for closest reference parity. Do not multiply it into BaseColor.
- Normal: linear tangent-space OpenGL +Y RGB, source strength 1. Import as a normal texture. Flip G only if the verified target convention requires it. Validate target triangulation, imported normals and tangent basis independently.
- Explicit R14_SurfaceUV and clamp/edge sampling are required. No UV scaling/offset or extra runtime detail map. Mips/compression remain target-engine review items.
- Source roughness/metallic is image-driven. Unlinked scalar defaults and viewport diffuse colors are provenance, not substitution values.

The six family sizes are cladding/steel/dark assembly 1024×1024 per map, exposed alloy 1024×512, orange/mineral 512×128. All 18 PNGs total 755,055 bytes. Existing source memory budgets are arithmetic estimates, not measured Unity memory. No high-resolution duplicate maps are bundled.

R23's referenced old roughness texture is deliberately not bundled or rebound; its source graph's UVMap request is not reproduced by export-only generated UV0. The existing R24 source graphs are also not target shader recipes. Do not automatically reconstruct protected materials from the provenance in `EXPORT_MANIFEST.json`.

Known R11 tangent and R15/R16 lettering UV gates remain in `MANUAL_REVIEW_GATES.json`. Geometry/UV byte preservation does not establish normal-map readiness or shader visual parity. No automatic material binding, texture import, global material replacement or lunar-material restoration is permitted.
