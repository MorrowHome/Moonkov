# Moonkov R09–R18 cumulative display review handoff

One additive display asset handoff, not a new full-map model revision, complete rendered-state replacement, or Unity acceptance. The frozen final R18 source was only read; no source save, render, new modeling, local-PC, Unity, Git, Host, runtime, install, download or upload action was performed.

## Current payload

- 1,629 display mesh objects in 33 FBX partitions. Existing 1,433 rows/stable IDs and all 24 R09–R16 FBXs are preserved exactly.
- Only 66 R17 workcell meshes (3 partitions) and 130 final R18 service-house meshes (6 partitions) are newly exported.
- 18 compact R14 maps, 755,055 bytes, retained byte-exact with existing R14 UVs. No high-resolution duplicates, re-atlasing, UV repair of old layers, or new image dependencies.
- 15 inherited material identities. FBX materials are neutral grey identity-only placeholders, never shader translations. 190 protected R23/R24 slot references require verified local bindings.
- The source actually contains 8,599 object datablocks, 8,387 mesh-type object datablocks, 6,906 mesh datablocks, 182 materials and 120 images. These are different quantities, not export totals.
- One package only. No full .blend, prior per-version ZIP, old backup or preview image is duplicated.

## Source and evidence authority

Final R18: Moonkov_Rebuild_R18_West_Service_House_FULL_EDITABLE.blend, SHA256 d840a1ad99f65a153f7bda34d73adbb830b7d1cad5654d3270f5cd23c6f788e0, 308,488,076 bytes.

Prior cumulative ZIP SHA256: 6978ccd76f57cb2823a6d954f0abc11dc0522e1587841338304850842279b541. SOURCE_R18_AUDIT.json records the current measured source scope; historical source independent reports retain their own hashes. R18_SERIAL_VALIDATION_REVIEW.json records current clean FBX reimport, not inherited source acceptance. R18_INDEPENDENT_METADATA_REVIEW.json reviews finalized evidence and protection contracts. PACKAGE_CONTENTS.json inventories the final files.

The final R18 stripe is corrected: four hidden rear vertices of R18_Service_South_Identifier_Stripe extend to Y2253.419921875, providing 20.01953125 mm overlap into R18_Wall_South_Vent_Header. The visible front and silhouette are unchanged. Source contracts preserve the exact correction and final review mapping. Existing R18 previews and R18_SAVED_GEOMETRY_QA.json refer to the pre-correction candidate; no rerender was done, and those previews are not bundled or presented as final-source evidence.

## Clean verification, not visual/runtime acceptance

Current validation reimports each of the 33 FBXs serially into a factory-empty scene, with one Blender process and two CPU threads. It checks stable object identity, finite vertices, exact local float32 geometry, polygon/loop topology, per-face material identities, UV order/values, binary tangent/normal/binormal arrays, transforms/pivots and world bounds, and exact prior FBX/map hashes. UV signed-zero equivalence is separately proven by canonical-zero hashes. World-bound and pivot tolerance is 0.005 m; linear transform absolute/relative tolerances are 1e-5 / 1e-6. New geometry is evaluated from the final source; only absent UV0 and n-gon splitting use transient export copies. Existing UVs remain unchanged by explicit corner mapping.

This is finite serialization evidence. It does not verify Unity import, local shader appearance, continuous capsule clearance, collision, NavMesh, runtime, performance, accessibility, building code, structural safety or machine safety. No unrelated full-map QA was repeated.

## Mandatory local protection contract

Preserve the user's current lunar material, textures and shader settings, all existing local material bindings, baked MC00 lighting, optimized static chunks, indoor culling, rock LOD, 118 light IDs, 135 button IDs, and every old R08 collider. Do not restore cloud lunar materials or import cloud material parameters over local choices. Do not create, delete, replace, regenerate or remap colliders from this art package. These are integration constraints, not a claim that local state was visited or tested.

Use one current cumulative display source. If earlier additions are already present locally, reconcile stable IDs and material assignments before separately authorized small display changes. Never blindly append this whole payload on top of a prior cumulative package or remove old objects by broad name matching. The package does not replace R08 baseline or author assets.

## R16 seam operation remains BLOCKED

INSTANCE_REPAIR_REVIEW_MANIFEST.json is retained byte-for-byte as historical R16 cloud reference. The current source audit verifies its target pointer, non-seam membership and instance transforms/visibility are still retained. It is NOT a Unity selection map or an executable cleanup command.

Only B_R06_SOUTHWEST_RIM_EB01_01 has a cloud private collection linking the same 130 non-seam source objects instead of all 144. The 14 source rods remain in the original shared collection; all other 21 instance pointers remain. Additive FBXs do not suppress legacy local rods. Automatic seam removal/hiding/replacement remains BLOCKED until a verified local per-instance renderer/submesh/combined-triangle ownership map and scoped rollback plan exist. Source names, nearby coordinates, or successful FBX import do not remove this gate. Never globally hide/delete shared source names, alter shared meshes for other instances, or touch old colliders.

## Geometry use and access limits

R17 is a single workcell on the original floor. Main central route is 2.60 m, separate west bypass approximately 2.646 m and front receiving depth approximately 6.007 m. Its 1.40 m nominal operator/service aisle is NOT the main combat/cooperative route. Source evidence has 14 floor-bearing seeds, 172 contact edges, 112 route rays and 44 floor samples. Rear spacing is approximately 4.53 m by the producer's rear-wall plane definition; independent measurement uses a different datum (4.5428 m), not a discrepancy to silently merge.

R18 is one split-grade storey with lower/upper room floors Z204.40 / Z205.30 m joined by 5 interior steps. It is lateral cover and an intermediate destination, not a second storey or a break in the straight street's longitudinal sightline. Final static source evidence has 130 meshes, 47 terrain-bearing seeds, 347 contact edges and 167 walking samples. Original DEM/display terrain is unmodified.

Access is a 1.80 m building-only branch: 10 crossfall-following shoulder steps to Z202.20 m landing, then 13 solid steps to the lower entrance and 5 steps to the upper court. Door openings are about 1.80 × 2.595 m; no interactive door leaves are supplied. The 4.40 m building setback is NOT an empty shoulder: access steps occupy a 1.80 m strip. P01 nominal 7.20 m pavement is retained (one inherited measured section is 7.198917 m). P02/P04/P05/P07 protections are scoped source/local occupancy evidence, not a full-map route recertification. South/north Cover Link gaps are approximately 3.296 / 3.700 m. No accessibility claim is made.

## Still-open quality gates

See QUALITY_GATES_EXACT.json and MANUAL_REVIEW_GATES.json for exact objects, loop/triangle IDs and thresholds. Inherited R11 binary tangent issues, R15/R16 collapsed lettering UVs, and near-degenerate R16 lettering geometry remain deliberately unchanged. Importer-recomputed tangents do not repair delivered binary tangent vectors. Geometry preservation is not normal-map readiness. The inherited IdentityPlate obstruction of the upper loading shell is not corrected. R14 channel packing, color space, target tangent convention, compression, triangulation and local lighting remain manual target-engine review items.

See MATERIAL_TRANSFER_GUIDE.md and LOCAL_REVIEW_CHECKLIST_ZH.md before any separately authorized integration. This package grants no automatic import or seam cleanup authority.
