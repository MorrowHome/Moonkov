"""Finalize current-scope review metadata after serial validation, without Blender or delivery."""
from pathlib import Path
import json,collections,hashlib
D=Path(__file__).resolve().parent
load=lambda n:json.loads((D/n).read_text())
def digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2,allow_nan=False))
m=load('EXPORT_MANIFEST.json');q=load('R18_SERIAL_VALIDATION_REVIEW.json');a=load('SOURCE_R18_AUDIT.json');old=load('source_contracts/PRIOR_R09_R16_EXPORT_MANIFEST.json')
assert q['status']=='PASS_BLENDER_INTEGRITY_WITH_QUALITY_REVIEW'
assert q['objects_passed']==len(m['objects'])==1629 and q['partitions_passed']==len(m['partitions'])==33
assert q['source_unchanged'] is True and q['protected_inputs_unchanged'] is True
assert all(digest(D/rel)==sha for rel,sha in q['input_sha256_before'].items())
assert digest(Path(m['source']))==m['source_sha256']
oldnames={r['source_object'] for r in old['objects']};newnames={r['source_object'] for r in m['objects']}-oldnames
assert len(newnames)==196
quality={'status':'EXACT_OPEN_REVIEW_GATES_NOT_RUNTIME_ACCEPTANCE','source_sha256':m['source_sha256'],'binary_tangent_quality_review':q['binary_tangent_quality_review'],'preserved_uv_quality_review':q['preserved_uv_quality_review'],'near_degenerate_local_geometry_review':q['reimport_geometry_degeneracy_quality_review'],'near_degenerate_triangle_area2_threshold':1e-12,'new_R17_R18_quality_gate_objects':[r['source_object'] for k in ('binary_tangent_quality_review','preserved_uv_quality_review','reimport_geometry_degeneracy_quality_review') for r in q[k] if r['source_object'] in newnames],'generated_uv_issues':q['generated_uv_issues'],'shader_visual_acceptance':False,'automatic_uv_or_geometry_repair_allowed':False,'importer_recomputed_tangents_are_not_delivered_binary_repair':True}
quality['totals']={'binary_tangent_objects':len(q['binary_tangent_quality_review']),'binary_zero_tangent_vectors':sum(l['zero_vectors'] for r in q['binary_tangent_quality_review'] for l in r['layers']),'collapsed_UV_objects':len(q['preserved_uv_quality_review']),'collapsed_UV_triangles_by_revision':dict(collections.Counter({rev:sum(r['nonzero_geometry_triangles_with_zero_uv_area'] for r in q['preserved_uv_quality_review'] if r['source_object'].startswith(rev+'_')) for rev in ('R15','R16')})),'near_degenerate_geometry_objects':len(q['reimport_geometry_degeneracy_quality_review']),'near_degenerate_geometry_triangles':q['reimport_geometry_degenerate_triangles_at_area2_1e_12']}
assert quality['totals']=={'binary_tangent_objects':3,'binary_zero_tangent_vectors':4,'collapsed_UV_objects':8,'collapsed_UV_triangles_by_revision':{'R15':522,'R16':1872},'near_degenerate_geometry_objects':4,'near_degenerate_geometry_triangles':9}
assert quality['new_R17_R18_quality_gate_objects']==[] and quality['generated_uv_issues']==[]
write('QUALITY_GATES_EXACT.json',quality)
gate=load('MANUAL_REVIEW_GATES.json');gate['exact_binary_and_clean_reimport_gates']='QUALITY_GATES_EXACT.json';gate['near_degenerate_geometry_review']=q['reimport_geometry_degeneracy_quality_review'];gate['new_R17_R18_open_mesh_UV_tangent_gate_objects']=[];gate['new_geometry_serialization_PASS_is_not_Unity_acceptance']=True;write('MANUAL_REVIEW_GATES.json',gate)
summary={'status':'REVIEW_READY_WITH_EXPLICIT_QUALITY_AND_LOCAL_MAPPING_GATES','scope':'One cumulative R09–R18 display asset export. No new full-map revision or Unity acceptance.','source':m['source'],'source_sha256':m['source_sha256'],'source_bytes':m['source_bytes'],'actual_source_counts':a['actual_source_counts'],'objects':len(m['objects']),'partitions':len(m['partitions']),'inherited_objects_exact':len(old['objects']),'inherited_FBX_files_byte_exact':len(old['partitions']),'new_revision_counts':a['new_revision_counts'],'new_partition_counts':a['new_partition_counts'],'compact_R14_maps_exact':len(m['images']),'compact_map_bytes':sum(i['bytes'] for i in m['images']),'material_identities':len(m['materials']),'protected_local_slot_references':len(m['local_material_protection']['protected_slot_references']),'geometry_totals':q['geometry_totals'],'serial_validation':{'status':q['status'],'partitions_passed':q['partitions_passed'],'objects_passed':q['objects_passed'],'source_unchanged':q['source_unchanged'],'new_R17_R18_gate_objects':[]},'quality_gates':quality['totals'],'seam_override':'BLOCKED_UNVERIFIED_LOCAL_PER_INSTANCE_RENDERER_SUBMESH_OWNERSHIP','seam_manifest_role':'byte-exact historical R16 cloud reference, not executable Unity mapping','final_R18_contact_correction_exported':True,'old_R18_previews_not_rerendered_or_bundled':True,'local_computer_Unity_Git_Host_runtime_actions':False,'source_saved_or_rendered':False,'full_map_QA_repeated':False,'automatic_integration_allowed':False,'source_contracts_are_historical_not_new_full_scene_QA':True}
write('HANDOFF_SUMMARY.json',summary)
text='''One cumulative R09–R18 display review package; not a new full-map model version or Unity acceptance.
1,629 meshes / 33 FBX partitions: inherited 1,433 objects + 66 R17 workcell + 130 final R18 service-house objects.
All 24 prior FBXs, 1,433 prior stable IDs/rows and 18 compact R14 maps preserved exactly.
Serial factory-empty Blender roundtrip: 33/33 partitions and 1,629/1,629 objects pass integrity checks; 64,418 vertices / 66,274 polygons / 253,943 loops / 121,395 triangles.
R18 final four-vertex hidden stripe contact correction is included; old pre-correction previews were not rerendered or bundled.
15 material identities, 190 protected R23/R24 slot references; neutral FBX materials are identity placeholders, not shader translations.
R16 seam reference retained byte-exact and review-only: 144 shared objects -> same 130 non-seam objects in one private target instance, 14 target occurrences omitted only in cloud source. No shared-source deletion.
Automatic seam repair BLOCKED on verified local per-instance renderer/submesh ownership. Additive FBXs alone do not remove old rods. All old colliders remain protected.
Open quality gates: 4 zero tangent corners in 3 R11 objects; 522 collapsed-UV triangles in 3 R15 labels and 1,872 in 5 R16 labels; 9 local-area2<=1e-12 triangles in 4 R16 labels. No new R17/R18 mesh/UV/tangent integrity gate detected.
R17 1.40 m operator aisle is not the 2.60 m main route. R18 is single-storey split-grade and lateral cover only, with building-only access stairs, not an accessibility or runtime claim.
Current lunar material, all local optimizations, existing material mappings, 118 lights, 135 buttons and every old R08 collider must remain unchanged.
Source actually has 8,599 object datablocks, 8,387 mesh-type objects, 6,906 mesh datablocks, 182 materials and 120 images; these are not export counts.
Source SHA unchanged: d840a1ad99f65a153f7bda34d73adbb830b7d1cad5654d3270f5cd23c6f788e0.
No source save/render/model edits, local PC, Unity, Git, Host, runtime, install, asset download or upload. Static export preparation only.
'''
(D/'HANDOFF_SUMMARY.txt').write_text(text)
write('PRESERVATION_CHECKSUMS.json',{'current_source_sha256':m['source_sha256'],'previous_cumulative_zip_sha256':'6978ccd76f57cb2823a6d954f0abc11dc0522e1587841338304850842279b541','inherited_files':m['inherited_delivery_files_preserved'],'R16_seam_manifest_sha256':digest(D/'INSTANCE_REPAIR_REVIEW_MANIFEST.json'),'old_manifest_rows_exact':1433,'current_source_hash_after':digest(Path(m['source']))})
print(text)
