MOONKOV R17 — WEST FABRICATION WORKCELL

Full editable model:
Moonkov_Rebuild_R17_Fabrication_Workcell_FULL_EDITABLE.blend

Frozen input:
../moonkov_rebuild_R16_fabrication_service_gallery_20261020/Moonkov_Rebuild_R16_Fabrication_Service_Gallery_FULL_EDITABLE.blend
Input SHA256: 39abbbcd746fb8eb8c0c2fa30b750cefc0085905c7d1fbb3f64ead4051b0609a
Read R17_SAVED_CANDIDATE.json for the final R17 hash and stage.

ONE BOUNDED INTERIOR WORKCELL
A single 6.55 m wide by 9.41 m long west-side fabrication workcell adds a deep, floor-bearing fixture bed, captive blank and guides, a short massive machine portal with rectangular ram/tool holder, an integrated rear drive, and substantial stepped protective shielding. This is architectural/industrial workflow blocking, not a tank grouping, wall texture pass, scattered equipment pack or second canopy.

Platform-frame envelope: x = -10.45 to -3.90; y = -14.00 to -4.59; z = 0.467985 to 4.85 m. There are 66 new editable meshes in three separable subcollections under R17_EB01_01_WEST_FABRICATION_WORKCELL. The existing original floor remains the walking surface. Existing materials are reused; no material, texture or lighting definitions are added.

The new opaque guards have real thickness, independently grounded deep ribs and stepped/tapered ends. The low front feed cradle remains six metres inside the loading entrance. Its impact lip has a real 20 mm projection and intersects its structural receiver, rather than sitting wholly inside the beam. The fixed blank rests in supported locators on the actual machine bed. No movement, operating hazard, functional safety or gameplay behavior is implied.

DISTINCT CIRCULATION
- Main front-to-rear route: preserved x = -1.3 to +1.3 m, 2.6 m wide, aligned with existing central personnel openings.
- West perimeter bypass: minimum 2.646 m to retained column faces, separate from machine operation space.
- Front receiving area: about 6.01 m between the inner loading facade and cell front.
- Rear crossflow: about 4.53 m from cell rear to the rear wall plane, connected to the original rear opening.
- Internal operator/service aisle: minimum nominal 1.40 m at frame/shield feet. This is deliberately NOT counted as the main combat/cooperative route.
The scoped QA reports measured routes, bearings and evaluated surfaces; it does not imply continuous capsule or runtime clearance.

EXACT PRESERVATION AND REVERSIBILITY
All 8,403 R16 objects and 6,710 R16 meshes, 182 material definitions, 120 images, original texts, cameras, lights, worlds, scene settings and collection states are fingerprinted before building and compared again after reopen. The retained original authored central megastructure's 207 objects are explicitly checked. DEM, mappings, author assets, shared sources, other instances, previous revisions and the R16 corrected support assemblies remain unchanged.

In particular, B_R06_SOUTHWEST_RIM_EB01_01 continues to use R16_EB01_01_PRIVATE_NO_MALFORMED_SEAMS exactly as R16 did. No original-property exception is needed for R17.

To roll back only R17, disable the new R17_EB01_01_WEST_FABRICATION_WORKCELL collection, or open the frozen R16 input. rollback_R17.py disables only this collection and deliberately does not save. No original or earlier work needs deletion. This is the latest editable full copy; no duplicate full blend is included in the source/QA archive.

INDEPENDENT ACCEPTANCE — PASS
All 24 independent checks pass for the frozen candidate and corrected preview. The independently reopened original state is exact. An unchanged unordered bake-pass enum set was canonicalized by sorting, and only the explicitly additive R17 root branch was excluded from the active-layer tree comparison; this is not an original-property exception or model correction. Full results, audit scripts, captured evidence and logs are included under independent_verification/.

EVIDENCE
R17_INPUT_MEASURED_STATE.json: actual R16 reopen, target pointer and measured hall/gallery bounds.
R17_FROZEN_R16_FINGERPRINTS.json: frozen input authored-state fingerprints.
R17_ALLOWED_CHANGE_CONTRACT.json: additions-only scope, zero original-property changes.
R17_WORKCELL_BUILD_REPORT.json: exact new inventory, dimensions, bearings and intent.
R17_SAVED_GEOMETRY_QA.json: reopened original-state comparison, body/floor rays, exact floor-seed bearing, actual evaluated triangle/surface contact graph, new mesh checks.
R17_RENDER_METADATA.json: repeatable player-height broad view and temporary review lighting.
R17_VISUAL_REVIEW.json: actual-pixel review of the sole broad review image.
independent_verification/R17_INDEPENDENT_ACCEPTANCE.json: authoritative independent PASS and exact source/preview hashes.
R17_SOURCE_CONTENTS.json: SHA256 and CRC32 for every packaged source/QA file. The ZIP passes a full CRC integrity test; the blend and sole preview remain separate to avoid duplication.

The review camera is 1.7 m above the retained original floor. The 1152 x 768 image uses 24 CPU Cycles samples. The replacement review uses temporary exposure -1.00 EV, neutral world strength 0.25, and area fills of 3000 W, 2000 W and 1400 W to recover paint/metal detail. It replaces the washed-out first preview at exactly the same camera and sample budget; only one current preview is kept. It is not a polished hero lighting pass. Review camera, lighting and world changes are not saved, and original visibility flags are not altered. One view only; no additional angles.

LIMITS
Static editable artwork and finite geometric evidence only. No Unity collision, NavMesh, runtime interaction, imported game update, structural/mechanical certification or accessibility certification. No stairs, new walkable floor, mezzanine, tank, text labels, new material definitions, animation or hazard mechanics. No local PC, Git, Unity, Host, installs or uploads are part of this revision.
