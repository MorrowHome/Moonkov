"""Package finalized review output once; no external delivery or source modification."""
from pathlib import Path
import json,hashlib,zipfile
D=Path(__file__).resolve().parent
OUT=D.parent/'Moonkov_Cumulative_R09_R18_Display_FBX_Review_Handoff_20261020.zip'
def digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2,allow_nan=False))
assert not OUT.exists(),'Refuse overwrite a published cumulative package'
m=json.loads((D/'EXPORT_MANIFEST.json').read_text());a=json.loads((D/'SOURCE_R18_AUDIT.json').read_text());seam=json.loads((D/'INSTANCE_REPAIR_REVIEW_MANIFEST.json').read_text())
assert digest(Path(m['source']))==m['source_sha256']=='d840a1ad99f65a153f7bda34d73adbb830b7d1cad5654d3270f5cd23c6f788e0'
assert a['source_hash_after']==m['source_sha256'] and seam['automatic_seam_replacement_allowed'] is False
assert len(m['objects'])==1629 and len(m['partitions'])==33 and len(m['images'])==18
for f in m['partitions']+m['images']:
 p=D/f['file'];assert digest(p)==f['sha256'] and p.stat().st_size==f['bytes']
q=json.loads((D/'R18_SERIAL_VALIDATION_REVIEW.json').read_text());assert q['status']=='PASS_BLENDER_INTEGRITY_WITH_QUALITY_REVIEW'
for name,sha in q['input_sha256_before'].items():assert digest(D/name)==sha,('Roundtrip input changed',name)
final=json.loads((D/'R18_INDEPENDENT_METADATA_REVIEW.json').read_text())
assert final['status'].startswith('PASS') and not final['failures'], final['status']
for name,sha in final['input_sha256'].items():assert digest(D/name)==sha,('Final metadata input changed',name)
files=[p for p in sorted(D.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.tmp','.log') and p.name not in ('PACKAGE_CONTENTS.json','ARCHIVE_VERIFICATION.json')]
assert not any(p.suffix in ('.blend','.zip','.blend1') for p in files)
entries=[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]
write('PACKAGE_CONTENTS.json',{'schema':'cumulative_review_package_inventory_v1','files':entries,'excluded_from_manifest':['PACKAGE_CONTENTS.json itself (avoids recursive hash)','ARCHIVE_VERIFICATION.json written outside archive after readback'],'one_cumulative_package':True,'full_editable_source_duplicated':False,'old_backups_duplicated':False})
files.append(D/'PACKAGE_CONTENTS.json')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,D.name+'/'+str(p.relative_to(D)))
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files) and len(set(z.namelist()))==len(files)
 for p in files:assert hashlib.sha256(z.read(D.name+'/'+str(p.relative_to(D)))).hexdigest()==digest(p)
report={'archive':str(OUT),'bytes':OUT.stat().st_size,'sha256':digest(OUT),'files':len(files),'zip_crc_test':'PASS','every_member_sha256_readback':'PASS','source_sha256_after':digest(Path(m['source'])),'scope':'One cumulative R09–R18 review package. No upload or local operation.'}
write('ARCHIVE_VERIFICATION.json',report);print(json.dumps(report,indent=2))
