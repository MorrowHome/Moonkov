"""One cumulative review handoff. Copies source only in memory. NEVER save .blend."""
import bpy,json,hashlib,collections,sys,csv,numpy as np
from pathlib import Path
from mathutils import Matrix,Vector
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from export_helpers import mesh_snapshot,uv_project,repair,arr,sha
from ngon_helpers import split_ngons
SRC=Path(bpy.data.filepath);SHA='d840a1ad99f65a153f7bda34d73adbb830b7d1cad5654d3270f5cd23c6f788e0'
R=D.parent/'moonkov_rebuild_R18_west_service_house_20261020'
def digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,d):(D/n).write_text(json.dumps(d,indent=2,allow_nan=False))
def matrix(m):return [list(x) for x in m]
assert bpy.app.version==(4,3,2)
assert digest(SRC)==SHA and SRC.stat().st_size==308488076
prior=json.loads((D/'source_contracts/PRIOR_R09_R16_EXPORT_MANIFEST.json').read_text())
old=prior['objects'];assert len(old)==1433
bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get()
# Recheck the exact inherited source geometry, UV bytes, material identities and matrices.
old_audit=[]
for r in old:
 o=bpy.data.objects[r['source_object']];assert o.visible_get() and not o.hide_render
 ev=o.evaluated_get(dg);me=ev.to_mesh(preserve_all_data_layers=True,depsgraph=dg)
 try:snap=mesh_snapshot(me,ev.matrix_world)
 finally:ev.to_mesh_clear()
 assert snap==r['source_snapshot'],('Inherited source geometry/UV/material difference',o.name)
 assert matrix(ev.matrix_world)==r['matrix_world'],('Inherited source transform difference',o.name)
 old_audit.append({'source_object':o.name,'export_object':r['export_object'],'partition':r['partition'],'source_snapshot_and_world_matrix_exact':True})
print('R09_R16_SOURCE_REVALIDATED',len(old_audit),flush=True)
file_proof=[]
for p in prior['partitions']+prior['images']:
 f=D/p['file'];assert f.stat().st_size==p['bytes'] and digest(f)==p['sha256'];file_proof.append({'file':p['file'],'bytes':p['bytes'],'sha256':p['sha256'],'copied_byte_exact':True})
for im in prior['images']:
 actual=bpy.data.images[im['source_image']];assert len(actual.packed_files)==1
 payload=actual.packed_files[0].packed_file.data
 assert hashlib.sha256(payload).hexdigest()==im['sha256'] and len(payload)==im['bytes']
print('R14_PACKED_MAPS_AND_INHERITED_DELIVERY_BYTES_EXACT',flush=True)
source_counts={'objects':len(bpy.data.objects),'mesh_datablocks':len(bpy.data.meshes),'mesh_objects':sum(o.type=='MESH' for o in bpy.data.objects),'materials':len(bpy.data.materials),'images':len(bpy.data.images)}
seam=json.loads((D/'INSTANCE_REPAIR_REVIEW_MANIFEST.json').read_text())
t=bpy.data.objects[seam['source_target']];c=bpy.data.collections[seam['original_collection']];pc=bpy.data.collections[seam['private_collection']]
assert t.instance_collection==pc and matrix(t.matrix_world)==seam['target_matrix_world_blender']
assert len(c.objects)==144 and len(pc.objects)==130 and tuple(c.instance_offset)==tuple(pc.instance_offset)==tuple(seam['collection_instance_offset'])
assert sorted(o.name for o in pc.objects)==sorted(r['source_object'] for r in seam['correspondence'] if r['private_collection_contains_same_object_datablock'])
assert all(pc.objects[o.name]==o for o in c.objects if o.name in pc.objects)
for row in seam['instance_inventory']:
 o=bpy.data.objects[row['source_instance_object']]
 assert o.instance_collection.name==row['collection'] and matrix(o.matrix_world)==row['matrix_world']
 assert o.hide_render==row['hide_render'] and o.hide_viewport==row['hide_viewport'] and o.hide_get()==row['hide_get'] and o.visible_get()==row['visible_get']
assert seam['automatic_seam_replacement_allowed'] is False and seam['local_renderer_mapping'] is None
new_contracts=[json.loads((D/'source_contracts'/f'{rev}_ALLOWED_CHANGE_CONTRACT.json').read_text()) for rev in ('R17','R18')]
expected_names={n for c in new_contracts for n in c['additive_objects']}
assert len(expected_names)==sum(len(c['additive_objects']) for c in new_contracts)
gallery=sorted([o for o in bpy.data.objects if o.type=='MESH' and o.name in expected_names],key=lambda o:o.name)
assert {o.name for o in gallery}==expected_names and all(o.visible_get() and not o.hide_render for o in gallery)
assert {o.name for c in new_contracts for o in bpy.data.collections[c['additive_root_collection']].all_objects}==expected_names
assert [sum(o.name.startswith(rev+'_') for o in gallery) for rev in ('R17','R18')]==[66,130]
fix=json.loads((D/'source_contracts/R18_IDENTIFIER_CONTACT_FINISH.json').read_text())
stripe=bpy.data.objects[fix['target']]
assert fix['source_sha256_after']==SHA and [list(v.co) for v in stripe.data.vertices]==fix['updated_vertex_positions']
print('R17_R18_MEASURED_SOURCE_COUNTS',json.dumps(source_counts),len(gallery),flush=True)
new_names={o.name for o in gallery};assert not any(i.is_instance and (i.object.original.name in new_names or (i.parent and i.parent.original.name in new_names)) for i in dg.object_instances)
scene=bpy.data.scenes.new('R17_R18_EXPORT_COPY');scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
rows=[];pending=[];parts=collections.defaultdict(list);proofs=[];repairs=[];matnames={n for r in old for n in r['export_snapshot']['material_slots'] if n}
for o in gallery:
 ev=o.evaluated_get(dg);m=ev.matrix_world.copy();me=bpy.data.meshes.new_from_object(ev,preserve_all_data_layers=True,depsgraph=dg);source=mesh_snapshot(me,m)
 cs=[c.name for c in o.users_collection];pns=[c for c in cs if c.startswith(('R17_WORKCELL_','R18_SERVICE_HOUSE_'))];assert len(pns)==1
 pn=pns[0];name='GX_'+hashlib.sha256(json.dumps([o.name,None,[]],separators=(',',':')).encode()).hexdigest()[:12]+'_'+o.name[:44]
 source_uv=[u.name for u in me.uv_layers];uvpolicy='preserved_existing_layers_unchanged'
 if not source_uv:
  uvpolicy=uv_project(me);me.uv_layers[0].name=o.name.split('_')[0]+'_GameExport_UV0_Box_1LocalUnit'
  pre=mesh_snapshot(me,m)
  if any(u['nonzero_geometry_triangles_with_zero_uv_area'] for u in pre['uv_layers']):
   changed=repair(me);post=mesh_snapshot(me,m);repairs.append({'source_object':o.name,'changed_polygons':changed,'uv_before':pre['uv_layers'],'uv_after':post['uv_layers']});uvpolicy+='__alternate_face_projection'
 pretri=mesh_snapshot(me,m)
 assert {k:v for k,v in pretri.items() if k!='uv_layers'}=={k:v for k,v in source.items() if k!='uv_layers'}
 if source_uv:assert source['uv_layers']==pretri['uv_layers']
 me,pr=split_ngons(me);snap=mesh_snapshot(me,m);assert snap['max_polygon_vertices']<=4
 assert all(u['finite'] for u in snap['uv_layers'])
 if not source_uv:assert all(u['nonzero_geometry_triangles_with_zero_uv_area']==0 for u in snap['uv_layers'])
 try:
  me.calc_tangents(uvmap=me.uv_layers[0].name);tang=arr(me.loops,'tangent',3);bits=arr(me.loops,'bitangent_sign',1);assert np.isfinite(tang).all() and np.isfinite(bits).all()
  zeroids=np.where(np.linalg.norm(tang,axis=1)<=0.9)[0].tolist();xyz=arr(me.vertices,'co',3);tv=arr(me.loop_triangles,'vertices',3,np.int32);tl=arr(me.loop_triangles,'loops',3,np.int32);g=xyz[tv];areas=np.linalg.norm(np.cross(g[:,1]-g[:,0],g[:,2]-g[:,0]),axis=1)
  tangent={'calculated':True,'finite':True,'unit_tangents':not bool(zeroids),'zero_or_nonunit_tangent_loop_indices':zeroids,'loops':len(me.loops),'sha256_float32':sha(tang),'bitangent_sign_sha256':sha(bits),'degenerate_geometry_triangle_indices':np.where(areas<=1e-12)[0].tolist(),'affected_triangles':[{'triangle':int(i),'area2':float(areas[i]),'loops':tl[i].tolist()} for i in np.flatnonzero(np.any(np.isin(tl,zeroids),axis=1))]}
 finally:me.free_tangents()
 row={'revision':o.name.split('_')[0],'source_object':o.name,'source_type':o.type,'source_data':o.data.name,'source_collections':cs,'source_scene_paths':[],'instance_parent':None,'parent_collections':[],'parent_scene_paths':[],'persistent_id':None,'matrix_world':matrix(m),'bounds_blender':snap['world_bounds'],'material_slots':source['material_slots'],'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'uv_layers':[u.name for u in o.data.uv_layers],'source_snapshot':source,'export_object':name,'partition':pn,'source_uv_layers':source_uv,'uv_policy':uvpolicy,'pretri_snapshot':pretri,'export_snapshot':snap,'ngon_export_copy_triangulated':bool(pr),'tangent_check':tangent}
 if pr:pr.update(source_object=o.name,export_object=name,partition=pn,source_pretri_snapshot=pretri,export_snapshot=snap);proofs.append(pr)
 rows.append(row);pending.append((name,me,m,pn));matnames.update(x for x in snap['material_slots'] if x)
assert len({r['export_object'] for r in old+rows})==len(old)+len(gallery)
# Explicit material graph provenance: neutral FBX identity placeholders, never actual source shaders.
materials=[]
for n in sorted(matnames):
 ma=bpy.data.materials[n];nodes=[];links=[]
 if ma.node_tree:
  for no in ma.node_tree.nodes:
   ins=[]
   for index,so in enumerate(no.inputs):
    if hasattr(so,'default_value'):
     v=so.default_value
     try:v=list(v)
     except TypeError:pass
     if isinstance(v,(str,int,float,bool,list)):ins.append({'index':index,'name':so.name,'identifier':so.identifier,'value':v})
   nodes.append({'name':no.name,'type':no.bl_idname,'inputs':ins,'image':no.image.name if hasattr(no,'image') and no.image else None,'uv_map':getattr(no,'uv_map',None),'settings':{k:getattr(no,k) for k in ('operation','blend_type','data_type','interpolation','extension','projection','projection_blend','space','mode') if hasattr(no,k)}})
  links=[{'from':[l.from_node.name,l.from_socket.name],'to':[l.to_node.name,l.to_socket.name]} for l in ma.node_tree.links]
 is_r14=n.startswith('R14_');protected=n.startswith(('R23_','R24_')) or any(t in n.lower() for t in ('regolith','terrain','lunar'));complex_graph=any(x['type'] not in ('ShaderNodeBsdfPrincipled','ShaderNodeOutputMaterial') for x in nodes)
 status='R14_IMAGE_PBR_CONTRACT_REQUIRES_TARGET_SHADER_HOOKUP_REVIEW' if is_r14 else ('EXCLUDED_SOURCE_SETTINGS_PRESERVE_CURRENT_LOCAL_R23_R24' if protected else ('BLOCKER_UNRESOLVED_SHADER_DEPENDENCY' if complex_graph else 'REUSE_VERIFIED_EXISTING_LOCAL_MATERIAL_IDENTITY_OR_REVIEW'))
 materials.append({'source_material':n,'translation_status':status,'automatic_import_allowed':False,'procedural_or_image_translation_unresolved':complex_graph and not is_r14,'fbx_material_role':'Identity-only neutral placeholder. Not a shader translation or material appearance.','diffuse_color_scene_linear_provenance_only':list(ma.diffuse_color),'nodes':nodes,'links':links})
prior_mats={x['source_material']:x for x in prior['materials']}
assert all(m==prior_mats[m['source_material']] for m in materials if m['source_material'] in prior_mats)
assert not ({n['image'] for m in materials for n in m['nodes'] if n['image']}-{i['source_image'] for i in prior['images']+prior['source_image_dependencies_reference_only']}),'New unaccounted image dependency'
stubs={}
for n in sorted({s for r in rows for s in r['export_snapshot']['material_slots'] if s}):
 bpy.data.materials[n].name='EXPORT_MEMORY_ONLY_ORIGINAL_'+n
 stub=bpy.data.materials.new(n);stub.use_nodes=False;stub.diffuse_color=(.5,.5,.5,1);stubs[n]=stub
for r,(name,me,m,pn) in zip(rows,pending):
 for i,n in enumerate(r['export_snapshot']['material_slots']):me.materials[i]=stubs[n]
 o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.matrix_world=m;parts[pn].append(o)
settings=prior['settings'].copy();settings['object_types']=set(settings['object_types']);bpy.context.window.scene=scene;bpy.context.view_layer.update()
newparts=[]
for pn,objects in sorted(parts.items()):
 p=D/'fbx'/(pn+'.fbx');assert not p.exists(),'Refuse overwrite any existing partition'
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0]
 assert bpy.ops.export_scene.fbx(filepath=str(p),**settings)=={'FINISHED'}
 newparts.append({'name':pn,'file':'fbx/'+p.name,'objects':len(objects),'bytes':p.stat().st_size,'sha256':digest(p)});print('R17_R18_EXPORT_PARTITION',pn,len(objects),flush=True)
assert len(newparts)==sum(len(c['additive_collections'])-1 for c in new_contracts)
manifest=dict(prior);allrows=old+rows
policy=prior['integration_policy'].copy();policy.update(cumulative_R09_R18_supersedes_R09_R16=True,automatic_instance_seam_replacement=False,local_per_instance_renderer_mapping_verified=False)
protected=[m['source_material'] for m in materials if m['source_material'].startswith(('R23_','R24_'))]
refs=[{'source_object':r['source_object'],'export_object':r['export_object'],'partition':r['partition'],'source_slot_index':i,'source_material':n,'policy':'EXCLUDED_SOURCE_SETTINGS_MANUAL_PRESERVE_CURRENT_LOCAL_MAPPING_ONLY'} for r in allrows for i,n in enumerate(r['export_snapshot']['material_slots']) if n in protected]
policy['protected_R23_R24_source_material_names']=protected
manifest.update(schema='cumulative_R09_R18_standard_FBX_review_manifest_v1_NOT_native_Unity_contract',status='exported_ready_for_independent_clean_reimport',source=str(SRC),source_bytes=SRC.stat().st_size,source_sha256=SHA,scope=f'One cumulative R09–R18 display review: {len(allrows)} additive meshes in {len(prior["partitions"])+len(newparts)} partitions; separate review-only target-instance seam reference remains BLOCKED on local ownership mapping.',export_scope_visible_occurrences=len(allrows),objects=allrows,partitions=prior['partitions']+newparts,materials=materials,integration_policy=policy,local_material_protection={'current_local_lunar_material_must_not_change':True,'all_existing_source_settings_are_reference_only':True,'protected_slot_references':refs},review_scopes=[{'id':'ADDITIVE_DISPLAY','objects':len(allrows),'inherited_R09_R16':len(old),'new_R17_workcell':sum(r['revision']=='R17' for r in rows),'new_R18_service_house':sum(r['revision']=='R18' for r in rows),'partitions':len(prior['partitions'])+len(newparts),'status':'REVIEW_ONLY_NO_AUTOMATIC_IMPORT','seam_override_included':False},{'id':'TARGET_INSTANCE_SEAM_OVERRIDE','manifest':'INSTANCE_REPAIR_REVIEW_MANIFEST.json','historical_manifest_source_sha256':seam['source_sha256'],'current_source_reference_audit':'SOURCE_R18_AUDIT.json','status':'BLOCKED_LOCAL_PER_INSTANCE_RENDERER_MAPPING','mesh_payloads':0,'automatic_apply':False}],inherited_delivery_files_preserved=file_proof)
manifest['limits']=prior['limits']+['R17 internal operator/service aisle is 1.40 m nominal and is NOT the main route. The preserved central main route is 2.60 m.', 'R18 is single-storey split-grade architecture and lateral cover only, not a two-storey building or a longitudinal street sightline break.', 'R18 uses final corrected stripe back-face geometry. Existing previews are pre-contact-correction and were not rerendered.', 'Static export preparation only: no new full-map revision, local project operation, Unity acceptance, collider or runtime verification.']
manifest['limits']=[x.replace('this package exports gallery display only','this package exports cumulative R09–R18 additive display only') for x in manifest['limits']]
manifest['historical_baseline_provenance']={'source_baseline_sha256_and_baseline_objects_excluded': 'Inherited historical R09–R12 export baseline metadata, retained as provenance only; neither field is the current final R18 source hash/count. Current source_sha256/source_bytes and SOURCE_R18_AUDIT.actual_source_counts are authoritative.'}
manifest['export_copy_uv_repairs']=prior['export_copy_uv_repairs']+repairs
write('EXPORT_MANIFEST.json',manifest)
prior_proofs=json.loads((D/'source_contracts/PRIOR_R09_R16_NGON_EXPORT_COPY_PROOF.json').read_text())
write('NGON_EXPORT_COPY_PROOF.json',{'source_sha256':SHA,'objects':prior_proofs['objects']+proofs,'old_R09_R16_objects':len(prior_proofs['objects']),'new_R17_R18_objects':len(proofs),'export_copy_only':True})
write('GENERATED_UV_REPAIR_PROOF.json',{'source_sha256':SHA,'inherited_repairs_unchanged':prior['export_copy_uv_repairs'],'new_R17_R18_changed_objects':repairs})
write('SOURCE_R18_AUDIT.json',{'status':'PASS_SCOPED_CLOUD_SOURCE_AUDIT','source_sha256':SHA,'source_bytes':SRC.stat().st_size,'actual_source_counts':source_counts,'prior_1433_source_snapshots_and_matrices_exact':True,'old_objects':old_audit,'old_material_graphs_exact':True,'R14_packed_maps_match_18_delivery_bytes':True,'inherited_delivery_files':file_proof,'new_object_count':len(rows),'new_revision_counts':dict(collections.Counter(r['revision'] for r in rows)),'new_partition_counts':dict(collections.Counter(r['partition'] for r in rows)),'new_source_snapshots':[{k:r[k] for k in ('source_object','matrix_world','source_snapshot')} for r in rows],'R18_final_contact_corrected_vertices_exact':True,'R18_contact_correction':fix,'R16_seam_reference_retained_byte_exact':True,'R16_target_private_collection_and_all_instance_pointers_transforms_visibility_match':True,'source_hash_after':digest(SRC),'full_original_source_preservation_evidence':['source_contracts/R17_INDEPENDENT_ACCEPTANCE.json','source_contracts/R18_INDEPENDENT_VERIFICATION.json'],'limits':'Scoped live audit of handoff geometry, transforms, UVs, material graphs, R14 packed maps, final R18 correction and retained R16 seam reference. No repeat of unrelated full-map QA. No local Unity evidence.'})
write('PRESERVE_LOCAL_MATERIAL_CONTRACT.json',{'integration_policy':policy,'protected_slot_references':refs,'source_image_dependencies_reference_only':manifest['source_image_dependencies_reference_only'],'automatic_binding_allowed':False})
for fname,columns in [('OBJECT_MAPPING.csv',['revision','source_object','export_object','partition','matrix_world','source_uv_layers','uv_policy']),('MATERIAL_SLOT_MAPPING.csv',['source_object','export_object','partition','source_slot_index','source_material','review_policy'])]:
 with (D/fname).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(columns)
  for r in allrows:
   if fname.startswith('OBJECT'):w.writerow([json.dumps(r[k]) if isinstance(r[k],(dict,list)) else r[k] for k in columns])
   else:
    for i,n in enumerate(r['export_snapshot']['material_slots']):w.writerow([r['source_object'],r['export_object'],r['partition'],i,n,'R14_EXACT_MAP_CONTRACT_MANUAL_TARGET_SHADER_REVIEW' if n.startswith('R14_') else 'PRESERVE_VERIFIED_LOCAL_MAPPING_NO_SOURCE_SETTING_IMPORT'])
write('MANUAL_REVIEW_GATES.json',{'status':'MANUAL_REVIEW_GATES_NOT_UNITY_ACCEPTANCE','automatic_integration_permitted':False,'seam_repair_status':'BLOCKED_LOCAL_PER_INSTANCE_RENDERER_MAPPING','inherited_gates':'source_contracts/PRIOR_R09_R16_MANUAL_REVIEW_GATES.json','tangent_quality_review':[{'source_object':r['source_object'],'export_object':r['export_object'],'partition':r['partition'],'check':r['tangent_check']} for r in allrows if not r['tangent_check']['unit_tangents']],'preserved_uv_review':[{'source_object':r['source_object'],'export_object':r['export_object'],'partition':r['partition'],'uv_layers':r['export_snapshot']['uv_layers']} for r in allrows if r['source_uv_layers'] and any(u['nonzero_geometry_triangles_with_zero_uv_area'] for u in r['export_snapshot']['uv_layers'])],'all_existing_uvs_preserved':True,'source_never_saved':True,'generated_uv_is_not_authored_texture_or_lightmap_uv':True,'shader_or_runtime_acceptance':False})
assert digest(SRC)==SHA
print('CUMULATIVE_R09_R18_EXPORT_READY',flush=True)
