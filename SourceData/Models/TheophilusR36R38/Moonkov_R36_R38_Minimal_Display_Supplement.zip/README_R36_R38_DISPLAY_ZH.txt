Moonkov｜R36＋R38 小显示补充包
2026-10-15

用途与接入顺序
在已成功应用「Moonkov_R29_To_R35_Minimal_Display_Handoff.zip」的 Blender 工作副本之后，一次加入原 R36 的井口西侧 4 个显示网格和原 R38 的桥端 6 个显示网格。
这不是 R39 美术版本，不是完整场景替换包，也不要求先安装 R37。旧包、源文件和 R38 大候选保持原样。
顺序：保留的 R29 工作副本 → 已完成的 R29→R35 合并包 → 本补充包。
不要在已经单独装过 R36 或 R38 的副本上叠加；遇到同名对象/集合/网格会停止，请改用尚未加入本补充组的 R35 工作副本。

本包内容
- Moonkov_R36_R38_Ten_Display_Meshes.blend：10 个显示网格、2 个空根、2 个集合；零材质、零图片、零节点组、零场景、零相机和零灯光。
- R36_R38_DISPLAY_MAPPING.json：原件与载荷哈希、材质槽/逐面映射、源签名、坐标/局部范围、R35 前置守卫和回退所有权。
- apply_display_supplement.py、rollback_display_supplement.py、supplement_common.py、source_signature_compat.py：应用、回退及共同检查逻辑。
- CHECK_ONLY.py：可选的只读检查；应用脚本已包含同样的前置检查，无需为了应用再重复运行它。
- BUILD_BINDING_EVIDENCE.json、COMBINATION_VALIDATION.json、SHA256SUMS.json：精确绑定与一次组合应用/回退记录、包内校验值。
不携带大场景、共用贴图、R37 云端专用材质、额外截图或新渲染。

10 个显示件
R36：
1. R36_01_Three_Buried_Edge_Dust_Lenses：三处低矮尘土接触片
2. R36_02_Sparse_Coarse_Breakups：稀疏粗碎块
3. R36_03_Clustered_Mid_Clasts：局部中粒簇
4. R36_04_Fading_Fine_Grains：向外稀疏的细粒
集合：B_R36_WEST_SHAFT_REGOLITH_CONTACT_DISPLAY
根：R36_WEST_SHAFT_CONTACT_DISPLAY_ROOT

R38：
5. R38_01_Outer_Bearing_Saddles：外侧轴承托座
6. R38_02_Open_Service_Bay_Knees：开放检修侧台斜撑
7. R38_03_Four_Cassette_Service_Deck：四块检修面板
8. R38_04_Open_Service_Railing：开放护栏
9. R38_05_Compact_Service_Isolator：紧凑检修柜
10. R38_06_Personnel_Band_And_Bay_Approach：通行面/侧台入口提示
集合：B_R38_WEST_TO_CENTRAL_TRANSFER_DISPLAY
根：R38_WEST_TRANSFER_DISPLAY_ROOT
源件合计 3,415 顶点、5,493 基础三角面；不应用原有倒角/法线修改器，不新增美术。

R35 材质绑定结论
只核对这 10 个显示件实际使用的 10 种共享材质，全部与 R35 基线精确一致：
R36 的 3 种：
- R27S_Compacted_WorldContinuous_PBR
- R27S_DustyClasts_WorldContinuous_PBR
- R27S_FineDust_WorldContinuous_PBR
R38 的 7 种：
- R13_Dark_Seal_And_Gasket
- R23_Exposed_Steel_Calm_Finish
- R23_Matte_Deck_Fine_Finish
- R23_Protective_Steel_Microfinish
- R24_Service_Stencil_Offwhite
- R24_Slate_Gray_Industrial_Enamel
- R8_Restrained_Safety_Ochre
保留旧脚本的源材质签名，另外精确检查材质/节点属性、输入输出、连接、节点组、色带、映射和所用图片内容哈希。应用只把新增网格绑定到当前副本中的这些已有材质；不追加、替换或修改任何共享材质。
R38 旧脚本中「需要 R37」的依赖已被明确限定为本包的 R35 精确绑定守卫；没有改成宽松匹配，也没有略过源检查。
另保留 R36 的 8 个支持面/原型和 R38 的 5 个桥端锚点守卫，并检查已完成 R29→R35 的 14 个前置对象状态。
若本地显示地面、原型、锚点或材质已不同，脚本会在写入前停止。不要用 R37 覆盖本地材质来迎合检查，也不要删掉/放宽守卫；先核对报出的具体差异。

为什么从两个原增量取件
R38 大候选里，R36_01_Three_Buried_Edge_Dust_Lenses 已经过 R37 云端参考修饰：换用 R37 专用网格，增加 3 个 R37 材质槽，并改变逐面绑定及属性。
因此本包从原 R36 小增量取全部 4 件，从原 R38 小增量取全部 6 件。R36 尘土片保留原 R36 的网格、UV、材质槽和逐面绑定；不会夹带 R37 的修饰或要求本地 R8 地表改成云端参考。
明确排除：R37_West_Seam_Compacted_WorldContinuous_PBR、R37_West_Seam_DustyClasts_WorldContinuous_PBR、R37_West_Seam_FineDust_WorldContinuous_PBR，以及 R37 节点组/地表覆盖。

应用
1. 保留原文件；在已完成 R29→R35 合并包的工作副本中操作。
2. 将本 ZIP 完整解压到一个目录，保留文件名与相对位置。
3. 本守卫在 Blender 4.3.2 核验。进入 Object Mode，在 Scripting 的 Text Editor 打开该目录中的 apply_display_supplement.py，运行脚本。
4. 脚本先核对载荷、精确 R35 源状态、前置显示件及 10 种共享材质，再追加 2 个集合并恢复各显示网格的原槽位/逐面绑定。
5. 成功输出 R36_R38_APPLIED。不会自动保存、导出、渲染、设置碰撞或接线。自行确认后才决定是否另存工作副本。
如报错，停止，不要保存不完整结果。脚本会尝试清理本次新增的数据；若提示清理未完成，请关闭该工作副本并从保留的文件重新打开。
不要直接把无材质 BLEND 库作为 Unity 成品导入。

回退
在同一工作副本中打开并运行 rollback_display_supplement.py。
脚本核对本补充包回执、12 个新增对象的几何/UV/变换/材质槽/属性与集合归属，并检查是否新增外部引用；通过后只删除本包的 10 个网格、2 个空根和2个集合。
已完成的 R29→R35 显示件、共享材质/贴图、原场景和原地表不受影响，不自动保存。
若新增显示件已被继续编辑、移动、重新归属或引用，回退会停止供人工核对。运行出错时不要保存，重新打开保留的工作副本即可；不承诺异常中断后的自动修复。
临时比较可切换两个新增集合的可见性；若随后执行严格回退，应先恢复原来的可见状态。

本轮核验范围
只在云端 Blender 4.3.2 的内存副本完成一次组合应用与一次回退：先接已有 R29→R35，再接本补充包，最后只回退本补充包。
核对旧对象完整签名、材质内容、数据块集合、前包回执、原集合/灯光/世界/相机/渲染设置及源文件哈希保持；没有保存新的大场景，没有新渲染。
这只是打包/绑定/回退检查，不是实机验证。

未做与边界
未在 Windows 导入验证，未访问离线 Windows，未修改本地工程。
没有 Unity 导出、导入、编译、运行、正式场景接线、性能或全场测试。
没有改全地表、DEM/Terrain、洞口尺寸/深度、碰撞、交互、MC00、灯光、雾、曝光或原相机。
R36 沿用原多 UV/世界坐标材质契约；Blender Z-up，既定 Unity XYZ=Blender XZY 只转换一次，本包不执行坐标转换。
桥端侧台/护栏是显示概念，不代表结构或安全认证。实际本地地表/Shader 上的视觉、接触关系和运行效果仍需之后在用户机器上确认。
