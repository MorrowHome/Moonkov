import json,shutil
from pathlib import Path
D=Path(__file__).resolve().parent;S=D.parent/'moonkov_rebuild_R21_ring_structural_finish_20261020'
for n in ['ALLOWED_CHANGE_AND_ROLLBACK.json','COMPONENT_OWNERSHIP_SIGNATURES.json']:
 shutil.copy2(S/n,D/'source_contracts'/n)
a=json.loads((S/'ALLOWED_CHANGE_AND_ROLLBACK.json').read_text());m=a['material'];linear=m['base_color_linear'];srgb=[12.92*x if x<=.0031308 else 1.055*x**(1/2.4)-.055 for x in linear]
recipe={'status':'RECIPE_ONLY_NOT_UNITY_VERIFIED','material':m['name'],'shader':'Universal Render Pipeline/Lit','workflow':'Metallic','surface':'Opaque','base_color_linear_rgba':linear+[1],'base_color_srgb_UI_rgba':srgb+[1],'metallic':0,'smoothness':.4,'normal_texture':None,'base_texture':None,'metallic_gloss_texture':None,'emission':'off','alpha_clip':False,'clear_coat':0,'scope':'150 selected source faces only. All other existing materials MUST be reused unchanged.','limitations':['URP Lit dielectric response is not pixel-identical to Blender IOR 1.48.','Set color once using the correct linear/sRGB API convention. Do not apply both conversions. Verify project color space before use.','Neutral FBX materials are identity stubs, not appearance.','Do not override R8_Dark_Protective_Steel globally.']}
(D/'PRIVATE_URP_MATERIAL_RECIPE.json').write_text(json.dumps(recipe,indent=2))
