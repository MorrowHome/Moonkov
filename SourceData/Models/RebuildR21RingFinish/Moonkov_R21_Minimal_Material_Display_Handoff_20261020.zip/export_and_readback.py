import bpy,json,hashlib,sys,collections,numpy as np
from pathlib import Path
D=Path(__file__).resolve().parent;S=D.parent/'moonkov_rebuild_R21_ring_structural_finish_20261020/Moonkov_Rebuild_R21_Ring_Structural_Finish_FULL_EDITABLE.blend'
C=json.loads((D/'source_contracts/ALLOWED_CHANGE_AND_ROLLBACK.json').read_text());H='3d2184aa58c3f895b746d16a0d653d70ec7b10bf728847e2aad72eabde6818c2'
def digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(n,v):(D/n).write_text(json.dumps(v,indent=2,allow_nan=False))
assert digest(S)==H
bpy.ops.wm.read_factory_settings(use_empty=True)
with bpy.data.libraries.load(str(S),link=False) as (a,b):b.objects=C['objects']
obs=b.objects
for o in obs:bpy.context.scene.collection.objects.link(o)
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=1
bpy.context.view_layer.update()
def snap(o):
 me=o.data;me.calc_loop_triangles();faces=[]
 for p in me.polygons:
  faces.append({'xyz':[list(me.vertices[me.loops[i].vertex_index].co) for i in p.loop_indices],'uv':{u.name:[list(u.data[i].uv) for i in p.loop_indices] for u in me.uv_layers},'material':me.materials[p.material_index].name})
 return {'matrix':[list(r) for r in o.matrix_world],'vertices':len(me.vertices),'faces':faces,'triangles':len(me.loop_triangles),'slots':[m.name for m in me.materials]}
before={o.name:snap(o) for o in obs};allmats={m.name:m for o in obs for m in o.data.materials};stubs={}
for n,m in allmats.items():
 m.name='MEMORY_ONLY_'+n;s=bpy.data.materials.new(n);s.diffuse_color=(.5,.5,.5,1);stubs[n]=s
for o in obs:
 assert not o.modifiers
 for i,n in enumerate(before[o.name]['slots']):o.data.materials[i]=stubs[n]
 o.select_set(True)
 me=o.data;me.calc_tangents(uvmap=me.uv_layers[0].name);assert all(np.isfinite(l.tangent).all() for l in me.loops);me.free_tangents()
settings=dict(use_selection=True,object_types={'MESH'},use_mesh_modifiers=False,use_triangles=False,use_tspace=True,mesh_smooth_type='OFF',global_scale=1.,apply_unit_scale=True,apply_scale_options='FBX_SCALE_UNITS',axis_forward='-Z',axis_up='Y',use_space_transform=True,bake_space_transform=False,bake_anim=False,use_custom_props=False,path_mode='STRIP',embed_textures=False)
f=D/'R21_FIVE_SOURCE_MESHES_REPLACEMENT_CANDIDATES_DO_NOT_INSTANTIATE.fbx'
assert not f.exists();assert bpy.ops.export_scene.fbx(filepath=str(f),**settings)=={'FINISHED'}
put('EXPORT_SOURCE_SNAPSHOT.json',before)
bpy.ops.wm.read_factory_settings(use_empty=True);assert bpy.ops.import_scene.fbx(filepath=str(f),use_custom_normals=True)=={'FINISHED'}
after={o.name:snap(o) for o in bpy.context.scene.objects if o.type=='MESH'};assert set(before)==set(after)
results=[]
for n,a in before.items():
 b=after[n];assert len(a['faces'])==len(b['faces']) and a['triangles']==b['triangles'];maxgeo=maxuv=0.;used=set();ac=np.array([np.mean(p['xyz'],axis=0) for p in a['faces']]);bc=np.array([np.mean(p['xyz'],axis=0) for p in b['faces']]);ties=0
 for i,p in enumerate(a['faces']):
  dist=np.linalg.norm(bc-ac[i],axis=1);matches=[];x=np.array(p['xyz'])
  for j in np.where(dist<.001)[0]:
   if int(j) in used:continue
   q=b['faces'][j]
   if p['material']!=q['material'] or len(p['xyz'])!=len(q['xyz']):continue
   y=np.array(q['xyz']);err,k=min((float(np.max(np.linalg.norm(x-np.roll(y,k,axis=0),axis=1))),k) for k in range(len(x)))
   if err>=.001 or len(p['uv'])!=len(q['uv']):continue
   ue=max(float(np.max(np.abs(np.array(u)-np.roll(np.array(v),k,axis=0)))) for u,v in zip(p['uv'].values(),q['uv'].values()))
   if ue<1e-5:matches.append((err,ue,int(j)))
  assert matches,(n,i,float(dist.min()),'no full winding+UV+material match')
  if len(matches)>1:ties+=1
  err,ue,j=min(matches);used.add(j);maxgeo=max(maxgeo,err);maxuv=max(maxuv,ue)
 materr=float(np.max(np.abs(np.array(a['matrix'])-np.array(b['matrix']))));assert materr<.001
 results.append({'object':n,'source_polygons':len(a['faces']),'triangles':a['triangles'],'source_vertices':a['vertices'],'readback_vertices':b['vertices'],'all_face_materials_match':True,'face_multiset_matched_one_to_one':True,'identical_face_candidate_ties':ties,'winding_preserved':True,'max_local_coordinate_error_m':maxgeo,'max_uv_error':maxuv,'max_matrix_element_error':materr})
assert digest(S)==H
put('OFFLINE_READBACK_REPORT.json',{'status':'PASS_OFFLINE_FBX_ROUNDTRIP_ONLY','source_sha256_before_and_after':H,'fbx_sha256':digest(f),'fbx_bytes':f.stat().st_size,'objects':results,'selected_source_face_count':150,'selected_components':25,'source_blend_saved':False,'unity_renderer_ownership':'NOT_CHECKED_BLOCKS_APPLICATION','unity_compilation_runtime_performance':'NOT_RUN','normal_limit':'Tangent finite on source and normals exported; engine shading not validated.'})
print('R21_EXPORT_READBACK_PASS',flush=True)
