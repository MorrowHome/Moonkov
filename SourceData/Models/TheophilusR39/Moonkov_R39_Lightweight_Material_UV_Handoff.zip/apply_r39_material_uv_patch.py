"""Apply exact R39 material + four UV coordinates to a matching R38 work copy.
Run with Blender's Scripting editor or --python. Does not save automatically.
"""
import bpy,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P))
from r39_common import *
def apply():
 p=json.loads((P/'R39_Deck0176_Material_UV_Patch.json').read_text())
 ob=bpy.data.objects.get(p['target_object']);assert ob and ob.type=='MESH','Required original deck is missing'
 m=ob.data;assert m.name==p['target_mesh'] and m.users==1,'Mesh identity or ownership changed'
 if object_sig(ob)==p['after_object_signature']:
  assert mat_sig(bpy.data.materials[p['new_material']])==p['new_material_signature'],'R39 material was edited'
  print('R39 already applied; no changes.');return
 assert object_sig(ob)==p['before_object_signature'],'Target deck no longer matches R38; nothing changed'
 assert geom_sig(m)==p['target_geometry'],'Original geometry changed; nothing changed'
 lib=P/p['material_library'];assert sha(lib)==p['material_library_sha256'],'Material library hash mismatch'
 for name,h in p['textures'].items():assert sha(P/'textures'/name)==h,'Texture mismatch: '+name
 assert p['new_material'] not in bpy.data.materials,'Conflicting R39 material already exists'
 assert not any(n in bpy.data.images for n in p['new_images']),'Conflicting R39 image already exists'
 with bpy.data.libraries.load(str(lib),link=False) as (src,dst):
  assert p['new_material'] in src.materials;dst.materials=[p['new_material']]
 mat=bpy.data.materials[p['new_material']]
 assert mat_sig(mat)==p['new_material_signature'],'Imported material verification failed'
 restore_surface(m,p['after'])
 assert object_sig(ob)==p['after_object_signature'],'Unexpected post-apply target state'
 print('R39 applied: one original top polygon, one appended material slot, four UV coordinates. No automatic save.')
if __name__=='__main__':apply()
