# R08 display-only game-export review handoff

This package is a standard FBX fallback for local review, not the Unity project's native mesh-bin/manifest contract and not a replacement for the full editable author map.

## Immutable source

Moonkov_Rebuild_R08_North_Entry_Alignment_FULL_EDITABLE.blend

305,168,030 bytes; SHA-256 b56a88516f3bb1ddc34ab9c109ccbe0ff9cf46cfc78df8685bcfeb7368742034.

The source was read only. All evaluated conversion and missing-UV authoring occurred on transient export copies in a separate scratch scene. No R09 content is used.

## Coverage and modularity

The full-map visibility audit found 15,089 unique display surface occurrences: 5,702 direct objects and 9,387 generated building instances after removing six duplicate evaluated FONT self-instance records from the initial 15,095 raw occurrences. This handoff exports only the 1,271 visible R01-R08 increment objects. The other 13,818 inherited author-map occurrences remain fully inventoried in SOURCE_INVENTORY.json; their geometry is deliberately not re-exported over the already optimized Unity base. Complete source object names, collections, generating instance parents, persistent IDs and transforms remain recorded in that inventory. Exported increments remain separate modular objects; no scene-wide mesh combining is performed.

Visible revision occurrences: R01 209; R02 125; R04 105; R05 473; R06 221; R07 135; R08 3. The other 13,818 occurrences are inherited author-map display geometry. Six increment FONT objects are evaluated to meshes so lettering is retained; the full source contains six unique visible FONT objects. Blender also reports six identical evaluated self-instances of those same labels; FONT_SELF_INSTANCE_DEDUP_PROOF.json records exact geometry/UV/material/transform equality, and only the redundant self-instance records are omitted. Legacy B_R03_* and B_R08_* asset names are inherited region names, not the R03/R08 revision identifiers.

The increment FBX files follow their source leaf collections. The inherited base and visible display terrain are inventory/reference only, with no base FBX or new terrain export. This partitioning is for transfer/review; it does not establish the best Unity batching/culling boundaries.

## Explicit local lunar-surface protection

The user confirmed on 2026-10-19 that the lunar-surface material has already been changed locally and must not be reverted. Preserve the current local lunar-surface material, texture assignments, shader, parameters and settings exactly. Do not import, remap, regenerate or replace terrain/lunar-surface materials from this cloud source. Base terrain geometry is inventory-only. R24_Compacted_Regolith_Trace is referenced by some increment paths/roofs and is explicitly blocked from importing its cloud settings. Preserve the corresponding current local material or hold those assignments for manual review. Any future lunar-surface dependency must remain excluded or be mapped manually to the current local material after review, never overwritten automatically.

## Local integration gate

1. Stage files for review first. Compare existing source identities and import only missing or explicitly matched replacement display increments. Do not replace or duplicate the existing optimized base from the full-map reference inventory.
2. Keep existing MC00 baked lighting and lighting loops, static chunks, indoor culling, rock LODs, existing Unity material identities, 118 lights and 135 button IDs. This package contains no lights, cameras, colliders, NavMesh or gameplay bindings. No interaction, collision or movement changes are authorized by this package.
3. Match source identities through EXPORT_MANIFEST.json, not truncated FBX display names or guessed prefix rules. GX names are deterministic hashes with a readable source-name suffix. JSON carries each complete original identity.
4. Review the native project ingestion contract separately. This JSON explicitly is not that contract. Reuse already-created Unity materials where exact identities match; do not overwrite them with FBX material auto-generation.
5. Verify target-engine coordinates, pivots, imported dimensions, visibility and material assignments before activation. Blender clean-reimport verification is an asset-side check only.

## Required visibility and replacements

- Original accepted R02 central design remains active. R03_CENTRAL_EXTRACTION_CITADEL and its descendants stay excluded. Only the 60 effectively visible objects in the 207-object restored center set are relevant; 147 historical variants remain hidden. The old R03 archive collections are empty and must not be used to re-enable variants.
- R06_ARCHIVE_SUPERSEDED_R05_WEST_SKIN contains 30 superseded R05 objects (28 meshes and 2 text objects). They stay excluded. Exact former memberships are in REVISION_ARCHIVE_MAPPING.json.
- Disable only the prior display object corresponding to R04_N03_R08_Aerial_Landing_Right_Rail when replacing that rail. It remains linked to R04_N_RIM_STAIR_AND_AERIAL_LANDING in the author source but is explicitly hidden, and is also linked to R08_ARCHIVE_REDUNDANT_R04_GUARD_ORIGINAL. Collection-only filtering is insufficient.
- Retain/import R08_R04_Guard_Retained_North_Span_Closed_End and R08_R04_Guard_Retained_South_Span_Closed_End. R08_Existing_EB07_Entry_Toe_Transition is the third new display mesh. Do not disable the whole R04 landing collection. R08_RAIL_REPLACEMENT_MAP.json also carries the old unchanged mesh signature and source opening measurements.
- The source's hidden archive alternatives and source DEM, cameras and lights are not exported. The visible display terrain is inventoried only; it is not re-exported or changed.

## Coordinates, UVs and material slots

Metric scene, scale_length=1.0. Global FBX scale=1; apply units; FBX_SCALE_UNITS; forward=-Z, up=Y; space transform enabled; bake-space-transform disabled. Evaluated object-local geometry and complete world placement are preserved. Generated instances use the actual evaluated instance matrix, including their template offset. There is no independent recentering. Several increment meshes already use world-positioned vertices with an identity object transform; this is preserved deliberately.

Existing evaluated UV layers are retained unchanged. Only meshes with no evaluated UV layer receive a new UV0 named R08_GameExport_UV0_Box_1LocalUnit. It is per-face dominant-normal box projection, anchored at the object's local bounds minimum, with one local unit per texture repeat. It is a deterministic export adaptation, not a bake or claim of artist-tuned texel density. Existing nondegenerate UVs are not replaced. Existing degenerate UV areas are reported, not silently repaired. No lightmap UVs are generated. Two R07 bay east-return rails initially exposed 12 collapsed triangles under ordinary box projection. Only those affected export-copy face UVs receive an alternate-axis/oblique face projection, with unchanged geometry/materials/bounds; see TWO_RAIL_UV_REPAIR_PROOF.json.

Disable automatic Unity material imports for these FBX files and use explicit existing-material mappings. MATERIAL_SLOT_MAPPING.csv lists source identities and protected assignments. FBX may reorder material slot indices. Reconcile by source material name and per-face assignment identities; do not hard-code source numeric slot positions. Seventeen source material node/input/link records are included. These increment materials reference no packed-image dependencies, so no texture files are bundled; inherited base textures remain in the unchanged author source. Generated UVs do not reproduce procedural Blender shading. Materials marked UNRESOLVED_PROCEDURAL_REQUIRES_UNITY_REVIEW need explicit target-engine translation/baking decisions. Even simple FBX PBR output can omit ORM or glass semantics; existing Unity materials should be retained where appropriate.

## Validation and limitations

Read REIMPORT_VALIDATION_SUMMARY.json and reimport_validation/*.json for actual validation results. A file existing or exporting successfully is not a passed clean-reimport check. Any failed partition remains blocked for import until explained or corrected.

No Unity import, target-shader visual parity, collider fit, continuous capsule walkability, NavMesh, runtime lighting, frame time, draw-call or performance claim is made. Original R08 static geometry QA remains separate from this export/roundtrip QA.

## Final asset-side result

Clean Blender reimport passes all 31 partitions and 1,271 objects: 154,420 vertices, 146,189 polygons and 279,994 triangles. Generated UV0 layers have zero nonzero-geometry triangles with collapsed UV area. Six preserved source labels retain 5,858 pre-existing degenerate triangle/layer warnings. All 515 raw UV-hash differences are independently proven to be signed-zero normalization only, with nonzero coordinates unchanged. Geometry, bounds, pivots, material identities and per-face assignments pass. The source SHA remains unchanged.

143 exported meshes contain polygons with more than four vertices; FBX cannot emit tangent arrays for those meshes under these topology-preserving settings. No image-normal-map dependency is bundled. Any target-engine tangent/triangulation choice needs local review; no global source triangulation was performed.

## Verification files

PACKAGE_CONTENTS.json lists byte sizes and SHA-256 hashes of every payload file except itself. The unchanged editable source is not bundled. Export/repair generation scripts and intermediate diagnostics remain separate from this import-review package. validate_fbx.py and its logic self-tests are included for asset-side repeat checks. To rerun validation, use a copied/extracted review folder, set MOONKOV_R08_SOURCE to the exact unchanged source file, then run Blender 4.3.2 in background factory-startup mode with validate_fbx.py. The validator writes its QA reports inside that copied folder; it never opens or saves the author source in Blender. The historical export.log is included only as its completed-export gate/evidence.
