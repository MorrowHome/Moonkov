"""Independently round-trip exported FBX partitions; never open or save author .blend.

Run after export completion:
blender -b --factory-startup -t 2 --python-exit-code 1 --python validate_fbx.py
Each FBX is imported into a newly reset, factory-empty Blender scene.
For a relocated unchanged source, set MOONKOV_R08_SOURCE to its local .blend path.
The exact original SHA256 remains mandatory; the source is never opened in Blender.
"""
import bpy
import collections
import hashlib
import json
import math
import os
import sys
import time
import traceback
from pathlib import Path
import numpy as np

D = Path(__file__).resolve().parent
REPORT_DIR = D / 'reimport_validation'
EXPECTED_SOURCE_SHA = 'b56a88516f3bb1ddc34ab9c109ccbe0ff9cf46cfc78df8685bcfeb7368742034'
WORLD_TOLERANCE_M = 0.005
LINEAR_TRANSFORM_TOLERANCE = 0.00001
LINEAR_TRANSFORM_RELATIVE_TOLERANCE = 0.000001
IMPORT_SETTINGS = dict(use_manual_orientation=False, global_scale=1.0,
                       bake_space_transform=False, use_custom_normals=True,
                       use_image_search=False, use_anim=False,
                       use_custom_props=False, ignore_leaf_bones=False,
                       automatic_bone_orientation=False)


def digest_file(path):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def sanitize(value):
    if isinstance(value, dict):
        return {k: sanitize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [sanitize(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return value


def write_json(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(sanitize(value), indent=2, allow_nan=False))
    tmp.replace(path)


def arr(data, prop, dimensions, dtype=np.float32):
    result = np.empty(len(data) * dimensions, dtype=dtype)
    data.foreach_get(prop, result)
    return result.reshape((-1, dimensions))


def sha_array(value):
    return hashlib.sha256(value.tobytes()).hexdigest()


def snapshot(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        matrix = np.array(evaluated.matrix_world, dtype=np.float64)
        xyz = arr(mesh.vertices, 'co', 3)
        world = xyz.astype(np.float64) @ matrix[:3, :3].T + matrix[:3, 3]
        material_indices = arr(mesh.polygons, 'material_index', 1, np.int32).ravel()
        slots = [x.name if x else None for x in mesh.materials]
        assignments = [slots[int(i)] if int(i) < len(slots) else None for i in material_indices]
        invalid_indices = [int(i) for i in material_indices if int(i) >= max(1, len(slots))]
        mesh.calc_loop_triangles()
        tri_loops = arr(mesh.loop_triangles, 'loops', 3, np.int32)
        tri_vertices = arr(mesh.loop_triangles, 'vertices', 3, np.int32)
        tri_xyz = xyz[tri_vertices]
        geom_area2 = np.linalg.norm(np.cross(tri_xyz[:, 1] - tri_xyz[:, 0],
                                             tri_xyz[:, 2] - tri_xyz[:, 0]), axis=1)
        nondegenerate = geom_area2 > 1e-12
        uv_layers = []
        for layer in mesh.uv_layers:
            uv = arr(layer.data, 'uv', 2)
            tri_uv = uv[tri_loops]
            ab = tri_uv[:, 1] - tri_uv[:, 0]
            ac = tri_uv[:, 2] - tri_uv[:, 0]
            uv_area2 = np.abs(ab[:, 0] * ac[:, 1] - ab[:, 1] * ac[:, 0])
            canonical_uv = uv.copy()
            canonical_uv[canonical_uv == 0] = 0.0
            reconstruction = None
            if layer.name == 'R08_GameExport_UV0_Box_1LocalUnit':
                projected = np.empty_like(uv)
                origin_shifted_xyz = xyz.copy()
                origin_shifted_xyz -= origin_shifted_xyz.min(axis=0)
                loop_vertices = arr(mesh.loops, 'vertex_index', 1, np.int32).ravel()
                for polygon in mesh.polygons:
                    axis = int(np.argmax(np.abs(polygon.normal)))
                    axes = ([1, 2], [0, 2], [0, 1])[axis]
                    sl = slice(polygon.loop_start, polygon.loop_start + polygon.loop_total)
                    coordinates = origin_shifted_xyz[loop_vertices[sl]][:, axes].copy()
                    if polygon.normal[axis] < 0:
                        coordinates[:, 0] *= -1
                    projected[sl] = coordinates
                canonical_projected = projected.copy()
                canonical_projected[canonical_projected == 0] = 0.0
                reconstruction = {
                    'sha256_float32': sha_array(projected),
                    'sha256_float32_canonical_zero': sha_array(canonical_projected),
                    'negative_zero_components': int(np.sum((projected == 0) & np.signbit(projected))),
                    'exact_numeric_equal_to_imported': bool(np.array_equal(projected, uv)),
                    'maximum_absolute_numeric_difference': float(np.max(np.abs(projected - uv))) if uv.size else 0.0}
            uv_layers.append({
                'name': layer.name,
                'index': len(uv_layers),
                'sha256_float32': sha_array(uv),
                'sha256_float32_canonical_zero': sha_array(canonical_uv),
                'negative_zero_components': int(np.sum((uv == 0) & np.signbit(uv))),
                'declared_box_projection_reconstruction': reconstruction,
                'finite': bool(np.isfinite(uv).all()),
                'nonzero_geometry_triangles_with_zero_uv_area': int(np.sum(nondegenerate & (uv_area2 <= 1e-12))),
                'range': [[float(uv[:, i].min()), float(uv[:, i].max())] for i in range(2)] if len(uv) else None,
            })
        return {
            'vertices': len(mesh.vertices),
            'polygons': len(mesh.polygons),
            'loops': len(mesh.loops),
            'triangles': len(mesh.loop_triangles),
            'world_bounds': [[float(world[:, i].min()), float(world[:, i].max())] for i in range(3)] if len(world) else None,
            'matrix_world': matrix.tolist(),
            'pivot_world': matrix[:3, 3].tolist(),
            'local_vertex_sha256': sha_array(xyz),
            'finite_geometry': bool(np.isfinite(xyz).all() and np.isfinite(world).all()),
            'finite_transform': bool(np.isfinite(matrix).all()),
            'material_slots': slots,
            'invalid_face_material_indices_count': len(invalid_indices),
            'face_material_counts': {('null' if k is None else k): int(v) for k, v in collections.Counter(assignments).items()},
            'face_material_sequence_sha256': hashlib.sha256(json.dumps(assignments, separators=(',', ':')).encode()).hexdigest(),
            'uv_layers': uv_layers,
            'max_polygon_vertices': max((p.loop_total for p in mesh.polygons), default=0),
        }
    finally:
        evaluated.to_mesh_clear()


def difference(a, b):
    aa, bb = np.array(a, dtype=np.float64), np.array(b, dtype=np.float64)
    if aa.shape != bb.shape or not np.isfinite(aa).all() or not np.isfinite(bb).all():
        return None
    return float(np.max(np.abs(aa - bb))) if aa.size else 0.0


def validate_object(row, obj, depsgraph):
    expected = row['export_snapshot']
    actual = snapshot(obj, depsgraph)
    checks, failures, warnings, quality_issues = {}, [], [], []
    def check(name, value):
        checks[name] = bool(value)
        if not value:
            failures.append(name)
    for metric in ('vertices', 'polygons', 'loops', 'triangles', 'max_polygon_vertices'):
        check(metric + '_match', expected[metric] == actual[metric])
    check('finite_geometry', actual['finite_geometry'])
    check('finite_transform', actual['finite_transform'])
    bounds_delta = difference(expected['world_bounds'], actual['world_bounds'])
    check('world_bounds_within_0_005_m', bounds_delta is not None and bounds_delta <= WORLD_TOLERANCE_M)
    expected_matrix = np.array(row['matrix_world'], dtype=np.float64)
    actual_matrix = np.array(actual['matrix_world'], dtype=np.float64)
    pivot_delta = difference(expected_matrix[:3, 3], actual_matrix[:3, 3])
    pivot_euclidean = float(np.linalg.norm(expected_matrix[:3, 3] - actual_matrix[:3, 3]))
    linear_delta = difference(expected_matrix[:3, :3], actual_matrix[:3, :3])
    homogeneous_delta = difference(expected_matrix[3], actual_matrix[3])
    check('pivot_within_0_005_m_euclidean', math.isfinite(pivot_euclidean) and pivot_euclidean <= WORLD_TOLERANCE_M)
    linear_within_tolerance = bool(np.allclose(expected_matrix[:3, :3], actual_matrix[:3, :3], atol=LINEAR_TRANSFORM_TOLERANCE, rtol=LINEAR_TRANSFORM_RELATIVE_TOLERANCE))
    check('linear_transform_within_atol_1e_5_rtol_1e_6', linear_delta is not None and linear_within_tolerance)
    if linear_delta is not None and linear_delta > LINEAR_TRANSFORM_TOLERANCE and linear_within_tolerance:
        warnings.append('Linear matrix absolute difference exceeds 1e-5 but passes declared 1e-6 relative float32 tolerance; world bounds and pivots independently meet the 0.005 m limit.')
    check('homogeneous_transform_preserved', homogeneous_delta is not None and homogeneous_delta <= LINEAR_TRANSFORM_TOLERANCE)
    check('face_material_indices_valid', actual['invalid_face_material_indices_count'] == 0)
    expected_slots = expected['material_slots']
    actual_slots = actual['material_slots']
    check('material_slot_identities_preserved', set(expected_slots) == set(actual_slots))
    check('face_material_identity_counts_match', expected['face_material_counts'] == actual['face_material_counts'])
    check('face_material_identity_sequence_hash_match', expected['face_material_sequence_sha256'] == actual['face_material_sequence_sha256'])
    slot_remap = [{'imported_slot': i, 'material_identity': name,
                   'matching_export_slots': [j for j, other in enumerate(expected_slots) if name == other]}
                  for i, name in enumerate(actual_slots)]
    if expected_slots != actual_slots:
        warnings.append('FBX material slots changed ordering or multiplicity; per-face material identity is checked independently of slot number.')
    if collections.Counter(expected_slots) != collections.Counter(actual_slots):
        warnings.append('Material slot multiplicities differ; see identity remap and face assignment checks.')
    expected_uv_names = [x['name'] for x in expected['uv_layers']]
    actual_uv_names = [x['name'] for x in actual['uv_layers']]
    check('uv_layer_identity_and_order_match', expected_uv_names == actual_uv_names)
    actual_uv_by_name = {x['name']: x for x in actual['uv_layers']}
    uv_details = []
    for layer in expected['uv_layers']:
        imported = actual_uv_by_name.get(layer['name'])
        detail = {'name': layer['name'], 'expected_sha256_float32': layer['sha256_float32'],
                  'actual_sha256_float32': imported['sha256_float32'] if imported else None,
                  'expected_degenerate_uv_triangles': layer['nonzero_geometry_triangles_with_zero_uv_area'],
                  'actual_degenerate_uv_triangles': imported['nonzero_geometry_triangles_with_zero_uv_area'] if imported else None}
        raw_hash_equal = imported is not None and layer['sha256_float32'] == imported['sha256_float32']
        signed_zero_equivalent = False
        proof_method = None
        if imported is not None and not raw_hash_equal:
            expected_canonical = layer.get('sha256_float32_canonical_zero')
            if expected_canonical and expected_canonical == imported.get('sha256_float32_canonical_zero'):
                signed_zero_equivalent = True
                proof_method = 'export_time_canonical_zero_hash_matches_imported_canonical_zero_hash'
            elif row['uv_policy'] == 'box_projection_per_face_dominant_local_normal_origin_at_local_bounds_min_1_local_unit_per_repeat':
                reconstructed = imported.get('declared_box_projection_reconstruction') or {}
                signed_zero_equivalent = (
                    reconstructed.get('sha256_float32') == layer['sha256_float32'] and
                    reconstructed.get('exact_numeric_equal_to_imported') is True and
                    reconstructed.get('sha256_float32_canonical_zero') == imported.get('sha256_float32_canonical_zero') and
                    expected['local_vertex_sha256'] == actual['local_vertex_sha256'])
                if signed_zero_equivalent:
                    proof_method = 'regenerated_raw_hash_matches_export_then_exact_numeric_equality_and_canonical_zero_hash_match'
        detail['raw_float32_hash_match'] = raw_hash_equal
        detail['signed_zero_only_equivalent'] = signed_zero_equivalent
        detail['signed_zero_equivalence_proof_method'] = proof_method
        detail['actual_sha256_float32_canonical_zero'] = imported.get('sha256_float32_canonical_zero') if imported else None
        if signed_zero_equivalent:
            warnings.append('Raw UV float32 hash differs only by signed zero; exact numerical values are proven equivalent with canonical-zero hashes.')
        check('uv_float32_integrity:' + layer['name'], raw_hash_equal or signed_zero_equivalent)
        check('uv_finite:' + layer['name'], layer['finite'] and imported is not None and imported['finite'])
        if layer['nonzero_geometry_triangles_with_zero_uv_area']:
            generated = row['uv_policy'] != 'preserved_existing_layers_unchanged'
            message = ('Generated' if generated else 'Preserved existing') + ' UV layer ' + layer['name'] + ' has ' + str(layer['nonzero_geometry_triangles_with_zero_uv_area']) + ' nondegenerate geometry triangles with zero UV area (threshold 1e-12 in export snapshot).'
            (quality_issues if generated else warnings).append(message)
        if imported and imported['nonzero_geometry_triangles_with_zero_uv_area'] != layer['nonzero_geometry_triangles_with_zero_uv_area']:
            warnings.append('UV/geometric degeneracy classification differs after reimport for ' + layer['name'] + '; see exact UV hash and geometry checks.')
        uv_details.append(detail)
    vertex_hash_equal = expected['local_vertex_sha256'] == actual['local_vertex_sha256']
    if not vertex_hash_equal:
        warnings.append('Local vertex float32 hash differs. Counts, world bounds and matrix tolerances are independently checked; this is not a proof of pointwise mesh equivalence.')
    return {
        'export_object': row['export_object'], 'source_object': row['source_object'],
        'instance_parent': row['instance_parent'], 'persistent_id': row.get('persistent_id'),
        'uv_policy': row['uv_policy'], 'source_uv_layers': row['source_uv_layers'],
        'status': 'PASS' if not failures else 'FAIL', 'checks': checks,
        'failed_checks': failures, 'warnings': warnings, 'export_quality_issues': quality_issues,
        'measurements': {'world_bounds_max_absolute_error_m': bounds_delta,
                         'pivot_max_axis_error_m': pivot_delta, 'pivot_euclidean_error_m': pivot_euclidean,
                         'linear_transform_max_absolute_error': linear_delta,
                         'homogeneous_transform_max_absolute_error': homogeneous_delta,
                         'local_vertex_float32_hash_match': vertex_hash_equal},
        'material_slot_identity_remap': slot_remap, 'uv_comparison': uv_details,
        'expected': dict(expected, matrix_world=row['matrix_world'], pivot_world=expected_matrix[:3, 3].tolist()),
        'actual': actual,
    }


def main():
    log = D / 'export.log'
    assert log.exists() and 'FINAL_EXPORT_READY_V3' in log.read_text().splitlines(), 'Final deduplicated export is not ready; no FBX was imported.'
    assert bpy.app.version == (4, 3, 2), ('Expected Blender 4.3.2', bpy.app.version_string)
    manifest_path = D / 'EXPORT_MANIFEST.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['source_sha256'] == EXPECTED_SOURCE_SHA
    repaired_names = {'R07_Bay_East_Return_Guard_Rail_1.12', 'R07_Bay_East_Return_Guard_Rail_0.58'}
    repair_proofs = manifest.get('export_copy_uv_repairs', [])
    assert len(repair_proofs) == 2 and {r['source_object'] for r in repair_proofs} == repaired_names, 'Final rail UV repair proof must contain exactly both target rails.'
    repaired_rows = [r for r in manifest['objects'] if r['source_object'] in repaired_names and not r.get('exclude_reason')]
    assert len(repaired_rows) == 2, 'Expected exactly two repaired rail export objects.'
    assert all(r['export_snapshot']['uv_layers'][0].get('sha256_float32_canonical_zero') for r in repaired_rows), 'Missing export-time canonical-zero hash on repaired rail UV snapshots; stop before importing.'
    source_inventory_summary = json.loads((D / 'SOURCE_SUMMARY.json').read_text())
    source_path = Path(os.environ.get('MOONKOV_R08_SOURCE', manifest['source'])).expanduser().resolve()
    before_sha = digest_file(source_path)
    assert before_sha == EXPECTED_SOURCE_SHA, 'Author source differs before validation.'
    rows_by_part = collections.defaultdict(list)
    excluded_rows = []
    for row in manifest['objects']:
        if row.get('exclude_reason'):
            excluded_rows.append({'source_object': row['source_object'], 'reason': row['exclude_reason']})
        else:
            assert row.get('export_object') and row.get('partition') and row.get('export_snapshot')
            rows_by_part[row['partition']].append(row)
    parts = manifest['partitions']
    assert set(rows_by_part) == {x['name'] for x in parts}, 'Manifest is missing a completed partition.'
    assert len(parts) == len({x['name'] for x in parts}), 'Duplicate partition entries.'
    active_rows = [r for rs in rows_by_part.values() for r in rs]
    font_direct = {r['source_object']: r for r in active_rows if r.get('source_type') == 'FONT' and r.get('instance_parent') is None}
    duplicate_font_pairs = []
    for row in active_rows:
        if row.get('source_type') != 'FONT' or row.get('instance_parent') != row['source_object']:
            continue
        direct = font_direct.get(row['source_object'])
        if direct and direct['export_snapshot']['local_vertex_sha256'] == row['export_snapshot']['local_vertex_sha256'] and direct['matrix_world'] == row['matrix_world'] and direct['export_snapshot']['world_bounds'] == row['export_snapshot']['world_bounds']:
            duplicate_font_pairs.append({'source_object': row['source_object'], 'direct_export_object': direct['export_object'], 'redundant_self_instance_export_object': row['export_object'], 'partition': row['partition']})
    all_names = [r['export_object'] for r in active_rows]
    assert len(all_names) == len(set(all_names)), 'Duplicate export object names.'
    REPORT_DIR.mkdir(exist_ok=True)
    summary = {
        'schema': 'r08_clean_blender_fbx_roundtrip_validation_v1', 'status': 'RUNNING',
        'blender': bpy.app.version_string, 'blender_command': 'blender -b --factory-startup -t 2 --python-exit-code 1 --python validate_fbx.py',
        'source': str(source_path), 'source_recorded_in_manifest': manifest['source'],
        'source_path_override_used': bool(os.environ.get('MOONKOV_R08_SOURCE')), 'source_sha256_before': before_sha,
        'manifest_sha256': digest_file(manifest_path),
        'manifest_export_scope': manifest.get('scope'),
        'identical_direct_self_instance_font_pairs': duplicate_font_pairs,
        'direct_font_objects': len(font_direct),
        'manifest_integrity_status': 'FAIL_DUPLICATE_FONT_DISPLAY' if duplicate_font_pairs else 'PASS_NO_DUPLICATE_FONT_DISPLAY',
        'full_source_inventory_reference': {
            'file': 'SOURCE_INVENTORY.json',
            'summary_file': 'SOURCE_SUMMARY.json',
            'visible_surface_occurrences': source_inventory_summary.get('visible_surface_instances'),
            'visible_by_revision': source_inventory_summary.get('visible_by_revision'),
            'occurrences_not_in_export_manifest': source_inventory_summary.get('visible_surface_instances', 0) - len(all_names),
            'manifest_reported_inherited_base_inventory_only_occurrences': manifest.get('inherited_base_inventory_only_occurrences'),
            'limitation': 'The full inherited base inventory is reference information. Only manifest-listed completed FBX partitions receive this reimport validation.'},
        'validation_scope': 'Independent clean Blender reimport of every exported FBX partition; no author .blend opened or saved; no Unity access or validation.',
        'tolerances': {'world_bounds_max_axis_error_m': WORLD_TOLERANCE_M,
                       'pivot_euclidean_error_m': WORLD_TOLERANCE_M,
                       'linear_matrix_absolute_tolerance': LINEAR_TRANSFORM_TOLERANCE,
                       'linear_matrix_relative_tolerance': LINEAR_TRANSFORM_RELATIVE_TOLERANCE,
                       'uv': 'Raw float32 per-loop hashes retained. A raw mismatch is accepted only with a signed-zero-only proof: either an export-time canonical-zero hash, or reconstructed raw hash matching the original snapshot plus exact numerical equality and canonical-zero hash equality. All nonzero float32 values, layer identities/order and finite values remain required.',
                       'face_materials': 'Exact material identity per-face sequence SHA256 and identity counts; material-slot numbering may reorder.'},
        'import_settings': IMPORT_SETTINGS, 'expected_partitions': len(parts),
        'expected_objects': len(all_names), 'excluded_manifest_rows': excluded_rows,
        'partitions': [], 'failures': [], 'warning_counts': {},
        'generated_uv_issues': [], 'preserved_uv_warnings': [],
        'material_limitations': {
            'procedural_materials': [m['source_material'] for m in manifest['materials'] if m['translation_status'] == 'UNRESOLVED_PROCEDURAL_REQUIRES_UNITY_REVIEW'],
            'notes': ['Matching material names/slots and per-face assignments do not establish shader or visual parity.',
                      'Blender procedural shaders are not baked or translated to Unity; reuse existing Unity materials by verified identity and review channel mapping.',
                      'Generated per-face box UVs are not authored texture layouts or lightmap UVs. Generated zero-area issue counts and preserved existing font warnings are reported separately below.']},
        'limits': ['This is a Blender FBX round-trip check, not a Unity import/runtime test or performance measurement.',
                   'Local vertex float32 hashes are reported; hash differences need pointwise investigation if all bounded/count checks otherwise pass.',
                   'No Unity project, source scene, FBX, shader, collision, gameplay, light IDs or button IDs is changed by this validator.'],
    }
    total_expected, total_actual = collections.Counter(), collections.Counter()
    signed_zero_uv_objects = []
    warning_counts = collections.Counter()
    for p in parts:
        pname = p['name']
        expected_rows = rows_by_part[pname]
        print('VALIDATE_PARTITION_BEGIN', pname, len(expected_rows), flush=True)
        report = {'partition': pname, 'file': p['file'], 'status': 'RUNNING', 'expected_objects': len(expected_rows),
                  'issues': [], 'objects': []}
        fbx_path = D / p['file']
        try:
            report['sha256'] = digest_file(fbx_path)
            report['expected_sha256'] = p['sha256']
            report['bytes'] = fbx_path.stat().st_size
            if report['sha256'] != p['sha256'] or report['bytes'] != p['bytes']:
                report['issues'].append('FBX file bytes/hash differ from completed export manifest.')
            bpy.ops.wm.read_factory_settings(use_empty=True)
            report['factory_empty_objects_before_import'] = len(bpy.data.objects)
            assert report['factory_empty_objects_before_import'] == 0
            result = bpy.ops.import_scene.fbx(filepath=str(fbx_path), **IMPORT_SETTINGS)
            assert result == {'FINISHED'}, result
            bpy.context.view_layer.update()
            imported_objects = list(bpy.context.scene.objects)
            report['actual_objects'] = len(imported_objects)
            report['imported_object_types'] = dict(collections.Counter(o.type for o in imported_objects))
            actual_by_name = {o.name: o for o in imported_objects}
            expected_by_name = {r['export_object']: r for r in expected_rows}
            report['missing_names'] = sorted(set(expected_by_name) - set(actual_by_name))
            report['unexpected_names'] = sorted(set(actual_by_name) - set(expected_by_name))
            if len(imported_objects) != len(expected_rows) or p['objects'] != len(expected_rows):
                report['issues'].append('Object count mismatch.')
            if report['missing_names'] or report['unexpected_names']:
                report['issues'].append('Exact object name set mismatch.')
            if any(o.type != 'MESH' for o in imported_objects):
                report['issues'].append('Unexpected non-mesh object imported.')
            depsgraph = bpy.context.evaluated_depsgraph_get()
            for row in expected_rows:
                obj = actual_by_name.get(row['export_object'])
                if obj is None or obj.type != 'MESH':
                    continue
                try:
                    detail = validate_object(row, obj, depsgraph)
                except Exception as e:
                    detail = {'export_object': row['export_object'], 'source_object': row['source_object'],
                              'status': 'ERROR', 'failed_checks': ['snapshot_or_compare_error'],
                              'error': repr(e), 'traceback': traceback.format_exc(), 'warnings': []}
                report['objects'].append(detail)
                for uv_detail in detail.get('uv_comparison', []):
                    if uv_detail.get('signed_zero_only_equivalent'):
                        signed_zero_uv_objects.append({'partition': pname, 'object': row['export_object'], 'layer': uv_detail['name'], 'proof_method': uv_detail['signed_zero_equivalence_proof_method']})
                if detail['status'] != 'PASS':
                    summary['failures'].append({'partition': pname, 'object': row['export_object'], 'failed_checks': detail['failed_checks']})
                for warning in detail['warnings']:
                    warning_counts[warning.split(':')[0] if ':' in warning else warning] += 1
                for metric in ('vertices', 'polygons', 'loops', 'triangles'):
                    total_expected[metric] += row['export_snapshot'][metric]
                    if 'actual' in detail:
                        total_actual[metric] += detail['actual'][metric]
                for uv in row['export_snapshot']['uv_layers']:
                    degenerate = uv['nonzero_geometry_triangles_with_zero_uv_area']
                    if degenerate:
                        warning = {'partition': pname, 'object': row['export_object'], 'source_object': row['source_object'],
                                   'layer': uv['name'], 'nonzero_geometry_triangles_with_zero_uv_area': degenerate,
                                   'uv_sha256_float32': uv['sha256_float32']}
                        key = 'preserved_uv_warnings' if row['uv_policy'] == 'preserved_existing_layers_unchanged' else 'generated_uv_issues'
                        summary[key].append(warning)
            report['status'] = 'PASS' if not report['issues'] and all(o['status'] == 'PASS' for o in report['objects']) and len(report['objects']) == len(expected_rows) else 'FAIL'
        except Exception as e:
            report['status'] = 'ERROR'
            report['issues'].append(repr(e))
            report['traceback'] = traceback.format_exc()
        report_path = REPORT_DIR / (pname + '.json')
        write_json(report_path, report)
        part_summary = {k: report[k] for k in ('partition', 'file', 'status', 'expected_objects', 'issues')}
        part_summary['actual_objects'] = report.get('actual_objects')
        part_summary['objects_passed'] = sum(o['status'] == 'PASS' for o in report['objects'])
        part_summary['objects_failed'] = sum(o['status'] != 'PASS' for o in report['objects'])
        part_summary['objects_with_warnings'] = sum(bool(o['warnings']) for o in report['objects'])
        part_summary['objects_with_export_quality_issues'] = sum(bool(o.get('export_quality_issues')) for o in report['objects'])
        part_summary['report'] = str(report_path.relative_to(D))
        summary['partitions'].append(part_summary)
        write_json(D / 'REIMPORT_VALIDATION_SUMMARY.json', summary)
        print('VALIDATE_PARTITION_DONE', json.dumps(part_summary, separators=(',', ':')), flush=True)
    after_sha = digest_file(source_path)
    summary['source_sha256_after'] = after_sha
    summary['source_unchanged'] = before_sha == after_sha == EXPECTED_SOURCE_SHA
    summary['manifest_unchanged_during_validation'] = digest_file(manifest_path) == summary['manifest_sha256']
    summary['expected_evaluated_geometry_totals'] = dict(total_expected)
    summary['actual_evaluated_geometry_totals'] = dict(total_actual)
    summary['warning_counts'] = dict(warning_counts)
    summary['signed_zero_only_uv_equivalences'] = signed_zero_uv_objects
    summary['signed_zero_only_uv_equivalence_count'] = len(signed_zero_uv_objects)
    summary['objects_passed'] = sum(p['objects_passed'] for p in summary['partitions'])
    summary['objects_failed'] = sum(p['objects_failed'] for p in summary['partitions'])
    summary['partitions_passed'] = sum(p['status'] == 'PASS' for p in summary['partitions'])
    summary['partitions_failed'] = sum(p['status'] != 'PASS' for p in summary['partitions'])
    summary['generated_uv_issue_objects'] = len({x['object'] for x in summary['generated_uv_issues']})
    summary['generated_uv_degenerate_triangle_layer_total'] = sum(x['nonzero_geometry_triangles_with_zero_uv_area'] for x in summary['generated_uv_issues'])
    summary['preserved_uv_warning_objects'] = len({x['object'] for x in summary['preserved_uv_warnings']})
    summary['preserved_uv_degenerate_triangle_layer_total'] = sum(x['nonzero_geometry_triangles_with_zero_uv_area'] for x in summary['preserved_uv_warnings'])
    summary['export_quality_status'] = 'GENERATED_UV_ISSUES_REQUIRE_REVIEW' if summary['generated_uv_issues'] else 'NO_GENERATED_ZERO_AREA_UV_ISSUES_FOUND'
    summary['roundtrip_integrity_status'] = 'PASS' if summary['partitions_failed'] == 0 and summary['source_unchanged'] and summary['manifest_unchanged_during_validation'] and not duplicate_font_pairs else 'FAIL'
    summary['generated_uv_zero_area_check_passed'] = not summary['generated_uv_issues']
    summary['material_limitations']['notes'][-1] = ('Generated per-face box UVs are not authored texture layouts or lightmap UVs. All generated zero-area UV issues are resolved (0); unchanged pre-existing font UV warnings remain preserved.' if summary['generated_uv_zero_area_check_passed'] else 'Generated per-face box UVs are not authored texture layouts or lightmap UVs. Generated zero-area UV issues remain unresolved; existing font UV warnings remain preserved.')
    summary['status'] = 'PASS' if summary['roundtrip_integrity_status'] == 'PASS' and summary['generated_uv_zero_area_check_passed'] else 'FAIL'
    write_json(D / 'REIMPORT_VALIDATION_SUMMARY.json', summary)
    concise = [
        'R08 FBX clean-reimport validation: ' + summary['status'],
        'Blender 4.3.2, factory-empty reset for every partition, -t 2.',
        f"Partitions: {summary['partitions_passed']}/{len(parts)} passed; objects: {summary['objects_passed']}/{len(all_names)} passed.",
        'Evaluated totals: ' + json.dumps(dict(total_actual), sort_keys=True),
        f"Generated UV zero-area issues: {summary['generated_uv_issue_objects']} objects; {summary['generated_uv_degenerate_triangle_layer_total']} triangle/layer instances.",
        f"Preserved UV zero-area warnings: {summary['preserved_uv_warning_objects']} objects; {summary['preserved_uv_degenerate_triangle_layer_total']} triangle/layer instances.",
        f"Procedural material identities requiring Unity review: {len(summary['material_limitations']['procedural_materials'])}.",
        'Source SHA256 unchanged: ' + str(summary['source_unchanged']) + ' (' + after_sha + ').',
        f"Signed-zero-only UV byte changes independently proven equivalent: {len(signed_zero_uv_objects)} layer/object instances.",
        'Full report: REIMPORT_VALIDATION_SUMMARY.json and reimport_validation/*.json.',
        'This does not establish Unity shader/visual parity, Unity import correctness or runtime/performance behavior.',
    ]
    if summary['failures']:
        concise.append('Object check failures: ' + json.dumps(summary['failures'][:15], separators=(',', ':')))
    (D / 'REIMPORT_VALIDATION_SUMMARY.txt').write_text('\n'.join(concise) + '\n')
    print('\n'.join(concise), flush=True)
    print('VALIDATE_ALL_DONE', summary['status'], flush=True)
    if summary['status'] != 'PASS':
        raise RuntimeError('Reimport validation failed; inspect full per-partition reports.')


if __name__ == '__main__':
    main()
