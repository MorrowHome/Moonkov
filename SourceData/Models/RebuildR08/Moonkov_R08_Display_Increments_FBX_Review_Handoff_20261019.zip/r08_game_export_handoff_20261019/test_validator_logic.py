"""Pure comparison-logic smoke tests; does not import Blender or source assets."""
import copy
import importlib.util
import json
import sys
import types
from pathlib import Path
D = Path(__file__).resolve().parent
sys.modules['bpy'] = types.SimpleNamespace()
spec = importlib.util.spec_from_file_location('validator_under_test', D / 'validate_fbx.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
expected = {'vertices': 4, 'polygons': 2, 'loops': 6, 'triangles': 2,
            'max_polygon_vertices': 3, 'world_bounds': [[4000., 4001.], [0., 1.], [0., 0.]],
            'local_vertex_sha256': 'vertex_hash', 'material_slots': ['MaterialA', 'MaterialB'],
            'face_material_counts': {'MaterialA': 1, 'MaterialB': 1},
            'face_material_sequence_sha256': 'face_identity_hash',
            'uv_layers': [{'name': 'UVMap', 'sha256_float32': 'uv_hash', 'finite': True,
                           'nonzero_geometry_triangles_with_zero_uv_area': 0}]}
row = {'export_object': 'Test', 'source_object': 'Source', 'instance_parent': None,
       'uv_policy': 'preserved_existing_layers_unchanged', 'source_uv_layers': ['UVMap'],
       'matrix_world': [[1., 0., 0., 4000.], [0., 1., 0., 0.], [0., 0., 1., 0.], [0., 0., 0., 1.]],
       'export_snapshot': expected}
actual = copy.deepcopy(expected)
actual.update(matrix_world=row['matrix_world'], pivot_world=[4000., 0., 0.], finite_geometry=True,
              finite_transform=True, invalid_face_material_indices_count=0)
results = []
def case(name, transform, predicate):
    r, a = copy.deepcopy(row), copy.deepcopy(actual)
    transform(r, a)
    v.snapshot = lambda _o, _d: a
    out = v.validate_object(r, None, None)
    assert predicate(out), (name, out)
    results.append({'case': name, 'status': 'PASS'})
case('Identical evaluated snapshot passes', lambda r,a: None, lambda o:o['status']=='PASS')
case('Material slot reorder preserves face identities', lambda r,a:a.update(material_slots=['MaterialB','MaterialA']),
     lambda o:o['status']=='PASS' and o['material_slot_identity_remap'][0]['matching_export_slots']==[1])
case('Wrong per-face material identity hash fails', lambda r,a:a.update(face_material_sequence_sha256='wrong'),
     lambda o:'face_material_identity_sequence_hash_match' in o['failed_checks'])
case('Changed UV float32 hash fails', lambda r,a:a['uv_layers'][0].update(sha256_float32='wrong'),
     lambda o:'uv_float32_integrity:UVMap' in o['failed_checks'])
case('Nonfinite UV fails', lambda r,a:a['uv_layers'][0].update(finite=False),
     lambda o:'uv_finite:UVMap' in o['failed_checks'])
case('World pivot 4 mm difference passes', lambda r,a:a['matrix_world'][0].__setitem__(3,4000.004),
     lambda o:o['checks']['pivot_within_0_005_m_euclidean'])
case('World pivot 6 mm difference fails', lambda r,a:a['matrix_world'][0].__setitem__(3,4000.006),
     lambda o:not o['checks']['pivot_within_0_005_m_euclidean'])
case('Pre-existing degenerate UV is a warning', lambda r,a:r['export_snapshot']['uv_layers'][0].update(nonzero_geometry_triangles_with_zero_uv_area=1),
     lambda o:bool(o['warnings']) and not o['export_quality_issues'])
def generated_degenerate(r,a):
    r['uv_policy']='box_projection_per_face_dominant_local_normal_origin_at_local_bounds_min_1_local_unit_per_repeat'
    r['export_snapshot']['uv_layers'][0]['nonzero_geometry_triangles_with_zero_uv_area']=1
case('Generated degenerate UV is an explicit quality issue', generated_degenerate,
     lambda o:bool(o['export_quality_issues']))
def canonical_zero_proof(r,a):
    r['export_snapshot']['uv_layers'][0]['sha256_float32_canonical_zero']='canonical_hash'
    a['uv_layers'][0]['sha256_float32']='normalized_zero_hash'
    a['uv_layers'][0]['sha256_float32_canonical_zero']='canonical_hash'
case('Export-time canonical-zero proof accepts zero-sign-only bytes', canonical_zero_proof,
     lambda o:o['status']=='PASS' and o['uv_comparison'][0]['signed_zero_only_equivalent'])
def wrong_canonical_zero(r,a):
    canonical_zero_proof(r,a)
    a['uv_layers'][0]['sha256_float32_canonical_zero']='different_nonzero_value'
case('Nonzero change fails canonical-zero proof', wrong_canonical_zero,
     lambda o:'uv_float32_integrity:UVMap' in o['failed_checks'])
def reconstruction_zero(r,a):
    r['uv_policy']='box_projection_per_face_dominant_local_normal_origin_at_local_bounds_min_1_local_unit_per_repeat'
    a['uv_layers'][0]['sha256_float32']='normalized_zero_hash'
    a['uv_layers'][0]['sha256_float32_canonical_zero']='canonical_hash'
    a['uv_layers'][0]['declared_box_projection_reconstruction']={'sha256_float32':'uv_hash','sha256_float32_canonical_zero':'canonical_hash','exact_numeric_equal_to_imported':True}
case('Reconstruction requires matching original raw hash and exact values', reconstruction_zero,
     lambda o:o['status']=='PASS' and o['uv_comparison'][0]['signed_zero_only_equivalent'])
def wrong_reconstructed_hash(r,a):
    reconstruction_zero(r,a)
    a['uv_layers'][0]['declared_box_projection_reconstruction']['sha256_float32']='not_source_uv'
case('Unproven reconstruction fails', wrong_reconstructed_hash,
     lambda o:'uv_float32_integrity:UVMap' in o['failed_checks'])
def changed_reconstructed_numeric(r,a):
    reconstruction_zero(r,a)
    a['uv_layers'][0]['declared_box_projection_reconstruction']['exact_numeric_equal_to_imported']=False
case('Nonzero numeric UV difference fails reconstruction', changed_reconstructed_numeric,
     lambda o:'uv_float32_integrity:UVMap' in o['failed_checks'])
(D/'VALIDATOR_LOGIC_SELF_TEST.json').write_text(json.dumps({'status':'PASS','tests':results},indent=2))
print(json.dumps({'status':'PASS','test_count':len(results)}))
