"""Direct binary FBX checks, independent of Blender importer results."""
import hashlib, json, collections
import numpy as np
def child(e,n):
    return next(x for x in e.elems if x.id==n)

def scalar(e,n):
    return child(e,n).props[0]

def values(e,n):
    return np.asarray(child(e,n).props[0])

def name(e):
    return e.props[1].split(b'\x00')[0].decode()

def validate_binary_geometry(path,rows):
    from io_scene_fbx import parse_fbx
    root,version=parse_fbx.parse(str(path))
    objects=child(root,b'Objects');connections=child(root,b'Connections')
    geo={e.props[0]:e for e in objects.elems if e.id==b'Geometry'}
    models={e.props[0]:e for e in objects.elems if e.id==b'Model'}
    assert len(models)==len(rows)==len(geo)
    assert all(e.props[-1]==b'Mesh' for e in models.values())
    assert not any(e.id in (b'NodeAttribute',b'Texture',b'Video') for e in objects.elems), 'Camera/light/texture payload is forbidden.'
    assert all(e.id not in (b'AnimationStack',b'AnimationLayer',b'AnimationCurve') for e in objects.elems)
    geometry_models={c.props[1]:c.props[2] for c in connections.elems if c.id==b'C' and c.props[0]==b'OO' and c.props[1] in geo and c.props[2] in models}
    assert len(geometry_models)==len(geo)
    expected={r['export_object']:r for r in rows}
    assert {name(e) for e in models.values()}==set(expected)
    details=[]
    for gid,g in geo.items():
        nm=name(models[geometry_models[gid]]);row=expected[nm];snap=row['export_snapshot']
        indices=values(g,b'PolygonVertexIndex');vertices=values(g,b'Vertices')
        assert len(indices)==snap['loops'] and len(vertices)==3*snap['vertices']
        assert np.isfinite(vertices).all()
        assert int(np.sum(indices<0))==snap['polygons']
        lvi=np.where(indices<0,-indices-1,indices).astype(np.int32)
        ends=np.flatnonzero(indices<0)+1;starts=np.concatenate(([0],ends[:-1])).astype(np.int32);totals=(ends-starts).astype(np.int32)
        for key,a in [('loop_vertex_index_sha256',lvi),('polygon_loop_start_sha256',starts),('polygon_loop_total_sha256',totals)]:
            assert hashlib.sha256(a.tobytes()).hexdigest()==snap[key],(nm,key)
        d={'object':nm,'loops':len(indices),'polygons':len(ends),'binary_topology_matches_export_snapshot':True,'tangent_layers':[],'normal_layers':[]}
        for kind,arrayname,dest in [(b'LayerElementTangent',b'Tangents','tangent_layers'),(b'LayerElementBinormal',b'Binormals','binormal_layers'),(b'LayerElementNormal',b'Normals','normal_layers')]:
            layers=[e for e in g.elems if e.id==kind];assert layers,(nm,'Missing',kind)
            d[dest]=[]
            for el in layers:
                a=values(el,arrayname).reshape((-1,3));mapping=scalar(el,b'MappingInformationType');reference=scalar(el,b'ReferenceInformationType')
                assert mapping==b'ByPolygonVertex' and reference in (b'Direct',b'IndexToDirect'),(nm,kind,mapping,reference)
                assert np.isfinite(a).all(), (nm,kind,'nonfinite raw array')
                encoded_vectors=len(a)
                if reference==b'IndexToDirect':
                    ix=values(el,arrayname+b'Index')
                    assert len(ix)==snap['loops'] and int(ix.min())>=0 and int(ix.max())<len(a)
                    a=a[ix]
                assert len(a)==snap['loops'] and np.isfinite(a).all(),(nm,kind,len(a))
                lengths=np.linalg.norm(a,axis=1)
                d[dest].append({'index':el.props[0],'name':scalar(el,b'Name').decode(),'mapping':mapping.decode(),'reference':reference.decode(),'vectors':len(a),'encoded_vectors':encoded_vectors,'finite':True,'zero_vectors':int(np.sum(lengths<1e-6)),'zero_loop_indices':np.flatnonzero(lengths<1e-6).tolist(),'nonunit_vectors':int(np.sum(np.abs(lengths-1)>1e-4)),'length_min':float(lengths.min()),'length_max':float(lengths.max()),'array_sha256':hashlib.sha256(a.tobytes()).hexdigest()})
        assert len(d['tangent_layers'])==len(snap['uv_layers'])==len(d['binormal_layers'])
        details.append(d)
    return {'status':'PASS','geometry_objects':len(details),'model_objects':len(models),'all_binary_topology_arrays_match_export_snapshots':True,'all_binary_tangent_binormal_normal_arrays_present_finite_and_loop_sized':True,'zero_tangent_vectors':sum(l['zero_vectors'] for d in details for l in d['tangent_layers']),'zero_binormal_vectors':sum(l['zero_vectors'] for d in details for l in d['binormal_layers']),'objects':details}


def validate_binary_attributes(path, rows):
    """Inspect vertex, UV, face-material and neutral-placeholder payload directly."""
    from io_scene_fbx import parse_fbx
    root, version = parse_fbx.parse(str(path))
    objects = child(root, b'Objects')
    connections = child(root, b'Connections')
    geometries = {e.props[0]: e for e in objects.elems if e.id == b'Geometry'}
    models = {e.props[0]: e for e in objects.elems if e.id == b'Model'}
    materials = {e.props[0]: e for e in objects.elems if e.id == b'Material'}
    geometry_models = {c.props[1]: c.props[2] for c in connections.elems
                       if c.id == b'C' and c.props[0] == b'OO'
                       and c.props[1] in geometries and c.props[2] in models}
    model_materials = collections.defaultdict(list)
    for c in connections.elems:
        if c.id == b'C' and c.props[0] == b'OO' and c.props[1] in materials and c.props[2] in models:
            model_materials[c.props[2]].append(name(materials[c.props[1]]))
    expected = {r['export_object']: r for r in rows}
    details = []
    for gid, geo in geometries.items():
        mid = geometry_models[gid]
        nm = name(models[mid])
        snap = expected[nm]['export_snapshot']
        xyz = values(geo, b'Vertices').astype(np.float32)
        assert hashlib.sha256(xyz.tobytes()).hexdigest() == snap['local_vertex_sha256'], (nm, 'binary vertices changed')
        uv_layers = [e for e in geo.elems if e.id == b'LayerElementUV']
        assert len(uv_layers) == len(snap['uv_layers'])
        uv_details = []
        for el, target in zip(uv_layers, snap['uv_layers']):
            assert scalar(el, b'Name').decode() == target['name']
            assert scalar(el, b'MappingInformationType') == b'ByPolygonVertex'
            ref = scalar(el, b'ReferenceInformationType')
            assert ref in (b'Direct', b'IndexToDirect')
            a = values(el, b'UV').reshape((-1, 2)).astype(np.float32)
            if ref == b'IndexToDirect':
                ix = values(el, b'UVIndex')
                assert len(ix) == snap['loops'] and int(ix.min()) >= 0 and int(ix.max()) < len(a)
                a = a[ix]
            assert len(a) == snap['loops'] and np.isfinite(a).all()
            raw_sha = hashlib.sha256(a.tobytes()).hexdigest()
            a[a == 0] = 0.0
            canonical_sha = hashlib.sha256(a.tobytes()).hexdigest()
            assert raw_sha == target['sha256_float32'] or canonical_sha == target['sha256_float32_canonical_zero'], (nm, 'binary UV changed')
            uv_details.append({'name': target['name'], 'raw_hash_match': raw_sha == target['sha256_float32'], 'canonical_zero_hash_match': canonical_sha == target['sha256_float32_canonical_zero']})
        mat_layers = [e for e in geo.elems if e.id == b'LayerElementMaterial']
        assert len(mat_layers) == 1
        el = mat_layers[0]
        assert scalar(el, b'ReferenceInformationType') == b'IndexToDirect'
        mapping = scalar(el, b'MappingInformationType')
        indices = values(el, b'Materials')
        if mapping == b'AllSame':
            assert len(indices) == 1
            indices = np.repeat(indices, snap['polygons'])
        else:
            assert mapping == b'ByPolygon'
        assert len(indices) == snap['polygons']
        slots = model_materials[mid]
        assert set(slots) == set(snap['material_slots'])
        assert int(indices.min()) >= 0 and int(indices.max()) < len(slots)
        sequence = [slots[int(i)] for i in indices]
        assert hashlib.sha256(json.dumps(sequence, separators=(',', ':')).encode()).hexdigest() == snap['face_material_sequence_sha256'], (nm, 'binary face material changed')
        details.append({'object': nm, 'binary_vertices_exact_float32': True, 'binary_uv_layers': uv_details,
                        'binary_per_face_material_identity_exact': True})
    common = None
    for mid, mat in materials.items():
        props = {p.props[0].decode(): list(p.props[4:]) for e in mat.elems if e.id == b'Properties70' for p in e.elems}
        assert props['DiffuseColor'] == [0.5, 0.5, 0.5]
        assert props['BumpFactor'] == [0.0] and props['ReflectionFactor'] == [0.0]
        if common is None:
            common = props
        assert common == props, (name(mat), 'Non-neutral divergent placeholder')
    expected_names = {n for r in rows for n in r['export_snapshot']['material_slots'] if n}
    assert {name(m) for m in materials.values()} == expected_names
    assert not any(e.id in (b'Texture', b'Video') for e in objects.elems)
    return {'status': 'PASS', 'objects': details, 'neutral_binary_properties': common,
            'material_names': sorted(expected_names), 'all_binary_material_properties_identical_neutral': True,
            'texture_video_nodes': 0}
