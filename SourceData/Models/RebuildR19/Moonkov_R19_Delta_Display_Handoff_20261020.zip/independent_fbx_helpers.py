"""Pure independent FBX reimport checks inherited from validated R09–R15 checker.
Does not load/save author .blend. Scope-specific validation is in independent_validate_r16.py.
"""
import bpy, collections, hashlib, json, math
import numpy as np
WORLD_TOLERANCE_M = 0.005
LINEAR_TRANSFORM_TOLERANCE = 0.00001
LINEAR_TRANSFORM_RELATIVE_TOLERANCE = 0.000001
IMPORT_SETTINGS = dict(use_manual_orientation=False, global_scale=1.0,
 bake_space_transform=False, use_custom_normals=True, use_image_search=False,
 use_anim=False, use_custom_props=False, ignore_leaf_bones=False, automatic_bone_orientation=False)
def digest_file(path):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def sanitize(value):
    if isinstance(value, dict):
        return {k: sanitize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [sanitize(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return value

def write_json(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(sanitize(value), indent=2, allow_nan=False))
    tmp.replace(path)

def arr(data, prop, dimensions, dtype=np.float32):
    result = np.empty(len(data) * dimensions, dtype=dtype)
    data.foreach_get(prop, result)
    return result.reshape((-1, dimensions))

def sha_array(value):
    return hashlib.sha256(value.tobytes()).hexdigest()

def snapshot(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        matrix = np.array(evaluated.matrix_world, dtype=np.float64)
        xyz = arr(mesh.vertices, 'co', 3)
        world = xyz.astype(np.float64) @ matrix[:3, :3].T + matrix[:3, 3]
        material_indices = arr(mesh.polygons, 'material_index', 1, np.int32).ravel()
        slots = [x.name if x else None for x in mesh.materials]
        assignments = [slots[int(i)] if int(i) < len(slots) else None for i in material_indices]
        invalid_indices = [int(i) for i in material_indices if int(i) >= max(1, len(slots))]
        mesh.calc_loop_triangles()
        tri_loops = arr(mesh.loop_triangles, 'loops', 3, np.int32)
        tri_vertices = arr(mesh.loop_triangles, 'vertices', 3, np.int32)
        tri_xyz = xyz[tri_vertices]
        geom_area2 = np.linalg.norm(np.cross(tri_xyz[:, 1] - tri_xyz[:, 0],
                                             tri_xyz[:, 2] - tri_xyz[:, 0]), axis=1)
        nondegenerate = geom_area2 > 1e-12
        uv_layers = []
        for layer in mesh.uv_layers:
            uv = arr(layer.data, 'uv', 2)
            tri_uv = uv[tri_loops]
            ab = tri_uv[:, 1] - tri_uv[:, 0]
            ac = tri_uv[:, 2] - tri_uv[:, 0]
            uv_area2 = np.abs(ab[:, 0] * ac[:, 1] - ab[:, 1] * ac[:, 0])
            canonical_uv = uv.copy()
            canonical_uv[canonical_uv == 0] = 0.0
            reconstruction = None
            if layer.name.endswith('GameExport_UV0_Box_1LocalUnit'):
                projected = np.empty_like(uv)
                origin_shifted_xyz = xyz.copy()
                origin_shifted_xyz -= origin_shifted_xyz.min(axis=0)
                loop_vertices = arr(mesh.loops, 'vertex_index', 1, np.int32).ravel()
                for polygon in mesh.polygons:
                    axis = int(np.argmax(np.abs(polygon.normal)))
                    axes = ([1, 2], [0, 2], [0, 1])[axis]
                    sl = slice(polygon.loop_start, polygon.loop_start + polygon.loop_total)
                    coordinates = origin_shifted_xyz[loop_vertices[sl]][:, axes].copy()
                    if polygon.normal[axis] < 0:
                        coordinates[:, 0] *= -1
                    projected[sl] = coordinates
                canonical_projected = projected.copy()
                canonical_projected[canonical_projected == 0] = 0.0
                reconstruction = {
                    'sha256_float32': sha_array(projected),
                    'sha256_float32_canonical_zero': sha_array(canonical_projected),
                    'negative_zero_components': int(np.sum((projected == 0) & np.signbit(projected))),
                    'exact_numeric_equal_to_imported': bool(np.array_equal(projected, uv)),
                    'maximum_absolute_numeric_difference': float(np.max(np.abs(projected - uv))) if uv.size else 0.0}
            uv_layers.append({
                'name': layer.name,
                'index': len(uv_layers),
                'sha256_float32': sha_array(uv),
                'sha256_float32_canonical_zero': sha_array(canonical_uv),
                'negative_zero_components': int(np.sum((uv == 0) & np.signbit(uv))),
                'declared_box_projection_reconstruction': reconstruction,
                'finite': bool(np.isfinite(uv).all()),
                'nonzero_geometry_triangles_with_zero_uv_area': int(np.sum(nondegenerate & (uv_area2 <= 1e-12))),
                'range': [[float(uv[:, i].min()), float(uv[:, i].max())] for i in range(2)] if len(uv) else None,
            })
        tangent_reconstruction = []
        if max((p.loop_total for p in mesh.polygons), default=0) <= 4:
            for tangent_uv_name in [layer.name for layer in mesh.uv_layers]:
                try:
                    mesh.calc_tangents(uvmap=tangent_uv_name)
                    t = arr(mesh.loops, 'tangent', 3)
                    signs = arr(mesh.loops, 'bitangent_sign', 1).ravel()
                    lengths = np.linalg.norm(t, axis=1)
                    bad = np.flatnonzero(np.abs(lengths - 1) > 1e-4)
                    affected = np.flatnonzero(np.any(np.isin(tri_loops, bad), axis=1))
                    tangent_reconstruction.append({'uv_layer': tangent_uv_name, 'finite': bool(np.isfinite(t).all() and np.isfinite(signs).all()), 'zero_vectors': int(np.sum(lengths < 1e-6)), 'nonunit_vectors': int(len(bad)), 'nonunit_loop_indices': bad.tolist(), 'affected_triangles': [{'triangle': int(i), 'area2': float(geom_area2[i]), 'geometry_degenerate_at_1e_12': bool(not nondegenerate[i]), 'loops': tri_loops[i].tolist()} for i in affected]})
                finally:
                    mesh.free_tangents()
        return {
            'geometry_degenerate_triangle_count_at_1e_12': int(np.sum(~nondegenerate)),
            'geometry_degenerate_triangle_indices_at_1e_12': np.flatnonzero(~nondegenerate).tolist(),
            'importer_tangent_reconstruction': tangent_reconstruction,
            'vertices': len(mesh.vertices),
            'polygons': len(mesh.polygons),
            'loops': len(mesh.loops),
            'triangles': len(mesh.loop_triangles),
            'world_bounds': [[float(world[:, i].min()), float(world[:, i].max())] for i in range(3)] if len(world) else None,
            'matrix_world': matrix.tolist(),
            'pivot_world': matrix[:3, 3].tolist(),
            'local_vertex_sha256': sha_array(xyz),
            'loop_vertex_index_sha256': sha_array(arr(mesh.loops, 'vertex_index', 1, np.int32)),
            'polygon_loop_start_sha256': sha_array(arr(mesh.polygons, 'loop_start', 1, np.int32)),
            'polygon_loop_total_sha256': sha_array(arr(mesh.polygons, 'loop_total', 1, np.int32)),
            'finite_geometry': bool(np.isfinite(xyz).all() and np.isfinite(world).all()),
            'finite_transform': bool(np.isfinite(matrix).all()),
            'material_slots': slots,
            'invalid_face_material_indices_count': len(invalid_indices),
            'face_material_counts': {('null' if k is None else k): int(v) for k, v in collections.Counter(assignments).items()},
            'face_material_sequence_sha256': hashlib.sha256(json.dumps(assignments, separators=(',', ':')).encode()).hexdigest(),
            'uv_layers': uv_layers,
            'max_polygon_vertices': max((p.loop_total for p in mesh.polygons), default=0),
        }
    finally:
        evaluated.to_mesh_clear()

def difference(a, b):
    aa, bb = np.array(a, dtype=np.float64), np.array(b, dtype=np.float64)
    if aa.shape != bb.shape or not np.isfinite(aa).all() or not np.isfinite(bb).all():
        return None
    return float(np.max(np.abs(aa - bb))) if aa.size else 0.0

def validate_object(row, obj, depsgraph):
    expected = row['export_snapshot']
    actual = snapshot(obj, depsgraph)
    checks, failures, warnings, quality_issues = {}, [], [], []
    def check(name, value):
        checks[name] = bool(value)
        if not value:
            failures.append(name)
    for metric in ('vertices', 'polygons', 'loops', 'triangles', 'max_polygon_vertices'):
        check(metric + '_match', expected[metric] == actual[metric])
    check('finite_geometry', actual['finite_geometry'])
    check('finite_transform', actual['finite_transform'])
    check('reconstructed_tangents_finite', all(t['finite'] for t in actual['importer_tangent_reconstruction']))
    bounds_delta = difference(expected['world_bounds'], actual['world_bounds'])
    check('world_bounds_within_0_005_m', bounds_delta is not None and bounds_delta <= WORLD_TOLERANCE_M)
    expected_matrix = np.array(row['matrix_world'], dtype=np.float64)
    actual_matrix = np.array(actual['matrix_world'], dtype=np.float64)
    pivot_delta = difference(expected_matrix[:3, 3], actual_matrix[:3, 3])
    pivot_euclidean = float(np.linalg.norm(expected_matrix[:3, 3] - actual_matrix[:3, 3]))
    linear_delta = difference(expected_matrix[:3, :3], actual_matrix[:3, :3])
    homogeneous_delta = difference(expected_matrix[3], actual_matrix[3])
    check('pivot_within_0_005_m_euclidean', math.isfinite(pivot_euclidean) and pivot_euclidean <= WORLD_TOLERANCE_M)
    linear_within_tolerance = bool(np.allclose(expected_matrix[:3, :3], actual_matrix[:3, :3], atol=LINEAR_TRANSFORM_TOLERANCE, rtol=LINEAR_TRANSFORM_RELATIVE_TOLERANCE))
    check('linear_transform_within_atol_1e_5_rtol_1e_6', linear_delta is not None and linear_within_tolerance)
    if linear_delta is not None and linear_delta > LINEAR_TRANSFORM_TOLERANCE and linear_within_tolerance:
        warnings.append('Linear matrix absolute difference exceeds 1e-5 but passes declared 1e-6 relative float32 tolerance; world bounds and pivots independently meet the 0.005 m limit.')
    check('homogeneous_transform_preserved', homogeneous_delta is not None and homogeneous_delta <= LINEAR_TRANSFORM_TOLERANCE)
    check('face_material_indices_valid', actual['invalid_face_material_indices_count'] == 0)
    expected_slots = expected['material_slots']
    actual_slots = actual['material_slots']
    check('material_slot_identities_preserved', set(expected_slots) == set(actual_slots))
    check('face_material_identity_counts_match', expected['face_material_counts'] == actual['face_material_counts'])
    check('face_material_identity_sequence_hash_match', expected['face_material_sequence_sha256'] == actual['face_material_sequence_sha256'])
    slot_remap = [{'imported_slot': i, 'material_identity': name,
                   'matching_export_slots': [j for j, other in enumerate(expected_slots) if name == other]}
                  for i, name in enumerate(actual_slots)]
    if expected_slots != actual_slots:
        warnings.append('FBX material slots changed ordering or multiplicity; per-face material identity is checked independently of slot number.')
    if collections.Counter(expected_slots) != collections.Counter(actual_slots):
        warnings.append('Material slot multiplicities differ; see identity remap and face assignment checks.')
    expected_uv_names = [x['name'] for x in expected['uv_layers']]
    actual_uv_names = [x['name'] for x in actual['uv_layers']]
    check('uv_layer_identity_and_order_match', expected_uv_names == actual_uv_names)
    actual_uv_by_name = {x['name']: x for x in actual['uv_layers']}
    uv_details = []
    for layer in expected['uv_layers']:
        imported = actual_uv_by_name.get(layer['name'])
        detail = {'name': layer['name'], 'expected_sha256_float32': layer['sha256_float32'],
                  'actual_sha256_float32': imported['sha256_float32'] if imported else None,
                  'expected_degenerate_uv_triangles': layer['nonzero_geometry_triangles_with_zero_uv_area'],
                  'actual_degenerate_uv_triangles': imported['nonzero_geometry_triangles_with_zero_uv_area'] if imported else None}
        raw_hash_equal = imported is not None and layer['sha256_float32'] == imported['sha256_float32']
        signed_zero_equivalent = False
        proof_method = None
        if imported is not None and not raw_hash_equal:
            expected_canonical = layer.get('sha256_float32_canonical_zero')
            if expected_canonical and expected_canonical == imported.get('sha256_float32_canonical_zero'):
                signed_zero_equivalent = True
                proof_method = 'export_time_canonical_zero_hash_matches_imported_canonical_zero_hash'
        detail['raw_float32_hash_match'] = raw_hash_equal
        detail['signed_zero_only_equivalent'] = signed_zero_equivalent
        detail['signed_zero_equivalence_proof_method'] = proof_method
        detail['actual_sha256_float32_canonical_zero'] = imported.get('sha256_float32_canonical_zero') if imported else None
        if signed_zero_equivalent:
            warnings.append('Raw UV float32 hash differs only by signed zero; exact numerical values are proven equivalent with canonical-zero hashes.')
        check('uv_float32_integrity:' + layer['name'], raw_hash_equal or signed_zero_equivalent)
        check('uv_finite:' + layer['name'], layer['finite'] and imported is not None and imported['finite'])
        if layer['nonzero_geometry_triangles_with_zero_uv_area']:
            generated = row['uv_policy'] != 'preserved_existing_layers_unchanged'
            message = ('Generated' if generated else 'Preserved existing') + ' UV layer ' + layer['name'] + ' has ' + str(layer['nonzero_geometry_triangles_with_zero_uv_area']) + ' nondegenerate geometry triangles with zero UV area (threshold 1e-12 in export snapshot).'
            (quality_issues if generated else warnings).append(message)
        if imported and imported['nonzero_geometry_triangles_with_zero_uv_area'] != layer['nonzero_geometry_triangles_with_zero_uv_area']:
            warnings.append('UV/geometric degeneracy classification differs after reimport for ' + layer['name'] + '; see exact UV hash and geometry checks.')
        if row['uv_policy'] != 'preserved_existing_layers_unchanged':
            check('generated_uv_noncollapsed:' + layer['name'], layer['nonzero_geometry_triangles_with_zero_uv_area'] == 0 and imported is not None and imported['nonzero_geometry_triangles_with_zero_uv_area'] == 0)
        uv_details.append(detail)
    vertex_hash_equal = expected['local_vertex_sha256'] == actual['local_vertex_sha256']
    check('local_vertex_float32_hash_match', vertex_hash_equal)
    for metric in ('loop_vertex_index_sha256', 'polygon_loop_start_sha256', 'polygon_loop_total_sha256'):
        if metric in expected:
            check(metric + '_match', expected[metric] == actual[metric])
    if not vertex_hash_equal:
        warnings.append('Local vertex float32 hash differs; exact local-vertex integrity fails.')
    return {
        'export_object': row['export_object'], 'source_object': row['source_object'],
        'instance_parent': row['instance_parent'], 'persistent_id': row.get('persistent_id'),
        'uv_policy': row['uv_policy'], 'source_uv_layers': row['source_uv_layers'],
        'status': 'PASS' if not failures else 'FAIL', 'checks': checks,
        'failed_checks': failures, 'warnings': warnings, 'export_quality_issues': quality_issues,
        'measurements': {'world_bounds_max_absolute_error_m': bounds_delta,
                         'pivot_max_axis_error_m': pivot_delta, 'pivot_euclidean_error_m': pivot_euclidean,
                         'linear_transform_max_absolute_error': linear_delta,
                         'homogeneous_transform_max_absolute_error': homogeneous_delta,
                         'local_vertex_float32_hash_match': vertex_hash_equal},
        'material_slot_identity_remap': slot_remap, 'uv_comparison': uv_details,
        'expected': dict(expected, matrix_world=row['matrix_world'], pivot_world=expected_matrix[:3, 3].tolist()),
        'actual': actual,
    }

def read_fbx_global_settings(path):
    """Inspect the actual binary FBX units/axes and unexpected texture payloads."""
    from io_scene_fbx import parse_fbx
    root, version = parse_fbx.parse(str(path))
    global_settings = next(e for e in root.elems if e.id == b'GlobalSettings')
    properties = next(e for e in global_settings.elems if e.id == b'Properties70')
    values = {e.props[0].decode(): e.props[4] for e in properties.elems if e.id == b'P' and len(e.props) >= 5}
    required = {'UnitScaleFactor': 100.0, 'OriginalUnitScaleFactor': 100.0,
                'UpAxis': 1, 'UpAxisSign': 1, 'FrontAxis': 2, 'FrontAxisSign': 1,
                'CoordAxis': 0, 'CoordAxisSign': 1}
    assert all(values.get(k) == v for k, v in required.items()), ('Actual FBX units/axes differ', values)
    objects = next(e for e in root.elems if e.id == b'Objects')
    texture_nodes = [e.id.decode() for e in objects.elems if e.id in (b'Texture', b'Video')]
    assert not texture_nodes, ('Unexpected FBX texture/video dependency', texture_nodes)
    return {'fbx_version': version, 'verified_global_settings': required,
            'unit_interpretation': '100 centimetres per FBX unit = 1 metre',
            'texture_or_video_nodes': len(texture_nodes)}
