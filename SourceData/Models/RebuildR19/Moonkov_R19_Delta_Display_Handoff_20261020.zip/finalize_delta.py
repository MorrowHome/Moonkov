import json,hashlib,zipfile,csv
from pathlib import Path
from PIL import Image
import numpy as np
D=Path(__file__).resolve().parent

def digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(n,v):(D/n).write_text(json.dumps(v,indent=2,allow_nan=False))
m=json.loads((D/'EXPORT_MANIFEST.json').read_text());v=json.loads((D/'ROUNDTRIP_SUMMARY.json').read_text());assert v['status']=='PASS'
# Exact unfiltered per-pixel inverse roughness in alpha; new derived files only.
derived=[]
for kind in ['CoatedPanel','MineralBase']:
 src=D/'textures'/f'R19_{kind}_Roughness_Linear.png';a=np.asarray(Image.open(src).convert('RGB'));assert np.array_equal(a[:,:,0],a[:,:,1]) and np.array_equal(a[:,:,0],a[:,:,2]);out=np.zeros((*a.shape[:2],4),dtype=np.uint8);out[:,:,3]=255-a[:,:,0]
 dst=D/'textures'/f'R19_{kind}_MetallicSmoothness_Linear.png';Image.fromarray(out).save(dst);back=np.asarray(Image.open(dst));assert np.array_equal(back,out)
 derived.append({'file':'textures/'+dst.name,'sha256':digest(dst),'bytes':dst.stat().st_size,'source':'textures/'+src.name,'source_sha256':digest(src),'formula':'R=G=B=0; A=255-source_R_8bit. No filtering, color conversion, or source change. Import linear (sRGB false).','role':'Optional standard URP metallic-smoothness input; smoothness multiplier 1, channel alpha. Engine result NOT tested.'})
materials=[]
for x in m['materials']:
 n=x['source_material'];kind='MineralBase' if 'MineralBase' in n else 'CoatedPanel';is_map='PBR' in n
 materials.append({'identity':n,'policy':x['policy'],'new_asset_namespace':'Moonkov/R19/PrivateMaterials' if n.startswith('R19_') else None,'base_color_texture':f'textures/R19_{kind}_BaseColor_sRGB.png' if n in ('R19_CoatedPanel_PRIVATE_PBR','R19_MineralBase_PRIVATE_PBR') else None,'base_color_constant_scene_linear':x['principled_channels']['Base Color']['default'],'base_color_multiplier_if_texture':[1,1,1,1] if n in ('R19_CoatedPanel_PRIVATE_PBR','R19_MineralBase_PRIVATE_PBR') else None,'roughness_texture':f'textures/R19_{kind}_Roughness_Linear.png' if is_map else None,'roughness_constant_if_unlinked':x['principled_channels']['Roughness']['default'],'metallic_constant':x['principled_channels']['Metallic']['default'],'optional_URP_metallic_smoothness_texture':f'textures/R19_{kind}_MetallicSmoothness_Linear.png' if is_map else None,'normal_texture_OpenGL':f'textures/R19_{kind}_Normal_OpenGL.png' if is_map else None,'uv_channel_index':0,'uv_layer':'R19_Meter_UV','texture_scale':[1,1],'texture_offset':[0,0],'normal_strength':1 if is_map else None,'warning':'For R05_exposed_alloy these values are provenance only; reuse verified local material, do not recreate or overwrite it.' if n=='R05_exposed_alloy' else 'Create only dedicated new R19 asset; never remap global old material name.'})
put('MATERIAL_TRANSFER.json',{'materials':materials,'source_graph_provenance':'EXPORT_MANIFEST.json/materials','derived_URP_maps':derived,'texture_rules':{'BaseColor':'sRGB true','Roughness':'sRGB false; do not bind directly as smoothness','Normal':'NormalMap import; tangent-space OpenGL +Y; no automatic green flip; validate under target importer/shader','MetallicSmoothness':'sRGB false; RGB metallic=0; alpha smoothness=1-roughness','UV':'Authored meter-scale in UV0, 4x6m nominal; no additional scale applied','target_shader_verified':False}})
replace=[]
for r in m['objects']:
 if not r['integration_role'].startswith('REPLACE'):continue
 prior=r['prior_object'];replace.append({'source_object':r['source_object'],'stable_export_object':r['export_object'],'prior_partition':prior['partition'],'replacement_partition':r['partition'],'expected_previous_mesh':prior['export_snapshot'],'replacement_mesh':r['export_snapshot'],'matrix_world_blender':r['matrix_world'],'operation':'On unique existing display target only: capture current MeshFilter.sharedMesh + renderer.sharedMaterials + enabled state; swap render mesh and private material slots. Preserve transform, hierarchy, components, collider.sharedMesh and all physics. Never instantiate replacement FBX. If merged/optimized or nonunique, HOLD this replacement; do not disable whole aggregate.','rollback':'Restore captured original display mesh/material references and enabled state; do not touch shared source assets or colliders.'})
put('REPLACEMENT_CONTRACT.json',{'requires_base_package_sha256':m['base_package_sha256'],'replacement_count':9,'additive_count':43,'replacement_targets':replace,'additive_partition':'R19_01_ADDITIVE_FACADE','duplicate_guard':'Before addition, exact stable IDs must be absent from target R19 namespace. Repeat application must be idempotent or stop; never append duplicates.','preserve_existing_optimization':'If an old display is merged, instanced or batched so a single intended owner cannot be proven, do not mutate it. Ask parent for mapping work only; apply other uniquely mapped additions separately.','no_global_name_hide':True,'no_old_asset_overwrite':True,'no_collision_changes':True,'no_DEM_lunar_material_changes':True,'no_118_135_changes':True,'no_automatic_R16_seam_override':True,'R20_excluded':True})
(D/'README_IMPORT_ZH.md').write_text('''# R19 最小显示增量

基线必须是已交接的 R09–R18 累计包（SHA256 见清单）。本包只含 R19，非完整地图，不包含 R20。

## 接入顺序
1. 记录当前场景状态，核实基线与当前用户优化，保留原资产与回退。
2. 将本包放入独立 R19 资产目录，禁用自动生成碰撞，禁止按共享材质名全局覆盖。FBX 材质全为中性身份占位，不是正确外观。
3. 按 MATERIAL_TRANSFER.json 创建四个私有材质并绑定打包 PNG；R05_exposed_alloy 必须复用核实过的当前本地材质。原贴图使用 4×6 米 UV0，材质 tiling 1×1；粗糙度不能直接当平滑度。提供线性、逐像素反相的 MetallicSmoothness 可选贴图。
4. 43 个新增构件可作为唯一 R19 显示根导入；同一稳定 ID 不得重复生成。保持 FBX 原坐标，不重置、居中或重复轴转换，参考基线同一导入方式。
5. 另一个 FBX 是九个已有 R18 墙体的替换网格，仅用于给原唯一对应的 MeshFilter 换 sharedMesh 和私有材质。绝对不要把这个 FBX 整体放入场景造成重叠墙体。REPLACEMENT_CONTRACT.json 包含精确旧分区、GX 名、原网格快照和矩阵。换前记录旧引用，不动 collider.sharedMesh、Transform 或其他组件。
6. 如本地优化后合并了 renderer/submesh，不能唯一定位时先跳过对应替换，禁止按名字全局隐藏或删除整个合并网格。其它安全增量可继续。
7. 必要静态检查后，仅小步本地 commit，不 push，不混入用户其他改动。

## 验证范围
实际 FBX 二进制检查和逐分区空场景回读，详见 ROUNDTRIP_SUMMARY.json。原 blend 文件未保存或修改；PBR 内外图像逐字节核实。无 Unity 编译、Shader 外观、实机、碰撞或性能通过声明。旧 R09–R18 的文字 UV、切线与 R16 实例替换门槛仍保持，未由本包解决。

## 回退
移除或禁用新增的独立 R19 显示根；九个原墙恢复此前记录的 mesh/material 引用与 enabled 状态。保持原材质、原模型、原碰撞、月面和既有优化文件。无需改动灯/按钮。
''')
with (D/'OBJECT_MAPPING.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['role','source_object','stable_export_object','partition','prior_partition'])
 for r in m['objects']:w.writerow([r['integration_role'],r['source_object'],r['export_object'],r['partition'],r.get('prior_object',{}).get('partition','')])
files=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and '__pycache__' not in str(p) and p.suffix not in ('.log','.zip') and p.name not in ['PACKAGE_CONTENTS.json','ARCHIVE_VERIFICATION.json','PRELIMINARY_REPLACEMENT_TARGETS.json']:
  files.append({'file':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':digest(p)})
put('PACKAGE_CONTENTS.json',{'files':files})
Z=D.parent/'Moonkov_R19_Delta_Display_Handoff_20261020.zip'
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,6) as z:
 for p in files:z.write(D/p['file'],p['file'])
 z.write(D/'PACKAGE_CONTENTS.json','PACKAGE_CONTENTS.json')
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 for r in files:assert hashlib.sha256(z.read(r['file'])).hexdigest()==r['sha256']
put('ARCHIVE_VERIFICATION.json',{'path':str(Z),'bytes':Z.stat().st_size,'sha256':digest(Z),'members':len(files)+1,'CRC_and_all_member_SHA256':'PASS','source_R19_sha256':m['source_sha256'],'roundtrip':v})
print(Z,Z.stat().st_size,digest(Z))
