"""R19 only; in-memory evaluated copies. Never saves author .blend."""
import bpy,json,hashlib,sys,collections,numpy as np
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from export_helpers import mesh_snapshot,arr,sha
from ngon_helpers import split_ngons
S=Path(bpy.data.filepath);EXPECTED='b61cfb1c9e1b35fad0b3a1d287b3ddda1845c448397e0511fae00367f4c7acdc'
def digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(n,v):(D/n).write_text(json.dumps(v,indent=2,allow_nan=False))
assert digest(S)==EXPECTED
prior=json.loads((D.parent/'r09_r18_cumulative_game_export_handoff_20261020/EXPORT_MANIFEST.json').read_text());old={r['source_object']:r for r in prior['objects']}
contract=json.loads((D.parent/'moonkov_rebuild_R19_service_facade_20261020/R19_ALLOWED_CHANGE_CONTRACT.json').read_text())
repls={r['object']:r for r in contract['allowed_original_changes']};adds=set(contract['new_objects']);assert len(repls)==9 and len(adds)==43
put('source_contracts/R19_ALLOWED_CHANGE_CONTRACT.json',contract)
put('source_contracts/R18_REPLACED_OBJECT_ROWS.json',[old[n] for n in sorted(repls)])
bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();rows=[];pending=[];mats=set();proofs=[]
geomkeys=['vertices','polygons','loops','triangles','world_bounds','local_vertex_sha256','max_polygon_vertices','loop_vertex_index_sha256','polygon_loop_start_sha256','polygon_loop_total_sha256']
for n in sorted(set(repls)|adds):
 o=bpy.data.objects[n];assert o.type=='MESH' and o.data.users==1 and o.visible_get() and not o.hide_render
 ev=o.evaluated_get(dg);mat=ev.matrix_world.copy();me=bpy.data.meshes.new_from_object(ev,preserve_all_data_layers=True,depsgraph=dg);snap=mesh_snapshot(me,mat)
 assert len(me.uv_layers)==1 and all(u['finite'] for u in snap['uv_layers'])
 role='REPLACE_DISPLAY_MESH_AND_MATERIALS_ONLY' if n in repls else 'ADD_DISPLAY_ONLY'
 pn='R19_00_REPLACEMENT_MESHES_DO_NOT_INSTANTIATE' if n in repls else 'R19_01_ADDITIVE_FACADE'
 name='GX_'+hashlib.sha256(json.dumps([n,None,[]],separators=(',',':')).encode()).hexdigest()[:12]+'_'+n[:44]
 if n in repls:
  assert name==old[n]['export_object'] and [list(x) for x in mat]==old[n]['matrix_world']
  assert all(snap[k]==old[n]['source_snapshot'][k] for k in geomkeys),(n,'Geometry mismatch')
  assert all(snap[k]==old[n]['export_snapshot'][k] for k in geomkeys),(n,'Old export geometry mismatch')
 me,pr=split_ngons(me);out=mesh_snapshot(me,mat)
 me.calc_tangents(uvmap=me.uv_layers[0].name);t=arr(me.loops,'tangent',3);b=arr(me.loops,'bitangent_sign',1);zero=np.where(np.linalg.norm(t,axis=1)<=.9)[0].tolist();assert np.isfinite(t).all() and np.isfinite(b).all();me.free_tangents()
 row=dict(revision='R19',source_object=n,source_type='MESH',source_data=o.data.name,source_collections=[c.name for c in o.users_collection],instance_parent=None,persistent_id=None,matrix_world=[list(x) for x in mat],source_snapshot=snap,pretri_snapshot=snap,export_snapshot=out,export_object=name,partition=pn,source_uv_layers=[u.name for u in o.data.uv_layers],uv_policy='preserved_existing_layers_unchanged',integration_role=role,tangent_check={'finite':True,'unit_tangents':not zero,'nonunit_loop_indices':zero})
 if n in repls:row['prior_object']={k:old[n][k] for k in ('source_object','export_object','partition','matrix_world','export_snapshot')}
 rows.append(row);pending.append((name,me,mat,pn));mats.update(out['material_slots'])
 if pr:proofs.append(dict(source_object=n,proof=pr))
# Capture exact source channel graph, separate from deliberately neutral FBX identities.
materials=[]
for n in sorted(mats):
 m=bpy.data.materials[n];p=next(x for x in m.node_tree.nodes if x.type=='BSDF_PRINCIPLED');channels={}
 for s in ('Base Color','Metallic','Roughness','IOR','Alpha'):
  inp=p.inputs[s];v=inp.default_value
  try:v=list(v)
  except TypeError:pass
  channels[s]={'default':v,'links':[{'node':l.from_node.name,'type':l.from_node.type,'image':l.from_node.image.name if l.from_node.type=='TEX_IMAGE' else None} for l in inp.links]}
 nodes=[]
 for node in m.node_tree.nodes:
  nodes.append({'name':node.name,'type':node.type,'image':node.image.name if node.type=='TEX_IMAGE' and node.image else None,'uv_map':getattr(node,'uv_map',None),'extension':getattr(node,'extension',None),'space':getattr(node,'space',None),'normal_strength':node.inputs['Strength'].default_value if node.type=='NORMAL_MAP' else None})
 materials.append({'source_material':n,'policy':'CREATE_NEW_PRIVATE_MATERIAL_ONLY' if n.startswith('R19_') else 'REUSE_VERIFIED_EXISTING_LOCAL_MATERIAL_ONLY_DO_NOT_OVERWRITE','principled_channels':channels,'nodes':nodes,'links':[{'from':[l.from_node.name,l.from_socket.name],'to':[l.to_node.name,l.to_socket.name]} for l in m.node_tree.links]})
images=[]
for n in contract['new_images']:
 im=bpy.data.images[n];assert len(im.packed_files)==1;data=im.packed_files[0].packed_file.data;p=D/'textures'/(n+'.png');assert p.read_bytes()==data
 images.append({'source_image':n,'file':'textures/'+p.name,'bytes':len(data),'sha256':digest(p),'color_space':im.colorspace_settings.name,'dimensions':list(im.size)})
stubs={}
for n in sorted(mats):
 bpy.data.materials[n].name='EXPORT_MEMORY_ONLY_ORIGINAL_'+n;m=bpy.data.materials.new(n);m.use_nodes=False;m.diffuse_color=(.5,.5,.5,1);stubs[n]=m
scene=bpy.data.scenes.new('R19_DELTA_EXPORT_ONLY');scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1;parts=collections.defaultdict(list)
for row,(name,me,mat,pn) in zip(rows,pending):
 for i,n in enumerate(row['export_snapshot']['material_slots']):me.materials[i]=stubs[n]
 o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.matrix_world=mat;parts[pn].append(o)
bpy.context.window.scene=scene;bpy.context.view_layer.update();settings=prior['settings'].copy();settings['object_types']=set(settings['object_types']);files=[]
for pn,obs in sorted(parts.items()):
 path=D/'fbx'/(pn+'.fbx');assert not path.exists();bpy.ops.object.select_all(action='DESELECT')
 for o in obs:o.select_set(True)
 bpy.context.view_layer.objects.active=obs[0];assert bpy.ops.export_scene.fbx(filepath=str(path),**settings)=={'FINISHED'}
 files.append({'name':pn,'file':'fbx/'+path.name,'objects':len(obs),'bytes':path.stat().st_size,'sha256':digest(path)})
put('EXPORT_MANIFEST.json',{'schema':'R19_DELTA_FOR_R09_R18_BASE_V1','source_sha256':EXPECTED,'source_bytes':S.stat().st_size,'source':str(S),'base_package_sha256':'6a34722eda6de2d0f7696b346da3083500b7e5965eaf2f924246f3d7cfcfdb85','objects':rows,'partitions':files,'materials':materials,'images':images,'settings':prior['settings'],'units':prior['units'],'ngon_export_copy_proofs':proofs,'source_hash_after':digest(S),'limits':['FBX materials are neutral identity placeholders, NOT appearance. Bind private PBR using MATERIAL_TRANSFER.json.','Nine replacement meshes must be assigned only to uniquely mapped existing R18 display objects; never instantiate duplicate walls.','No collider, optimized aggregate, source shared asset, terrain or light/button changes.','No Unity compile, renderer mapping, shader appearance, play or performance validation.']})
assert digest(S)==EXPECTED
print('R19_EXPORT_COMPLETE',len(rows),flush=True)
