import numpy as np
import hashlib,collections,json
def arr(data,prop,dim,dtype=np.float32):
 a=np.empty(len(data)*dim,dtype=dtype);data.foreach_get(prop,a);return a.reshape((-1,dim))

def sha(a):return hashlib.sha256(a.tobytes()).hexdigest()

def mesh_snapshot(me,m):
 xyz=arr(me.vertices,'co',3); w=xyz@np.array(m,dtype=np.float64)[:3,:3].T+np.array(m,dtype=np.float64)[:3,3]
 pmat=arr(me.polygons,'material_index',1,np.int32).ravel(); slots=[x.name if x else None for x in me.materials]; assignments=[slots[int(i)] if int(i)<len(slots) else None for i in pmat]
 me.calc_loop_triangles();stats=[]
 tri_loops=arr(me.loop_triangles,'loops',3,np.int32);tri_vertices=arr(me.loop_triangles,'vertices',3,np.int32);tri_xyz=xyz[tri_vertices];geom_area2=np.linalg.norm(np.cross(tri_xyz[:,1]-tri_xyz[:,0],tri_xyz[:,2]-tri_xyz[:,0]),axis=1);nongenerate=geom_area2>1e-12
 for u in me.uv_layers:
  uv=arr(u.data,'uv',2);tuv=uv[tri_loops];a=tuv[:,1]-tuv[:,0];b=tuv[:,2]-tuv[:,0];uvarea2=np.abs(a[:,0]*b[:,1]-a[:,1]*b[:,0]);stats.append({'name':u.name,'index':len(stats),'sha256_float32':sha(uv),'finite':bool(np.isfinite(uv).all()),'nonzero_geometry_triangles_with_zero_uv_area':int(np.sum(nongenerate & (uvarea2<=1e-12))),'range':[[float(uv[:,i].min()),float(uv[:,i].max())] for i in range(2)] if len(uv) else None})
 return {'vertices':len(me.vertices),'polygons':len(me.polygons),'loops':len(me.loops),'triangles':len(me.loop_triangles),'world_bounds':[[float(w[:,i].min()),float(w[:,i].max())] for i in range(3)],'local_vertex_sha256':sha(xyz),'material_slots':slots,'face_material_counts':dict(collections.Counter(assignments)),'face_material_sequence_sha256':hashlib.sha256(json.dumps(assignments,separators=(',',':')).encode()).hexdigest(),'uv_layers':stats,'max_polygon_vertices':max(p.loop_total for p in me.polygons)}

def uv_project(me):
 uv=me.uv_layers.new(name='R09_R12_GameExport_UV0_Box_1LocalUnit');coords=np.empty((len(me.loops),2),dtype=np.float32)
 xyz=arr(me.vertices,'co',3);xyz-=xyz.min(axis=0);vi=arr(me.loops,'vertex_index',1,np.int32).ravel()
 for p in me.polygons:
  ax=int(np.argmax(np.abs(p.normal)));axes=([1,2],[0,2],[0,1])[ax];q=xyz[vi[p.loop_start:p.loop_start+p.loop_total]][:,axes].copy()
  if p.normal[ax]<0:q[:,0]*=-1
  coords[p.loop_start:p.loop_start+p.loop_total]=q
 uv.data.foreach_set('uv',coords.ravel());uv.active_render=True;me.uv_layers.active_index=0
 return 'box_projection_per_face_dominant_local_normal_origin_at_local_bounds_min_1_local_unit_per_repeat'

def repair(me):
 me.calc_loop_triangles();xyz=arr(me.vertices,'co',3).astype(np.float64);lv=arr(me.loops,'vertex_index',1,np.int32).ravel();tl=arr(me.loop_triangles,'loops',3,np.int32);tp=arr(me.loop_triangles,'polygon_index',1,np.int32).ravel();tv=arr(me.loop_triangles,'vertices',3,np.int32)
 g=xyz[tv];area=np.linalg.norm(np.cross(g[:,1]-g[:,0],g[:,2]-g[:,0]),axis=1);valid=area>1e-12;uv=arr(me.uv_layers[0].data,'uv',2);changed=[]
 bases=[np.eye(3)[:,[0,1]],np.eye(3)[:,[0,2]],np.eye(3)[:,[1,2]]]
 for n in ([1.,2.,3.],[2.,3.,5.],[3.,5.,7.],[1.,np.sqrt(2),np.sqrt(3)]):
  n=np.array(n);n/=np.linalg.norm(n);u=np.cross(n,[0,0,1]);u/=np.linalg.norm(u);v=np.cross(n,u);bases.append(np.stack([u,v],axis=1))
 for p in me.polygons:
  ids=np.where((tp==p.index)&valid)[0]
  if not len(ids):continue
  t=uv[tl[ids]].astype(np.float64);a=t[:,1]-t[:,0];b=t[:,2]-t[:,0];aa=np.abs(a[:,0]*b[:,1]-a[:,1]*b[:,0])
  if np.min(aa)>1e-12:continue
  local=xyz[lv[p.loop_start:p.loop_start+p.loop_total]];local=local-local.mean(axis=0);tri=tl[ids]-p.loop_start;best=None
  for idx,basis in enumerate(bases):
   candidate=(local@basis).astype(np.float32);t=candidate[tri].astype(np.float64);a=t[:,1]-t[:,0];b=t[:,2]-t[:,0];score=float(np.min(np.abs(a[:,0]*b[:,1]-a[:,1]*b[:,0])))
   if best is None or score>best[0]:best=(score,candidate,idx)
  assert best[0]>1e-12,(p.index,best[0],area[ids].tolist())
  uv[p.loop_start:p.loop_start+p.loop_total]=best[1];changed.append({'polygon':p.index,'alternate_basis_index':best[2],'minimum_uv_area2':best[0]})
 me.uv_layers[0].data.foreach_set('uv',uv.ravel());return changed
base_snapshot=mesh_snapshot
def mesh_snapshot(me,m):
 s=base_snapshot(me,m)
 for key,data,prop in [('loop_vertex_index_sha256',me.loops,'vertex_index'),('polygon_loop_start_sha256',me.polygons,'loop_start'),('polygon_loop_total_sha256',me.polygons,'loop_total')]:s[key]=sha(arr(data,prop,1,np.int32))
 for row,layer in zip(s['uv_layers'],me.uv_layers):
  uv=arr(layer.data,'uv',2);uv[uv==0]=0;row['sha256_float32_canonical_zero']=sha(uv)
 return s
