"""Factory-empty per-FBX roundtrip plus direct binary validation; no author save."""
import bpy,json,sys,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from independent_fbx_helpers import digest_file,write_json,validate_object,read_fbx_global_settings,IMPORT_SETTINGS
from independent_binary_r16 import validate_binary_geometry,validate_binary_attributes
m=json.loads((D/'EXPORT_MANIFEST.json').read_text());reports=[]
for p in m['partitions']:
 rows=[r for r in m['objects'] if r['partition']==p['name']];path=D/p['file'];assert digest_file(path)==p['sha256']
 out={'partition':p['name'],'binary_geometry':validate_binary_geometry(path,rows),'binary_attributes':validate_binary_attributes(path,rows),'fbx_settings':read_fbx_global_settings(path)}
 bpy.ops.wm.read_factory_settings(use_empty=True);assert len(bpy.data.objects)==0
 assert bpy.ops.import_scene.fbx(filepath=str(path),**IMPORT_SETTINGS)=={'FINISHED'};bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();obs={o.name:o for o in bpy.context.scene.objects}
 assert set(obs)=={r['export_object'] for r in rows};out['objects']=[validate_object(r,obs[r['export_object']],dg) for r in rows]
 out['status']='PASS' if all(o['status']=='PASS' for o in out['objects']) else 'FAIL';reports.append(out);write_json(D/(p['name']+'_ROUNDTRIP.json'),out)
 print('R19_PARTITION_VALIDATION',p['name'],out['status'],flush=True)
assert digest_file(Path(m['source']))==m['source_sha256']
summary={'status':'PASS' if all(r['status']=='PASS' for r in reports) else 'FAIL','partitions':len(reports),'objects':sum(len(r['objects']) for r in reports),'max_world_bounds_error_m':max(o['measurements']['world_bounds_max_absolute_error_m'] for r in reports for o in r['objects']),'max_pivot_error_m':max(o['measurements']['pivot_euclidean_error_m'] for r in reports for o in r['objects']),'quality_gates':[{'object':o['source_object'],'warnings':o['warnings'],'quality':o['export_quality_issues']} for r in reports for o in r['objects'] if o['export_quality_issues'] or any('zero UV' in w for w in o['warnings'])],'nonunit_export_tangents':[{'object':r['source_object'],'check':r['tangent_check']} for r in m['objects'] if not r['tangent_check']['unit_tangents']],'source_unchanged':True,'Unity_verified':False}
write_json(D/'ROUNDTRIP_SUMMARY.json',summary);assert summary['status']=='PASS';print('R19_ROUNDTRIP_COMPLETE',flush=True)
