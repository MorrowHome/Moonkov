"""Static foot-only FBX audit in a NEW background Blender process; no scene save/apply.
Run: blender -b --factory-startup --python verify_fbx_static.py
No source .blend is loaded. Never run this in an interactive unsaved session.
"""
import bpy,json,hashlib,math
from pathlib import Path
from mathutils import Vector
from io_scene_fbx import parse_fbx
assert bpy.app.background,'Use a NEW background process, not an interactive editing session.'
P=Path(__file__).resolve().parent;c=json.loads((P/'FOOT0541_GEOMETRY_AND_LOCAL_GATE.json').read_text());fbx=P/'R22_FOOT0541_DISPLAY_ONLY.fbx';NEW=c['object'];MAT=c['source_material_name'];reference=c['triangles'];matrix=c['matrix_world_blender']
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def elem(x,k):return next(e for e in x.elems if e.id==k)
def vecs(a,n):return [list(a[i:i+n]) for i in range(0,len(a),n)]
root,version=parse_fbx.parse(str(fbx));objects=elem(root,b'Objects');counts={}
for e in objects.elems:counts[e.id.decode()]=counts.get(e.id.decode(),0)+1
assert counts.get('Geometry')==1 and counts.get('Model')==1 and counts.get('Material')==1
assert not any(counts.get(x,0) for x in ['Texture','Video','NodeAttribute','AnimationStack','AnimationLayer'])
props={e.props[0].decode():e.props[-1] for e in elem(elem(root,b'GlobalSettings'),b'Properties70').elems if e.id==b'P'};props={k:(v.decode('utf-8') if isinstance(v,bytes) else v) for k,v in props.items()};assert props['UnitScaleFactor']==100.
g=elem(objects,b'Geometry');verts=vecs(elem(g,b'Vertices').props[0],3);polyinds=elem(g,b'PolygonVertexIndex').props[0]
ln=elem(g,b'LayerElementNormal');lu=elem(g,b'LayerElementUV');ls=elem(g,b'LayerElementSmoothing')
assert elem(ln,b'MappingInformationType').props[0]==b'ByPolygonVertex' and elem(ln,b'ReferenceInformationType').props[0]==b'IndexToDirect'
normals=vecs(elem(ln,b'Normals').props[0],3);ni=list(elem(ln,b'NormalsIndex').props[0]);uv=vecs(elem(lu,b'UV').props[0],2);ui=list(elem(lu,b'UVIndex').props[0]);uvname=elem(lu,b'Name').props[0].decode()
assert elem(lu,b'MappingInformationType').props[0]==b'ByPolygonVertex' and elem(lu,b'ReferenceInformationType').props[0]==b'IndexToDirect'
assert all(v==0 for v in elem(ls,b'Smoothing').props[0]),'Original flat face flags not retained'
raw=[];ids=[];loops=[]
for i,v in enumerate(polyinds):
 ids.append(v if v>=0 else -v-1);loops.append(i)
 if v<0:
  assert len(ids)==3
  raw.append({'xyz':[verts[v] for v in ids],'uv':{uvname:[uv[ui[j]] for j in loops]},'corner_normals':[normals[ni[j]] for j in loops],'material':MAT});ids=[];loops=[]
assert len(raw)==24 and len(verts)==14

def compare(rows,normal_required):
 assert len(rows)==24
 used=set();maxg=maxuv=maxn=0.;matched_faces=[]
 def triangle_match(f,corner_ids):
  found=[]
  for j,u in enumerate(rows):
   if j in used or u['material']!=f['material']:continue
   for k in range(3):
    order=[(i+k)%3 for i in range(3)]
    ge=max((Vector(f['xyz'][q])-Vector(u['xyz'][order[i]])).length for i,q in enumerate(corner_ids))
    ue=max(abs(f['uv'][n][q][v]-u['uv'][n][order[i]][v]) for n in f['uv'] for i,q in enumerate(corner_ids) for v in range(2))
    ne=max((Vector(f['corner_normals'][q])-Vector(u['corner_normals'][order[i]])).length for i,q in enumerate(corner_ids))
    if ge<.001 and ue<1e-5:found.append((j,k,ge,ue,ne))
  return found
 for f in c['polygons']:
  n=len(f['xyz']);assert n in [3,4]
  layouts=[[[0,1,2]]] if n==3 else [[[0,1,2],[0,2,3]],[[0,1,3],[1,2,3]]]
  solutions=[]
  for li,layout in enumerate(layouts):
   matches=[triangle_match(f,ids) for ids in layout]
   if all(len(m)==1 for m in matches) and len({m[0][0] for m in matches})==len(layout):solutions.append((li,[m[0] for m in matches]))
  assert len(solutions)==1,('source polygon triangulation/winding/UV must match uniquely',f['source_face_index'],solutions)
  layout,matches=solutions[0]
  for j,k,ge,ue,ne in matches:
   used.add(j);maxg=max(maxg,ge);maxuv=max(maxuv,ue);maxn=max(maxn,ne)
   if normal_required:assert ne<1e-4,('corner normal difference',f['source_face_index'],ne)
  matched_faces.append({'source_polygon':f['source_face_index'],'legal_quad_diagonal_option':layout if n==4 else None,'matched_FBX_triangles':[m[0] for m in matches]})
 assert len(used)==24
 return {'max_local_coordinate_error_m':maxg,'max_UV_error':maxuv,'max_corner_normal_vector_error':maxn,'max_corner_normal_angular_error_degrees_bound':math.degrees(2*math.asin(min(1,maxn/2))),'17_source_polygons_24_triangles_unique_winding_UV_material_match':True,'triangulation_rule':'Either valid diagonal of each original planar quad; per-corner XYZ, winding, UV and normals preserved. Exporter need not choose Blender display-cache diagonal.','source_polygon_matches':matched_faces}
raw_result=compare(raw,True)

def import_probe(custom):
 bpy.ops.wm.read_factory_settings(use_empty=True);assert bpy.ops.import_scene.fbx(filepath=str(fbx),use_custom_normals=custom)=={'FINISHED'}
 obs=list(bpy.context.scene.objects);assert len(obs)==1 and obs[0].type=='MESH' and obs[0].name==NEW
 o=obs[0];me=o.data;me.calc_loop_triangles();assert [m.name for m in me.materials]==[MAT] and not bpy.data.images
 rows=[{'xyz':[list(me.vertices[i].co) for i in t.vertices],'uv':{u.name:[list(u.data[i].uv) for i in t.loops] for u in me.uv_layers},'corner_normals':[list(me.corner_normals[i].vector) for i in t.loops],'material':me.materials[t.material_index].name} for t in me.loop_triangles]
 error=max(abs(matrix[i][j]-o.matrix_world[i][j]) for i in range(4) for j in range(4));assert error<.001
 result=compare(rows,not custom);result.update(use_custom_normals=custom,has_custom_normals=me.has_custom_normals,smooth_polygons=sum(p.use_smooth for p in me.polygons),max_world_matrix_element_error=error,readback_vertices=len(me.vertices),readback_polygons=len(me.polygons))
 return result
custom_result=import_probe(True);flat_result=import_probe(False)
assert custom_result['max_corner_normal_vector_error']<1e-4
report={'status':'PASS_STATIC_FOOT_FBX_RAW_DATA_AND_BOTH_NORMAL_READBACKS','fbx_file':fbx.name,'fbx_bytes':fbx.stat().st_size,'fbx_sha256':sha(fbx),'source_R22_sha256_reference':c['source_R22_sha256'],'source_vertices':14,'source_polygons':17,'source_triangles':24,'full_blend_loaded_saved_or_rendered':False,'FBX_version':version,'FBX_object_types':counts,'FBX_global_settings':props,'textures_referenced_or_embedded':0,'source_material_name':MAT,'source_unit_scale_m':1,'FBX_unit_scale_cm':100,'original_flat_face_flags_preserved':True,'raw_binary_geometry_UV_normals':raw_result,'Blender_reimport_original_flat_normals':flat_result,'Blender_reimport_custom_normals_diagnostic':custom_result,'normal_export_history':'Prototype without explicit FACE smoothing metadata produced a custom-normal reimport discrepancy and was not delivered. Final FBX retains original flat-face flags; stored normals and both custom-normal/flat-normal reimports match source within the stated strict threshold. Unity importer/shading still requires local inspection.','source_material_stub_only':True,'Unity_local_ownership_foot_surface_collision_runtime_performance':'NOT_RUN; gates remain closed','parent_pixels':'Earlier isolated source view accepted; no new render for this export.'}
put('STATIC_EXPORT_READBACK.json',report)
print('RAW_FBX_AND_ORIGINAL_FLAT_REIMPORT_PASS',json.dumps({'raw':raw_result,'flat':flat_result,'custom_probe':custom_result}),flush=True)
