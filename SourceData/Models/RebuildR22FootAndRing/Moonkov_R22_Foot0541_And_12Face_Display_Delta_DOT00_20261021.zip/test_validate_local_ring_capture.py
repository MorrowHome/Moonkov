#!/usr/bin/env python3
"""Source-derived SYNTHETIC tests only. These are NOT DOT00/local Unity captures.

Run: python test_validate_local_ring_capture.py
Uses the adjacent complete source contract; generates no files or Unity changes.
"""
import copy
import json
import unittest
from pathlib import Path
import validate_local_ring_capture as v


def owner(n):
    return {"scene_asset_path": "Assets/SYNTHETIC_TEST_ONLY.unity",
            "scene_guid": "1"*32,
            "renderer_global_object_id": "GlobalObjectId_V1-1-" + "1"*32 + "-" + str(n) + "-0",
            "mesh_asset_path": "Assets/SYNTHETIC_TEST_ONLY_" + str(n) + ".asset",
            "mesh_guid": format(n, "032x"), "mesh_local_file_id": "4300000"}


def make_triangle(face, corners, i, slots, positions):
    material = face["material"]
    submesh = slots.index(material)
    position = positions.get(submesh, 0)
    positions[submesh] = position + 1
    xyz = [face["xyz"][k] for k in corners]
    uv = {"UVMap": [face["uv"]["UVMap"][k] for k in corners]}
    return {"triangle_id": "SYNTHETIC_TRI_" + str(i), "submesh": submesh,
            "triangle_index_in_submesh": position, "vertex_indices": [i*3, i*3+1, i*3+2],
            "xyz": copy.deepcopy(xyz), "raw_xyz": copy.deepcopy(xyz),
            "uv": copy.deepcopy(uv), "raw_uv": copy.deepcopy(uv), "material": material}


def fixture(alternative=False):
    contract = json.loads(Path(__file__).with_name("RING_12_FACE_DELTA_CONTRACT.json").read_text())
    slots = sorted({f["material"] for f in contract["baseline_source_faces"]})
    triangles, positions = [], {}
    for face in contract["baseline_source_faces"]:
        variants = v.face_alternatives(face)
        group = variants[-1] if alternative else variants[0]
        for corners in group:
            triangles.append(make_triangle(face, corners, len(triangles), slots, positions))
    identity4 = [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
    normalization = {"units": "meters", "space": "blender_source_local", "winding": "source_polygon",
                     "verified_from_local_receipt_and_scene_refs": True,
                     "source_matrix_world_blender": contract["matrix_world_blender"],
                     "mesh_local_to_blender_source_local": identity4,
                     "mesh_uv_to_source_uv": [[1,0,0],[0,1,0],[0,0,1]], "normalized_corner_order": [0,1,2]}
    protected = []
    for n, (name, obj) in enumerate(contract["protected_prior_R21_faces"]["objects"].items(), 2):
        if name == v.SOURCE:
            ts = sorted([t for t in triangles if t["material"] == v.NEW], key=lambda t: t["triangle_id"])
            o = owner(1)
        else:
            ts, ps = [], {}
            for face in obj["faces"]:
                for corners in v.face_alternatives(face)[0]:
                    ts.append(make_triangle(face, corners, len(ts), [v.NEW], ps))
            ts = sorted(ts, key=lambda t: t["triangle_id"])
            o = owner(n)
        protected.append({"source_object": name, "owner": o, "mesh_asset_sha256": "a"*64,
                          "source_face_count": len(obj["faces"]), "triangle_ids": [t["triangle_id"] for t in ts],
                          "protected_triangle_records_sha256": v.sha(v.canonical(ts))})
    material = {"name": v.NEW, "asset_path": "Assets/SYNTHETIC_TEST_ONLY.mat", "guid": "9"*32}
    common = {"source_object": v.SOURCE, "source_mesh": contract["source_mesh"], "owner": owner(1),
              "mesh_asset_sha256": "a"*64, "scene_asset_sha256": "b"*64,
              "vertex_streams_sha256": "c"*64, "material_slots": slots,
              "collider_references_sha256": "e"*64,
              "normalization": normalization, "protected_prior_r21": protected,
              "existing_finish_material": material}
    capture = dict(copy.deepcopy(common), schema="r22-normalized-triangle-capture-v1",
                   vertex_count=len(triangles)*3, submesh_count=len(slots), triangles=triangles)
    receipt = dict(copy.deepcopy(common), schema="r22-dot00-readonly-receipt-v1", verified_by="DOT00",
                   verification_mode="read_only", r21_delivery_receipt={"path": v.R21_PATH, "sha256": "d"*64},
                   verified_r21_commits=sorted(v.COMMITS), existing_private_material_count=1,
                   existing_private_mesh_clone_count=5)
    return contract, capture, receipt


def run_validation(parts, repin=True):
    c, a, r = parts
    ch, ah = v.sha(v.canonical(c)), v.sha(v.canonical(a))
    if repin:
        r["contract_sha256"], r["capture_sha256"] = ch, ah
    rh = v.sha(v.canonical(r))
    return v.validate(c, a, r, ch, ah, rh, rh)


class ValidatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = fixture()

    def fresh(self):
        return copy.deepcopy(self.base)

    def assertBlocked(self, parts, reason=None):
        with self.assertRaises(v.Blocked) as caught:
            run_validation(parts)
        if reason:
            self.assertIn(reason, str(caught.exception))

    def test_full_baseline_proposal(self):
        result = run_validation(self.fresh())
        self.assertEqual(result["status"], "VALID_PROPOSAL_ONLY")
        self.assertEqual(result["complete_clone_triangle_count"], 2604)
        self.assertEqual(len(result["plan"]), 24)
        self.assertFalse(result["applied"])
        self.assertEqual(len({x["triangle_id"] for x in result["plan"]}), 24)

    def test_all_alternative_quad_diagonals(self):
        self.assertEqual(run_validation(fixture(True))["proposed_triangle_count"], 24)

    def test_cyclic_corner_rotation(self):
        p = self.fresh(); t = self.target_triangle(p)
        for key in ("xyz", "raw_xyz", "vertex_indices"):
            t[key] = t[key][1:] + t[key][:1]
        for key in ("uv", "raw_uv"):
            t[key]["UVMap"] = t[key]["UVMap"][1:] + t[key]["UVMap"][:1]
        self.assertEqual(run_validation(p)["proposed_triangle_count"], 24)

    def test_reviewed_mirror_and_corner_parity(self):
        p = self.fresh()
        for item in (p[1], p[2]):
            n = item["normalization"]
            n["mesh_local_to_blender_source_local"][0] = [-1,0,0,17]
            n["normalized_corner_order"] = [0,2,1]
        for t in p[1]["triangles"]:
            t["raw_xyz"] = [[17-t["xyz"][j][0],t["xyz"][j][1],t["xyz"][j][2]] for j in [0,2,1]]
            t["raw_uv"]["UVMap"] = [copy.deepcopy(t["uv"]["UVMap"][j]) for j in [0,2,1]]
        protected = sorted([t for t in p[1]["triangles"] if t["material"] == v.NEW], key=lambda t:t["triangle_id"])
        for item in (p[1],p[2]):
            row = next(x for x in item["protected_prior_r21"] if x["source_object"] == v.SOURCE)
            row["protected_triangle_records_sha256"] = v.sha(v.canonical(protected))
        self.assertEqual(run_validation(p)["proposed_triangle_count"], 24)

    def target_triangle(self, parts):
        f = parts[0]["target_faces"][0]
        return next(t for t in parts[1]["triangles"] if v.matches(t, f, (0,1,2), 0.001, 1e-5))

    def test_changed_uv(self):
        p = self.fresh(); t = self.target_triangle(p)
        t["uv"]["UVMap"][0][0] += .01; t["raw_uv"]["UVMap"][0][0] += .01
        self.assertBlocked(p, "Missing or ambiguous")

    def test_wrong_material(self):
        p = self.fresh(); self.target_triangle(p)["material"] = v.NEW
        self.assertBlocked(p, "material/submesh")

    def test_duplicate_triangle_id(self):
        p = self.fresh(); p[1]["triangles"][1]["triangle_id"] = p[1]["triangles"][0]["triangle_id"]
        self.assertBlocked(p, "Duplicate triangle ID")

    def test_extra_duplicate_triangle(self):
        p = self.fresh(); p[1]["triangles"].append(copy.deepcopy(self.target_triangle(p)))
        self.assertBlocked(p, "full target clone")

    def test_duplicate_geometry_preserving_count(self):
        p = self.fresh(); a = self.target_triangle(p); b = p[1]["triangles"][-1]
        for key in ("xyz", "raw_xyz", "uv", "raw_uv"):
            b[key] = copy.deepcopy(a[key])
        # Distinct IDs and vertex indices, same geometry: never select arbitrarily.
        self.assertBlocked(p, "Ambiguous/duplicate")

    def test_reversed_winding(self):
        p = self.fresh(); t = self.target_triangle(p)
        for key in ("xyz", "raw_xyz"):
            t[key][1], t[key][2] = t[key][2], t[key][1]
        for key in ("uv", "raw_uv"):
            t[key]["UVMap"][1], t[key]["UVMap"][2] = t[key]["UVMap"][2], t[key]["UVMap"][1]
        self.assertBlocked(p, "Missing or ambiguous")

    def test_false_normalization(self):
        p = self.fresh(); self.target_triangle(p)["raw_xyz"][0][0] += 1
        self.assertBlocked(p, "reviewed affine")

    def test_protected_overlap(self):
        p = self.fresh(); tid = self.target_triangle(p)["triangle_id"]
        for obj in (p[1], p[2]):
            row = next(x for x in obj["protected_prior_r21"] if x["source_object"] == v.SOURCE)
            row["triangle_ids"][0] = tid
        self.assertBlocked(p, "Missing or changed existing R21")

    def test_missing_receipt(self):
        p = self.fresh(); p[2].clear()
        self.assertBlocked(p, "Missing trusted DOT00")

    def test_missing_other_renderer(self):
        p = self.fresh(); p[2]["protected_prior_r21"].pop()
        self.assertBlocked(p, "five existing")

    def test_unknown_owner(self):
        p = self.fresh(); p[2]["owner"]["mesh_guid"] = "unknown"
        self.assertBlocked(p, "unresolved owner")

    def test_missing_baseline_face(self):
        p = self.fresh(); p[0]["baseline_source_faces"].pop()
        self.assertBlocked(p, "complete 1,604")

    def test_capture_hash_binding(self):
        p = self.fresh(); run_validation(p); p[1]["vertex_count"] += 1
        with self.assertRaisesRegex(v.Blocked, "exact contract and capture bytes"):
            run_validation(p, repin=False)

    def test_receipt_pin_binding(self):
        c,a,r = self.fresh(); ch,ah = v.sha(v.canonical(c)),v.sha(v.canonical(a))
        r["contract_sha256"],r["capture_sha256"] = ch,ah
        with self.assertRaisesRegex(v.Blocked, "receipt hash mismatch"):
            v.validate(c,a,r,ch,ah,v.sha(v.canonical(r)),"0"*64)

    def test_json_duplicate_key(self):
        with self.assertRaisesRegex(v.Blocked, "Duplicate JSON key"):
            v.parse_json(b'{"a":1,"a":2}')

    def test_changed_collider_references(self):
        p = self.fresh(); p[1]["collider_references_sha256"] = "f"*64
        self.assertBlocked(p, "collider_references_sha256")

    def test_non_target_digest_tolerates_only_ordinal_shift(self):
        t = copy.deepcopy(self.base[1]["triangles"][0])
        before = v.canonical(v.non_target_record(t))
        t["triangle_index_in_submesh"] += 1
        self.assertEqual(before, v.canonical(v.non_target_record(t)))
        t["submesh"] += 1
        self.assertNotEqual(before, v.canonical(v.non_target_record(t)))


if __name__ == "__main__":
    unittest.main(verbosity=2)
