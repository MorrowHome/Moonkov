"""Exact rollback to preserved R29 display state; refuses edited increments. No save."""
import bpy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import combined_display_common as C
from apply_combined_display import restore_host

def rollback():
    data=C.mapping();C.verify_payload(data)
    assert C.MARKER in bpy.context.scene,'No combined handoff receipt on this scene.'
    receipt=json.loads(bpy.context.scene[C.MARKER])
    assert receipt['mapping_sha256']==C.sha(C.ROOT/C.MAPPING),'Receipt/mapping mismatch.'
    C.verify_applied(data)
    assert 'R29_R35_Display_Export_Copies' not in bpy.data.scenes,'Remove the temporary export-copy scene first, or reopen preserved R29.'
    added=set(receipt['created']['objects'])
    for n in added:
        o=bpy.data.objects[n]
        assert not o.data or o.type!='MESH' or o.data.users==1,'Added mesh has other users; reopen R29 instead of destructive rollback.'
        assert all(c.name in data['collections'] for c in o.users_collection),'Added object was linked elsewhere; inspect before rollback.'
    for cname in data['collections']:
        assert set(bpy.data.collections[cname].all_objects.keys())<=added,'Collection contains user-added objects; stop.'
    restore_host(data)
    for n in receipt['created']['objects']:bpy.data.objects.remove(bpy.data.objects[n],do_unlink=True)
    for n in receipt['created']['collections']:bpy.data.collections.remove(bpy.data.collections[n])
    for kind in ['meshes','materials','node_groups','images']:
        seq=getattr(bpy.data,kind)
        for n in receipt['created'][kind]:
            block=seq.get(n)
            if block and block.users==0:seq.remove(block)
    del bpy.context.scene[C.MARKER];bpy.context.view_layer.update()
    for name,signature in data['baseline_guards'].items():assert C.object_signature(bpy.data.objects[name])==signature,'Rollback baseline differs: '+name
    print('Rolled back: R29 host restored; combined collections removed; shared materials/textures preserved. Not saved.')

if __name__=='__main__':rollback()
