"""Read-only R29 and package preflight. No scene edits, save, export or render."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from combined_display_common import preflight
if __name__=='__main__':
    data=preflight()
    print('PASS: 36 R29 object guards, seven shared material guards and all package payload hashes. No scene edits.')
