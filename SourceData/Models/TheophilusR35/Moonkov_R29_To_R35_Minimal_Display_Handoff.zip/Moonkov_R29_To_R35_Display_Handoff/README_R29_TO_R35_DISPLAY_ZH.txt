Moonkov：现有 R29 → 现有 R35 美术显示合并交接
2026-10-15 | Blender 4.3.2 | 仅整理既有成果，不是新增美术版本

结论
本包补齐本地只有 R29 时缺少的 R32 几何、R34 表面 UV/烘焙材质和 R35 驱动壳链路。
不需要 R33 程序材质步骤，不需要先下载/打开 R32、R34、R35 完整大场景。
最新完整参考仍是 Moonkov_R35_Actuator_Housing_Current_Candidate.blend，未被替换或修改。
本包不是已导入 Unity 的工程、FBX 成品或实机验收结果。

最小有效负载
1. Moonkov_R32_R35_Eleven_Display_Meshes.blend
   精确 11 个既有新增显示网格，2 个空根，2 个独立集合。
   无场景、相机、灯光、材质、图像或共用纹理。材质槽按 JSON 严格绑定到接收方现有材质。
2. Moonkov_R34_Baked_Materials_Only_Delta.blend
   两个已经完成的 R34 烘焙材质，原文件字节不变。只通过随包纹理取样。
3. textures/：原 R34 的 10 张 PNG，像素/文件字节不变。
   两组 BaseColor、Metallic、Roughness、NormalTS、MetallicSmoothness。
   Blender 实际接入 8 张，另 2 张 MetallicSmoothness 供已有 Standard/URP 流程接线。
4. 精确映射、只读预检、应用、回退、可选导出副本准备、检查记录和 SHA256 清单。
不含完整大场景、预览图、基础工业/月壤纹理包，也不重复 R35 旧增量捎带的共用钢材纹理。

接收前提和守卫
- 在保留原件的 R29 Blender 工作副本里操作；不要覆盖唯一原件。
- 需要现有 R29 最终显示几何、正常的原材质/贴图依赖，且尚未装 R32/R33/R34/R35。
- 36 个精确对象守卫：34 个最终 R29 显示网格 + 原护罩 + 原前鼓制动对象。
- 检查几何/拓扑、所有原 UV、世界变换/父级逆矩阵、材质槽和逐面赋值、修改器、可见性、刚体状态等。
- 严格验证 7 个共用材质的节点/输入/连接与其图像字节；没有名字近似或 .001 自动容错。
- 导入前验证 12 个资产文件的 SHA256；拒绝已有同名集合、网格、材质、图像冲突。
- 当前只验证 Blender 4.3.2，脚本限制 4.3.x。其他版本、局部改过的 R29 或本地来源差异应先诊断；不要注释掉守卫强行导入。
- 实测基线是云端重建 R29，SHA256：
  d21ab7dbc1ad458a4dd6bf9c84591d867d42dbaf1cf4b74546286a11b04c35a0
  守卫核对实际对象内容，不要求本地文件路径或整文件哈希等于云端文件。

应用顺序
1. 完整解压本包，保持脚本、JSON、两个 .blend 和 textures/ 的相对位置。
2. 打开保留好的 R29 工作副本，退出编辑/雕刻模式。保留现有 R29 基础贴图位置。
3. 可先运行 CHECK_ONLY.py；它只读检查，不修改场景。
4. 运行 apply_combined_display.py。它按顺序：
   全部预检 → 导入 11 个无材质显示网格 → 绑定 7 个现有共用材质 →
   应用两处 R34 UV/材质补丁 → 严格核对最终结果 → 记录回退清单。
   不执行 R33，不调用 R32/R35 旧版应用脚本，不保存、不导出、不渲染。
5. 核对后按原有工作流程另存新文件，保留 R29 原件和本包纹理位置。
   新图像路径相对当前 Blender 文件计算。移动或另存时保留/重映射其相对位置；不要删除本包 textures/。

在 Blender Python Console 的运行方式示例（把路径换成真实解压目录）：
import runpy
runpy.run_path(r"D:\你的解压目录\CHECK_ONLY.py", run_name="__main__")
runpy.run_path(r"D:\你的解压目录\apply_combined_display.py", run_name="__main__")
该示例是交接说明。本次没有操作 Windows 或在本地执行命令。

精确两处补丁
A. R20_11_Drawworks_Armor_And_Cable_Returns：源 polygon 2。
   R29 原面材质 R8_OffWhite_Ceramic_Coat 保留在原槽，仅此面换到 R34_01_Service_Shroud_Baked_PBR。
   直接适配器新槽 10；R35 完整候选保留 R33 历史槽，那里新槽是 11。
B. 新增 R32_02_Recessed_Sealed_Brake_Access_Cover：源 polygon 10–19。
   原 R24_Slate_Gray_Industrial_Enamel 槽保留，仅所列面换到 R34_02_Brake_Cover_Baked_PBR。
   直接适配器新槽 3；R35 完整候选中是 4。
两处只新增 R34_Display_Surface_UV，保持原 UV 数值、原活动/渲染 UV 不变。
数字是 Blender 源网格的 0-based polygon index，不是 Unity 三角形索引。
槽号与 R35 历史候选不同是有意省去未使用的 R33 槽；逐面最终材质名、几何、UV 和变换已独立核对相同。
除了 A，全部既有 R29 对象不改；B 是本包新导入对象。

11 个显示网格清单
R32_01_Deep_Maintenance_Rim_And_Mount
R32_02_Recessed_Sealed_Brake_Access_Cover
R32_03_Extraction_Guides_Stops_And_Two_Cams
R32_04_Lubrication_Return_Lines_And_Two_Supports
R32_05_Service_Plate_Arrow_And_Ledge_Dust
R32_06_DW01_Brake_Service_Stencil
R35_01_Split_Cast_Housing_Cheeks
R35_02_Split_Flange_And_Sealing_Land
R35_03_Registered_Removable_Actuator_Cap
R35_04_Four_Cap_Studs_And_Two_Split_Clamps
R35_05_Load_Return_Ribs_And_Lower_Keys
集合：B_R32_DRAWWORKS_MAINTENANCE_CASSETTE_DISPLAY
      B_R35_FRONT_DRUM_ACTUATOR_HOUSING_DISPLAY
空根：R32_MAINTENANCE_CASSETTE_DISPLAY_ROOT
      R35_ACTUATOR_HOUSING_DISPLAY_ROOT

共用依赖（接收方已有，本包不携带）
R23_Protective_Steel_Microfinish
R24_Dark_Forged_Joint_Steel
R24_Exposed_Machined_Contact_Steel
R24_Localized_Lunar_Dust_Deposit
R24_Recessed_Elastomer_Seal
R24_Service_Stencil_Offwhite
R24_Slate_Gray_Industrial_Enamel
其中钢材沿用 R8_Dark_Protective_Steel_MetallicGloss.png；通过现有材质复用，不追加副本。
全部原 R29 场景依赖仍由原场景提供。包不替用户补回缺失的基础纹理，也不重定向它们。

可选：显示 UV0 导出准备
合并应用成功后可运行 prepare_display_export_copies.py。
它只在内存建立独立 R29_R35_Display_Export_Copies 场景：11 个新增网格副本 + 原护罩显示副本，合计 12 网格、2 空根。
两个目标表面写入副本 UV0，其余面的 UV0 不改；保留原 UV1+，移除仅用于 Blender 的额外 R34 UV 层。
只有这两个临时副本使用材质副本，把 UVMap/Normal Map 的 UV 指向该 UV0；这不是新设计材质。
保持原件、父子变换、几何及修改器；不保存、不导出、不创建碰撞或光照 UV。
该临时场景已按精确世界矩阵检查，旋转字样的本地变换不经多余重分解。
按项目已有流程处理倒角/法线/三角化、轴向/尺度和 FBX 导出；不要把原件和副本一起重复导出。
在 Unity 端需保留原护罩和旧渲染器作为回退，并按既有替换流程处理护罩显示副本，避免与原护罩双重渲染；不要自动替换碰撞/交互/地形或全局源资产。
本包没有自动执行上述 Unity 操作，也没有验证本地导入器。

贴图接线约定
- BaseColor：sRGB；材质颜色乘数白。
- Metallic、Roughness：线性单通道。
- NormalTS：RGB16 PNG，线性，切线空间 +Y/OpenGL；按 Normal map 导入，强度 1，不无条件翻绿通道。
- MetallicSmoothness：线性 RGBA8；R=Metallic，G=B=0，A=1-Roughness。
  Standard/URP 既有 Metallic 流程使用 Metallic Alpha 的 Smoothness，乘数 1。
- Tiling 1,1，Offset 0,0，Wrap Clamp。没有 AO、Emission 或 Height 图。
- Shroud 2048×2048；Cover 2048×1024。BaseColor 没有灯光/阴影/AO/曝光烘入。
- HDRP 不能直接把 MetallicSmoothness 当 Mask Map；其他管线需按已用着色器要求接线。
- 切线基、色彩空间、压缩、反射/罩光模型可能导致目标管线差异，未以改灯方式掩盖。

回退
完整回退：先移除整个临时导出副本场景及其副本，或直接重新打开保留的 R29。
在合并后的工作场景运行 rollback_combined_display.py，可恢复原护罩面赋值、移除新增 R34 UV/槽、移除两个新增显示集合及本次导入的未使用数据。
守卫会拒绝已经改过的增量、挪到别处/被复用的网格或混入用户新对象的集合；不会以删除共用材质/纹理来强行清理。
回退脚本不保存。最可靠的完整回退始终是重新打开保留的 R29 原件。
仅隐藏两集合不等于完整回退：原护罩的 R34 表面补丁仍在。不要把“关集合”误作恢复 R29。

本次实际检查
- 核实 R32/R34/R35 原源文件与映射哈希；开始和结束时均没有遗留 Blender 构建进程。
- 最新 R35 目标几何、变换、原 UV、新显示 UV 与逐面最终材质语义相符。
- 从云端重建 R29 在隔离 Blender 内存中组合应用成功；11 网格、2 空根、2 已有材质、8 已有图像数据块，10 PNG 随包。
- 首次组合检查确认：除一个必要护罩表面补丁外，2245 个原对象不变；60 个原材质、90 个原图像不变；相机/灯光/世界/曝光/渲染设置不变；无缺失外链依赖。
- 可选导出副本最初在旋转字样精确矩阵检查失败；已修复交接脚本保持原本地变换，未放宽精度守卫。只针对导出准备/回退再验证，未重复全场比较。
- 修复后 12 网格显示导出副本准备通过；随后回退成功，原数据块名称集合精确恢复，旧源/候选哈希不变。
- 0 次渲染，0 次保存完整场景，0 次新模型/材质/纹理制作；未改旧版本文件。

未验证
本地 Windows 的 R29 实际内容是否通过本包守卫；Windows/Unity 工程、FBX 导入器、实机视觉与性能；目标着色器/法线压缩/三角化；MC00、DEM、碰撞、交互、灯光和 lightmap。
Windows 在父任务 18:16 UTC 已核实离线，本轮未操作它。云端检查不能代替本地验收。
若本地守卫失败，保留报错和工作副本，定位具体对象/材质/依赖差异后修交接，不删守卫继续。
