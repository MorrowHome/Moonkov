"""Run on an unchanged R29 working copy. All guards precede edits. No save/export."""
import bpy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import combined_display_common as C

def cleanup_added(before):
    # Remove only datablocks created by this invocation, never original shared resources.
    for name in set(bpy.data.objects.keys())-before['objects']:
        bpy.data.objects.remove(bpy.data.objects[name],do_unlink=True)
    for name in set(bpy.data.collections.keys())-before['collections']:
        bpy.data.collections.remove(bpy.data.collections[name])
    for kind in ['meshes','materials','node_groups','images']:
        seq=getattr(bpy.data,kind)
        for name in set(seq.keys())-before[kind]:
            block=seq[name]
            if block.users==0:seq.remove(block)

def restore_host(data):
    spec=data['patches'][0];o=bpy.data.objects[spec['object']];m=o.data
    if C.UV in m.uv_layers:m.uv_layers.remove(m.uv_layers[C.UV])
    # Slots were appended, never reordered. Restore only this host's original assignments.
    m.polygons.foreach_set('material_index',spec['baseline_face_indices'])
    while len(m.materials)>len(spec['baseline_slots']):m.materials.pop(index=len(m.materials)-1)
    m.uv_layers.active_index=spec['original_uv_active_index'];m.uv_layers[spec['original_uv_render']].active_render=True

def apply():
    data=C.preflight()
    with bpy.data.libraries.load(str(C.ROOT/'Moonkov_R34_Baked_Materials_Only_Delta.blend'),link=False) as (lib,dst):
        assert set(lib.materials)=={s['new'] for s in data['patches']}
        assert not any(n in bpy.data.images for n in lib.images), 'Baked image name conflict; start from clean R29.'
    before={kind:set(getattr(bpy.data,kind).keys()) for kind in ['objects','collections','meshes','materials','node_groups','images']}
    host_touched=False
    try:
        with bpy.data.libraries.load(str(C.ROOT/'Moonkov_R32_R35_Eleven_Display_Meshes.blend'),link=False) as (lib,dst):
            assert set(lib.collections)==set(data['collections']) and not lib.materials and not lib.images
            dst.collections=data['collections']
        for coll in dst.collections:bpy.context.scene.collection.children.link(coll)
        for rec in data['added_objects']:
            o=bpy.data.objects[rec['name']]
            if o.type=='MESH':
                assert not o.data.materials
                for name in rec['materials']:o.data.materials.append(bpy.data.materials[name])
                o.data.polygons.foreach_set('material_index',rec['face_material_indices'])
        bpy.context.view_layer.update()
        for rec in data['added_objects']:
            assert C.object_signature(bpy.data.objects[rec['name']])==rec['before_patch_signature'], 'Imported display mesh/UV/transform differs: '+rec['name']
        with bpy.data.libraries.load(str(C.ROOT/'Moonkov_R34_Baked_Materials_Only_Delta.blend'),link=False) as (lib,dst):
            dst.materials=[s['new'] for s in data['patches']]
        for spec in data['patches']:
            o=bpy.data.objects[spec['object']];m=o.data
            assert C.UV not in m.uv_layers
            assert [mat.name for mat in m.materials]==spec['baseline_slots']
            assert [p.material_index for p in m.polygons]==spec['baseline_face_indices']
            for rec in spec['uv_faces']:
                p=m.polygons[rec['face']]
                assert list(p.vertices)==rec['vertices'] and list(p.loop_indices)==rec['loop_indices'],'Face identity differs: '+o.name
            if spec['key']=='Shroud':host_touched=True
            uv=m.uv_layers.new(name=C.UV,do_init=True)
            for rec in spec['uv_faces']:
                for li,co in zip(rec['loop_indices'],rec['uv']):uv.data[li].uv=co
            m.uv_layers.active_index=spec['original_uv_active_index'];m.uv_layers[spec['original_uv_render']].active_render=True
            mat=bpy.data.materials[spec['new']];m.materials.append(mat)
            assert len(m.materials)-1==spec['applied_slot']
            for fi in spec['faces']:m.polygons[fi].material_index=spec['applied_slot']
            for node in mat.node_tree.nodes:
                if node.type=='TEX_IMAGE' and node.image:
                    p=(C.ROOT/spec['texture_files'][node.name]).resolve()
                    node.image.filepath=bpy.path.relpath(str(p)) if bpy.data.filepath else str(p)
        bpy.context.view_layer.update();C.verify_applied(data)
        receipt={'mapping_sha256':C.sha(C.ROOT/C.MAPPING),'created':{k:sorted(set(getattr(bpy.data,k).keys())-before[k]) for k in before},'baseline_filepath':bpy.data.filepath}
        bpy.context.scene[C.MARKER]=json.dumps(receipt)
        print('Applied: 11 display meshes, two empty roots, two R34 surface/UV patches. No save, render, export or Unity changes.')
        return receipt
    except Exception:
        if host_touched:restore_host(data)
        cleanup_added(before);bpy.context.view_layer.update()
        assert C.object_signature(bpy.data.objects[data['patches'][0]['object']])==data['baseline_guards'][data['patches'][0]['object']]
        raise

if __name__=='__main__':apply()
