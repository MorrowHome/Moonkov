"""Strict R29-to-R35 display-only handoff. Blender 4.3.2; no save/export/install."""
import bpy, array, hashlib, json
from pathlib import Path
from compat_semantics import project_values,clone_flags,sockets,socket_index,socket_name,legacy_nh
ROOT = Path(__file__).resolve().parent
MAPPING = 'R29_TO_R35_DISPLAY_MAPPING.json'
UV = 'R34_Display_Surface_UV'
MARKER = 'MOONKOV_R29_TO_R35_DISPLAY_RECEIPT'

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def values(value):
    result={}
    for p in value.bl_rna.properties:
        if p.identifier in {'rna_type','name','session_uid'} or p.type in {'POINTER','COLLECTION'} or p.is_readonly: continue
        try:
            v=getattr(value,p.identifier)
            result[p.identifier]=list(v) if p.is_array else v
        except: pass
    return project_values(value,result)

def array_hash(seq,attr,n,typ):
    a=array.array(typ,[0])*n; seq.foreach_get(attr,a)
    return hashlib.sha256(a.tobytes()).hexdigest()

def geometry(o):
    m=o.data
    return {key:array_hash(seq,attr,n,t) for key,seq,attr,n,t in [
      ('vertices',m.vertices,'co',len(m.vertices)*3,'f'),
      ('edges',m.edges,'vertices',len(m.edges)*2,'i'),
      ('loops',m.loops,'vertex_index',len(m.loops),'i'),
      ('polygon_starts',m.polygons,'loop_start',len(m.polygons),'i'),
      ('polygon_lengths',m.polygons,'loop_total',len(m.polygons),'i'),
      ('smooth',m.polygons,'use_smooth',len(m.polygons),'b')]}

def uv_signature(m):
    flags=clone_flags(m)
    return {'layers':[[u.name,array_hash(u.data,'uv',len(u.data)*2,'f'),u.active_render,flags[i]] for i,u in enumerate(m.uv_layers)], 'active':m.uv_layers.active_index}

def face_materials(o):
    return [o.data.materials[p.material_index].name if len(o.data.materials)>p.material_index and o.data.materials[p.material_index] else None for p in o.data.polygons]

def object_signature(o):
    result={'type':o.type,'matrix_world':[list(r) for r in o.matrix_world],
      'matrix_parent_inverse':[list(r) for r in o.matrix_parent_inverse],
      'parent':o.parent.name if o.parent else None,'hide_render':o.hide_render,'hide_viewport':o.hide_viewport,'hide_set':o.hide_get(),
      'modifiers':[[m.name,m.type,values(m)] for m in o.modifiers],
      'constraints':[[c.name,c.type,values(c)] for c in o.constraints],
      'rigid_body':o.rigid_body is not None,'rigid_body_constraint':o.rigid_body_constraint is not None}
    if o.type=='MESH':
        result.update({'geometry':geometry(o),'uv':uv_signature(o.data),'slots':[m.name if m else None for m in o.data.materials],
          'face_material_indices':array_hash(o.data.polygons,'material_index',len(o.data.polygons),'i'),
          'face_material_names':digest(face_materials(o))})
    return result

def image_identity(im):
    assert im.source=='FILE', 'Unsupported shared image type: '+im.name
    h=hashlib.sha256(im.packed_file.data).hexdigest() if im.packed_file else sha(bpy.path.abspath(im.filepath))
    return {'name':im.name,'sha256':h,'colorspace':im.colorspace_settings.name,'alpha_mode':im.alpha_mode}

def material_signature(mat):
    def tree(t):
        nodes=[]
        for n in t.nodes:
            ins=[]
            for i,s,sname in sockets(n,'inputs'):
                if hasattr(s,'default_value'):
                    v=s.default_value
                    if isinstance(v,(str,int,float,bool)):ins.append([i,sname,v])
                    elif hasattr(v,'__len__'):ins.append([i,sname,list(v)])
            rec={'name':n.name,'type':n.bl_idname,'properties':values(n),'inputs':ins}
            if hasattr(n,'image') and n.image: rec['image']=image_identity(n.image)
            if n.type=='GROUP' and n.node_tree: rec['group']=tree(n.node_tree)
            nodes.append(rec)
        return {'nodes':nodes,'links':[[l.from_node.name,socket_index(l.from_node,'outputs',l.from_socket),l.to_node.name,socket_index(l.to_node,'inputs',l.to_socket)] for l in t.links]}
    return digest({'properties':values(mat),'nodes':tree(mat.node_tree) if mat.use_nodes else None})

def mapping(): return json.loads((ROOT/MAPPING).read_text(encoding='utf-8'))

def verify_payload(data):
    for name,rec in data['payload'].items():
        p=ROOT/name
        assert p.is_file() and p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'], 'Missing or changed package payload: '+name

def preflight(data=None):
    data=data or mapping(); verify_payload(data)
    from compat_readonly import runtime_guard
    runtime_guard()
    assert bpy.context.mode=='OBJECT','Leave Edit/Sculpt mode first.'
    assert MARKER not in bpy.context.scene,'Combined delta already applied.'
    assert not any(n in bpy.data.collections for n in data['collections']), 'A target collection already exists; start from the preserved R29 working copy.'
    for rec in data['added_objects']:
        assert rec['name'] not in bpy.data.objects, 'Conflicting object: '+rec['name']
        if rec.get('mesh_name'): assert rec['mesh_name'] not in bpy.data.meshes, 'Conflicting mesh datablock: '+rec['mesh_name']
    for spec in data['patches']:
        assert spec['new'] not in bpy.data.materials,'Conflicting baked material: '+spec['new']
        assert spec['old_r33'] not in bpy.data.materials,'R33 is present; use a clean R29 copy.'
    for name,expected in data['baseline_guards'].items():
        o=bpy.data.objects.get(name); assert o is not None,'Missing R29 baseline object: '+name
        actual=object_signature(o)
        assert actual==expected, 'R29 baseline differs: '+name+' / '+', '.join(k for k in expected if actual.get(k)!=expected[k])
    for name,expected in data['reused_material_signatures'].items():
        m=bpy.data.materials.get(name)
        assert m is not None and material_signature(m)==expected, 'Shared material differs or its texture is missing: '+name
    host=bpy.data.objects[data['patches'][0]['object']]
    assert host.data.users==1, 'Shroud mesh has linked users; do not patch it in place.'
    assert UV not in host.data.uv_layers,'Display UV layer already exists.'
    return data

def verify_applied(data=None):
    data=data or mapping()
    for rec in data['added_objects']:
        o=bpy.data.objects.get(rec['name']); assert o is not None,'Missing added object: '+rec['name']
        assert object_signature(o)==rec['applied_signature'], 'Applied display object differs: '+rec['name']
    for name,expected in data['applied_host_signatures'].items():
        assert object_signature(bpy.data.objects[name])==expected, 'Applied host differs: '+name
    for name,h in data['baked_material_signatures'].items():
        assert material_signature(bpy.data.materials[name])==h, 'Baked material differs: '+name
    return data

# Detect stale cached code after a script overlay. Restart Blender before preflight.
COMPAT_SOURCE_SHA256=sha(__file__)
