"""Optional staging only: 12 display meshes in a separate in-memory scene.
11 additive meshes plus the patched original shroud. Only the two patch surfaces
receive R34 UV values in export UV0. No save/export, colliders, lightmap UV or project edits.
"""
import bpy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import combined_display_common as C
assert C.ROOT.resolve()==Path(__file__).resolve().parent,'Common module belongs to another package directory; restart Blender.'

def prepare():
    from compat_readonly import runtime_guard
    runtime_guard()
    from compat_readonly import module
    module(C.ROOT)
    data=C.verify_applied();name='R29_R35_Display_Export_Copies'
    assert C.MARKER in bpy.context.scene,'Apply combined delta first.'
    assert name not in bpy.data.scenes,'Export-copy scene exists; inspect instead of duplicating.'
    scene=bpy.data.scenes.new(name);scene.unit_settings.system=bpy.context.scene.unit_settings.system;scene.unit_settings.scale_length=bpy.context.scene.unit_settings.scale_length
    names=[r['name'] for r in data['added_objects']]+[data['patches'][0]['object']]
    copies={}
    for n in names:
        src=bpy.data.objects[n];o=src.copy()
        if o.type=='MESH':o.data=src.data.copy()
        o.name=n+'__DISPLAY_EXPORT_COPY';scene.collection.objects.link(o);copies[n]=o
    for n,o in copies.items():
        src=bpy.data.objects[n]
        if src.parent and src.parent.name in copies:
            # Preserve the copied local components and inverse. Reassigning world
            # would decompose the stencil's 90-degree rotation and change float bits.
            o.parent=copies[src.parent.name]
        elif src.parent:
            world=src.matrix_world.copy();o.parent=None;o.matrix_world=world
        else:
            o.parent=None
    for spec in data['patches']:
        o=copies[spec['object']];m=o.data;uv0=m.uv_layers[0];original=bpy.data.objects[spec['object']]
        for rec in spec['uv_faces']:
            for i,co in zip(rec['loop_indices'],rec['uv']):uv0.data[i].uv=co
        m.uv_layers.remove(m.uv_layers[C.UV]);m.uv_layers.active_index=0;uv0.active_render=True
        mat=m.materials[spec['applied_slot']].copy();mat.name=spec['new']+'__DISPLAY_UV0';m.materials[spec['applied_slot']]=mat
        for node in mat.node_tree.nodes:
            if node.type in {'UVMAP','NORMAL_MAP'}:node.uv_map=uv0.name
        assert C.geometry(o)==C.geometry(original)
        for index in range(1,len(m.uv_layers)):
            a,b=m.uv_layers[index],original.data.uv_layers[index]
            assert a.name==b.name and C.array_hash(a.data,'uv',len(a.data)*2,'f')==C.array_hash(b.data,'uv',len(b.data)*2,'f')
    # Evaluate copy parenting before exact world checks.
    scene.view_layers[0].update()
    for n,o in copies.items():assert o.matrix_world==bpy.data.objects[n].matrix_world,n
    assert sum(o.type=='MESH' for o in scene.objects)==12
    C.verify_applied(data)
    print('Prepared separate scene: 12 display mesh copies + two roots. Two UV0 patches, all original scene assets untouched. Not exported or saved.')
    return scene

if __name__=='__main__':prepare()
